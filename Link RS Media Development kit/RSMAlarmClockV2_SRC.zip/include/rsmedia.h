#ifndef _RSMEDIA_H
#define _RSMEDIA_H

//Keys on the left hand side of the RSMedia Remote control
#define RS_KEY_DOWN_L 106
#define RS_KEY_UP_L 105
#define RS_KEY_a 97
#define RS_KEY_b 98
#define RS_KEY_c 99
#define RS_KEY_stop 101
#define RS_KEY_select 115
#define RS_KEY_M 00		// (unknown)
#define RS_KEY_R 63531

//Keys on the Right hand side of the RSMedia Remote control
#define RS_KEY_DOWN_R 110
#define RS_KEY_UP_R 109
#define RS_KEY_x 120
#define RS_KEY_y 121
#define RS_KEY_z 122
#define RS_KEY_play 119
#define RS_KEY_photo 118
#define RS_KEY_D 100
#define RS_KEY_L 62532

//Keys of RSMedia Gauntlets
#define RS_KEY_UP_G 63490
#define RS_KEY_DOWN_G 63491
#define RS_KEY_UP_DOWN_G 63493
#define RS_KEY_PLAY_G 63489
#define RS_KEY_STOP_G 63488

#endif
