These include files assist RSMedia programs to be linked against shared RSMedia libraries.
The include files here are extracted are from common linux sources.
They are collected here in a simplifed directory structure to keep the makefile and directory structure simple.
Normally this would not be recommended with linux libraries. But since RSmedia linux image is unavailable and RSMedia is now unsupported by Wowwee, its extremely unlikley any updates or changes will ever be released.
So by collecting the correct versions of linux headers we can make a subset of include files that are needed. Its very unlikely they will need to be edited or updated.

Here is a list of include files in this directory and the path & sources they were collected from:

/gdk/*			-/usr/include/gtk-1.2/gdk (from gtk+-devel-1.2.10-15.i386.rpm)
/gdk-pixbuf/*	- /usr/include/gdk-pixbuf-1.0/gdk-pixbuf (from gdk-pixbuf-devel-0.14.0-8.i386.rpm)
/gtk/*	 		-/usr/include/gtk-1.2/gtk (from gtk+-devel-1.2.10-15.i386.rpm)
/glib-1.2/*		-/usr/include/glib-1.2 (from glib-devel-1.2.10-5.i386.rpm)
/glibconfig.h   -/usr/lib/glib/include/ (from glib-devel-1.2.10-5.i386.rpm)

By Helibot Aug 2009