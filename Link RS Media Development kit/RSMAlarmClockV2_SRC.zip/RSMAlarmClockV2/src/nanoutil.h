#ifndef _NANO_UTIL_H
#define _NANO_UTIL_H

extern void dumpscreeninfo(GR_SCREEN_INFO	*si);
extern void dumpwinfo(GR_WINDOW_INFO *wi);
extern void dumpwprop(GR_WM_PROPERTIES *wp);
extern void dumpgcinfo(GR_GC_INFO *wp);
extern void dumpfontinfo(GR_FONT_INFO *fi);
extern void getfontlist();
unsigned char *psGetEventName(GR_EVENT_TYPE type);
void get_sys_colors();
void ColourTest(GR_WINDOW_ID wid,GR_GC_ID gc);
#endif
