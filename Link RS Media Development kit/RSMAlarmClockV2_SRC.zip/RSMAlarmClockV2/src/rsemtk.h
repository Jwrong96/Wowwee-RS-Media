#ifndef EMTK_H_
#define EMTK_H_

#define FONT1 1
#define FONT2 2
#define FONT3 3

#define RED_COLOR      "#ff0000" 
#define GRN_COLOR	   "#00ff00"
#define LBLUE_COLOR      "#0080FF"
#define MDBLUE_COLOR      "#000080"
#define WHITE_COLOR      "#FFFFFF"
#define BLACK_COLOR      "#000000"
//"#00001" shows as black?
//"#000010" shows as dark Blue
//"#ff0000" full red
//"#00ff00" full green
//"#0000FF" dark blue
//"#000080" mid blue
//"#000200" Black??


#define TRUE 1
#define FALSE 0

#define WINDOW_X		0
#define WINDOW_Y		0
#define WINDOW_W		132
#define WINDOW_H		176

typedef struct {  //HEBIBOT HAS GUESSED THIS STRUCT!!
    int x;
	int y;
	int w;
	int h;
} WindowRect;

//HEBIBOT HAS GUESSED THESE PARAMATERS!
extern void emtk_root (int,int,int,int);
extern void emtk_window_show (int);
extern void emtk_init(int *argc, char ***argv);
extern int emtk_window_new (int x, int y, int w, int h);
extern int emtk_window_set_background_color(int wid, char * color);
extern int emtk_label_new (int wid, int x, int y, int font, int , char *);
extern int emtk_label_set_foreground_color(int wid, char * color);
extern int emtk_label_set_background_color(int wid, char * color);
extern int emtk_window_add_object (int wid, int obj_id);
extern void *emtk_window_get_drawable(int wid);
extern void emtk_set_focus_window(int wid);
extern void emtk_run(void);
extern void emtk_app_close(void);
extern int emtk_app_get_hl_color(void);
extern WindowRect *emtk_window_add_rect_new(int);
extern void emtk_close(void);
extern void emtk_label_set_string(int, char *, int);

#endif /*EMTK_H_*/
