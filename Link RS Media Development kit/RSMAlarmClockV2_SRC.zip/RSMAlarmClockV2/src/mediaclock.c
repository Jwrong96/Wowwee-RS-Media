/*
 * RSM Alarm  Clock application for RSMedia Robot.
 * Helibot 2009
 *
  * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: mediaclock.c
 * Description 	: Application main entry point
 * Author      	: Helibot
 * Version 	           :2.0     03/11/2009
 */
	
#include <stdio.h>
#include <stdlib.h> //needed for 'system'
#include <string.h> //needed fro strlen
#include <sys/time.h>
#include "rsmedia.h"
#include "nano-X.h"
#include "nanoutil.h"	//Only required for debug printing functions
#include "udfdecl.h" 	//Required for get_time

#include "rsemtk.h"
#include "gdk/gdk.h"
#include "gdk-pixbuf/gdk-pixbuf.h"

#include "iniparser.h" //inifile parser header file.

#include <dirent.h> //Required to read filesnames from a directory

//CLOCK Window Defines
#define CLOCK_W_X 0 //DEPRECATED - The x position is now set in clk_cfg->x_position. It can be configured in the ini file.
#define CLOCK_W_Y 0 //DEPRECATED - The Y position is now set in clk_cfg->y_position. It can be configured in the ini file.
#define CLOCK_W_H 80
#define CLOCK_W_W 132

//CLOCK layout
//H1sH2cM1sM2
#define DIGIT_WIDTH 27
#define DIGIT_HEIGHT 50
#define CLOCK_LHS 5
#define CLOCK_TOP 5
#define CLOCK_SPACE 2
#define CLOCK_COLON_WIDTH 8

#define CLOCK_H1_X CLOCK_LHS
#define CLOCK_H2_X CLOCK_H1_X + DIGIT_WIDTH + CLOCK_SPACE
#define CLOCK_COLON_X CLOCK_H2_X + DIGIT_WIDTH
#define CLOCK_M1_X CLOCK_COLON_X + CLOCK_COLON_WIDTH
#define CLOCK_M2_X CLOCK_M1_X + DIGIT_WIDTH + CLOCK_SPACE

#define HIGHLIGHT_BORDER 1
#define HIGHLIGHT_WIDTH DIGIT_WIDTH*2+2*HIGHLIGHT_BORDER+CLOCK_SPACE + 2
#define HIGHLIGHT_HEIGHT DIGIT_HEIGHT+2*HIGHLIGHT_BORDER + 2

enum {
	LOG_OFF = 0,
	LOG_LOW,
	LOG_MED,
	LOG_HIGH
} eLOGLEVEL;

enum {
	RECUR_SECS = 1,
	RECUR_MINS = 60,
	RECUR_HOURS= 60*60,
	RECUR_DAYS= 60*60*24
} eRECUR_PERIOD;

enum {
	DIR_NONE = 0,
	DIR_RND = 1,
	DIR_SEQ = 2
} eDIRECTORY_ACCESS_TYPE;

enum SET_TIME {SET_OFF = 0,SET_HOURS,SET_MINUTES,SET_DAY,SET_MONTH,SET_YEAR};

typedef struct {
	GR_COORD x;
	GR_COORD y;
	GR_SIZE  width;
	GR_SIZE  height;
} SETHIGHLIGHTPOSTITION;

SETHIGHLIGHTPOSTITION HighLightPostiton[] ={
	{CLOCK_LHS-2,CLOCK_TOP-2,HIGHLIGHT_WIDTH,HIGHLIGHT_HEIGHT},	//x,y,w,h for Box around the Hours digits
	{CLOCK_M1_X -2 ,CLOCK_TOP-2,HIGHLIGHT_WIDTH,HIGHLIGHT_HEIGHT}, //x,y,w,h for Box around the Minutes digits
	{0,56,20,18}, //x,y,w,h for Box around the Day digits
	{21,56,25,18}, //x,y,w,h for Box around the Month digits
	{47,56,35,18} //x,y,w,h for Box around the Year digits
};
//Set the rate the clock will be repainted (in ms) 20000 = 20secs.
#define CLOCK_REFRESH_RATE 20000

//Define the maximum number of alarms the user can define in the config.ini file
#define MAX_ALARMS 20

#define MAX_ACTION_LEN 120

typedef struct _alarm_def_ {
	//Fields from ini data
    int hour;
	int minute;
	int day;
	int weekday;
	int month;
	int year;
	char action[MAX_ACTION_LEN];
	int snooze;		//Not used yet
	int duration;	//Not used yet
	int enabled;	//This must be set for the alarm to be used
	int volume;		//Not used yet
	int recur_value;  //The recurance rate. 0=never, >=1 when to regenerate the alarm 
	int recur_period; //0=seconds,1=minutes,2=hours,3=days,4=months
	int recur_count;  //The number of times a recuring alarm should be triggered
//	int random;		//if random = true, then recur_rate specifies the max number of times per recur period 
	//Internal fields
	int count;	//Count of the number of times the alarm has triggered
	int tid; 	//Timer Id
	int random_max;
	int random_last;
	int directory;	//Set when value for the action is a directory
} alarm_def;


typedef struct _clock_config_ {
	alarm_def *alarms[MAX_ALARMS];
	int num_alarms;
	int mode24hour;
	int y_offset;
	int x_offset;
	char *bg_name;
	int time_offset;
	int forceLCDon;	
} clock_config;

//Clock drawing/processing functions
void paintdigits( GdkWindow *gdkwin, GdkGC *gc, timestamp *time_stamp);
void paint_settime(GdkWindow *gdkwin, GdkGC *gc,enum SET_TIME  settime);
void paint_date(GdkWindow *gdkwin, GdkGC *gc,timestamp *time_stamp);
GR_BOOL changetime(timestamp *newtime,enum SET_TIME settime,GR_KEY key);

//Alarm setup and processing functions
GR_BOOL get_alarm_data(dictionary *ini, alarm_def *alarm, const char *section);
int get_ini_data( dictionary *ini, clock_config *clk_cfg);
static gint processAlarm(gpointer data); /*alarm_def *alarm, dictionary *ini , GR_WINDOW_ID wid);*/
void set_alarm_timer (alarm_def *alarm/*, GR_WINDOW_ID wid*/);
void checkfocus(GR_WINDOW_ID wid);
void setsystemtime(timestamp *newtime);
void adjustsystemtime(int adjust);
void setmidnighttimer(clock_config *clk_cfg);

//Debug functions
char *printdifftime(char *str,int diff);

//Global variables
clock_config clk_cfg;
GdkPixbuf * pixbuf[10];
GdkPixbuf * pixbuf_bg;
GdkFont *gdkfont;
GdkGC *clk_gc = NULL;
static guint tid_clk_refresh=0;
static guint tid_24hr = 0;
dictionary *ini = NULL;

timestamp time_stamp;
timestamp newtime;
enum SET_TIME settime = SET_OFF;
int log_level = LOG_MED;

//Look up the ini file cache for an alarm and fetch the alarm data.
//Inputs:
//  ini - pointer to the ini dictionary.
//  alarm - point to an alarm_def structure (will be filled in with alarm data)
//  section - a string with the name of the alarm (usually "alarmX")
//Returns -
//  If the alarm data is found then all data is copied into the alarm structure.  
//Notes - 
//  Handles fetching dates & times for alarms,
//  Handles fetching recurance settings and of course the alarm action  
GR_BOOL get_alarm_data(dictionary *ini,alarm_def *alarm,const char *section)
{
	char char1;
	
	char str_in[MAX_ACTION_LEN];
	str_in[0] = 0;
	
	//Clear the alarm config to all zeros.
	memset(alarm,0,sizeof(alarm));
	if (log_level >= LOG_MED) printf ("Checking for %s\n",section);
 
	alarm->enabled = iniparser_getboolean2(ini, section, "enabled", 0);
	if (alarm->enabled != 0)  //Only get alarm data if alarm exists and is enabled.
	{
		//Get action target
		strncpy(&str_in[0],iniparser_getstring2(ini, section ,"action", ""),MAX_ACTION_LEN);
		if (str_in[0] != 0) 
		{
			strncpy(alarm->action, str_in, MAX_ACTION_LEN);
		}
		else 
		{	//action not found, so check for action_random
			strncpy(&str_in[0],iniparser_getstring2(ini, section ,"action_rnd", ""),MAX_ACTION_LEN);
			if (str_in[0] != 0) {
				strncpy(alarm->action, str_in, MAX_ACTION_LEN);
				alarm->directory = DIR_RND;
			} else {	//action_rnd not found, so check for action_seq
				strncpy(&str_in[0],iniparser_getstring2(ini, section ,"action_seq", ""),MAX_ACTION_LEN);
				if (str_in[0] != 0) {
					strncpy(alarm->action, str_in, MAX_ACTION_LEN);
					alarm->directory = DIR_SEQ;
				}
			}
		}
		if (log_level >= LOG_MED) printf ("Found %s.action=%s\n",section, alarm->action);
		
		memset(str_in,0,MAX_ACTION_LEN);
		strncpy(&str_in[0],iniparser_getstring2(ini, section, "time", ""),MAX_ACTION_LEN);
		if (str_in[0] != 0) {
			char1=' ';
			sscanf (str_in,"%d%*c%d%c",&alarm->hour,&alarm->minute,&char1);
			if ((char1 == 'p' || char1 == 'P') &&  
			    (alarm->hour > 1 &&  alarm->hour < 12))
				alarm->hour = alarm->hour + 12;
			//Special case for 12:00am -12:59am - this needs to be treated as 00:00-00:59
			if ((char1 == 'a' || char1 == 'A') &&
			    (alarm->hour == 12))
				alarm->hour = 0;
			if (log_level >= LOG_MED) printf("Found %s;time is %d:%d\n",section, alarm->hour,alarm->minute);	   
		}else
		{
			alarm->hour = -1;  // If time is not set then set to -1 (cos 00:00 is a valid time)
			alarm->minute = -1;
		}

		memset(str_in,0,MAX_ACTION_LEN);
		strncpy(&str_in[0],iniparser_getstring2(ini, section, "date", ""),MAX_ACTION_LEN);
		if (str_in[0] != 0) {
			sscanf (str_in,"%d%*c%d%*c%d",&alarm->year,&alarm->month,&alarm->day);
			if (alarm->year <= 1899) alarm->year=0;  
			if (alarm->month <1 && alarm->month >12) alarm->month=0;
			if (alarm->day <1 && alarm->month >31) alarm->day=0;			  
			if (log_level >= LOG_MED) printf("Found %s has date %s;date = %d/%d/%d\n",section, str_in, alarm->year,alarm->month,alarm->day);	   
		}


		//Get the recurance rate of the alarm
		memset(str_in,0,MAX_ACTION_LEN);
		strncpy(&str_in[0],iniparser_getstring2(ini, section, "recur", ""),MAX_ACTION_LEN);

		if (str_in[0] != 0) {
			char1=' ';
			sscanf (str_in,"%d%c",&alarm->recur_value,&char1);
			if (char1 == 's' || char1 == 'S') alarm->recur_period = RECUR_SECS;
			if (char1 == 'm' || char1 == 'M') alarm->recur_period = RECUR_MINS;
			if (char1 == 'h' || char1 == 'H') alarm->recur_period = RECUR_HOURS;
			if (char1 == 'd' || char1 == 'D') alarm->recur_period = RECUR_DAYS;
			if (log_level >= LOG_MED) printf("Found recur %s\n",str_in);
		}
		alarm->weekday = iniparser_getint2(ini, section, "weekday", 0);
		alarm->recur_count = iniparser_getint2(ini, section, "recurcount", 0);
//		alarm->random = iniparser_getboolean2(ini, section, "random", 0);
		alarm->enabled = iniparser_getboolean2(ini, section, "enabled", 1); //Set default to 1 (enabled)
		alarm->snooze = iniparser_getint2(ini, section, "snooze", 0);
		alarm->duration = iniparser_getint2(ini, section, "duration", 0);
		alarm->volume = iniparser_getint2(ini, section, "volume", 0);
		alarm->random_max=-1;
		alarm->random_last=-1;

		if (log_level >= LOG_MED) printf("Found %s ;enabled is %d. snooze is %d. duration is %d. volume is %d\nRecur value %d, Recur period %d, Hour %d, Min %d\n",section,
			alarm->enabled,
			alarm->snooze,
			alarm->duration,
			alarm->volume,
			alarm->recur_value,
			alarm->recur_period,
			alarm->hour,
			alarm->minute);
	} else
		return FALSE;  //If alarm does not exist or is disabled then return FALSE.
	return TRUE;
}

//Read the config.ini file and extract the alarm information
//Inputs:
//  ini - pointer to the ini dictionary.
//  clock_cfg - pointer to the global clk_def structure
//Returns -
//  True (ie we have loaded some data) 
//Notes - 
//It will check for alarms named alarm1 to alarmxx where xx is MAX_ALARMS
//It will also load the values for misc and debug sections of the inifile.
int get_ini_data( dictionary *ini, clock_config *clk_cfg)
{	
	int i,j=0;
	alarm_def tempalarm; 
	char alarmname[10];
	//get_alarm_data(ini,&clk_cfg->alarm1,"alarm1");
	//get_alarm_data(ini,&clk_cfg->alarm2,"alarm2");
	clk_cfg->num_alarms = 0;
	for (i=1;i<=MAX_ALARMS;i++)
	{
		sprintf(alarmname,"alarm%d",i);
		if (log_level >= LOG_MED) printf("Checking for alarm %s\n",alarmname);
		//Zero out the tempory structure
		memset(&tempalarm,00,sizeof(alarm_def));
		//Load the data from the ini file
		if (get_alarm_data(ini,&tempalarm,alarmname) == TRUE)
		{ //Alarm was found so make a copy and save it.
			clk_cfg->alarms[j]= malloc(sizeof(alarm_def));
			memcpy(clk_cfg->alarms[j],&tempalarm,sizeof(alarm_def));
			if (log_level >= LOG_MED) 
			   printf("Found %s ;copied to alarms[%d]\n",alarmname,j);
			j++;
		}
	}
	clk_cfg->num_alarms = j;
	if (log_level >= LOG_MED) 
	{ 
		printf("Found %d enabled alarms\n",j);
	}		   
	//NEED TO REMEMBER TO FREE THE MALLOCED ALARMS LATER??
			
	log_level = iniparser_getint(ini, "debug:level", 0);
	clk_cfg->mode24hour = iniparser_getboolean(ini, "misc:24hourmode", 0);
	clk_cfg->y_offset = iniparser_getint(ini, "misc:yoffset", CLOCK_W_Y);
	clk_cfg->x_offset = iniparser_getint(ini, "misc:xoffset", CLOCK_W_X);
	clk_cfg->bg_name = iniparser_getstring(ini, "misc:background", "");
	clk_cfg->time_offset = iniparser_getint(ini, "misc:timeadjust", 0);
	clk_cfg->forceLCDon = iniparser_getboolean(ini,"misc:forceLCDon",1);
	return 1;  //we successfully loaded some data
}	

//Retreives the next file from a directory used for action_rnd or action_seq commands
//Inputs:
//  actioncmd - pointer to a supplied buffer where the action command will be created in.
//  alarm - pointer to an alarm_def structure
//Returns -
//  formated action command in the paramater actioncmd 
//Notes - 
//For the first time though the code will open the directory and walk the list of all files 9to find out the number of available files)
//For first and subsequent calls it iterate through the filelist and choose a file to be used, then format the command line with the found file.
//Handles random - select a file randomally from the list.
//Handles sequential - iterate to the next file each time the function is called.
void getvaluefromdirlist(char* actioncmd,alarm_def *alarm)
{
	DIR *dp;
    struct dirent *ep;
    int count=0;

	if (alarm->random_max == -1)  //We dont know the number of files in the directory yet
	{	//This should only need to be done when the alarm runs for the first time.
       alarm->random_max = 0;
	   alarm->random_last = 0;
       dp = opendir (&alarm->action[6]);
       if (dp != NULL)
         {
           while ((ep = readdir(dp))) {
			if (ep->d_type != DT_DIR)  //If its not a directory
			{
             	alarm->random_max++; 
             	//puts (ep->d_name);  //DEBUG ONLY
             	if (log_level >= LOG_HIGH) printf("name = %s, type = %d\n",ep->d_name,ep->d_type);
			}
           }
           (void) closedir (dp);
           if (log_level >= LOG_HIGH) printf("Alarm->Directory_MAX = %d\n",alarm->random_max);

         }
       else
         if (log_level >= LOG_LOW) printf("Couldn't open the directory");
	}

	if (alarm->directory ==DIR_RND)  //Select a random file from the directroy list
	{
		count = random();  // Should generate a very large number
		if (alarm->random_max >= 0)
		{
			//Use modulus operator to reduce the number to 0-random_max
			//I dont know if this is a good way todo this ....but its certainly easy!! 
			count = count%alarm->random_max;
			count++; //Change count from 0-random-max-1 to 1-random-max range.
		}else count = 1;
		if (log_level >= LOG_HIGH) printf("Alarm rand file count = %d\n",count);

	}

	if (alarm->directory ==DIR_SEQ)  //Get the next file from the directory list
	{
		//Have we used all file names? If yes then reset to the start
		alarm->random_last++;
		if (alarm->random_last > alarm->random_max)
			alarm->random_last = 1;
		count = alarm->random_last;
		if (log_level >= LOG_HIGH) printf("Alarm seq file count = %d\n",count);
	}

	//Now open the dir and iterate thorugh the directory entries by 'count' times.
    dp = opendir (&alarm->action[6]);
    if (dp != NULL)
    {
    	int i=1;	
		while ((ep=readdir(dp))) {
			if (ep->d_type != DT_DIR)  //If its not a directory then increase the counter
				i++;
			if (i > count)  //Stop when we have read count entries from the directory.
				break;
       }
       	//When we have the file then create the action string from the action, the path and the filename
		if (ep !=NULL && ep->d_name != NULL)
		{
			sprintf (actioncmd,"%s %s/%s",actioncmd,&alarm->action[6],ep->d_name);
		} else
		{
			sprintf (actioncmd,"echo ***ERROR FILE NOT FOUND - ALARM FAILED***");
		}

       (void) closedir (dp);
	}
	if (log_level >= LOG_MED) printf("After getvaluefromdirlist() actioncmd = [%s]\n",actioncmd);
}

//This function is called back by a glib timer. Not sure of the context? But it seems to be able to see and access global data ok.
//May cause problems if triggers drawing or other gdkwindow processing? 
//(if it does then should post a gdk message to the gdk message queue and trigger alarms from there.))
static gint processAlarm(gpointer data){
	alarm_def *alarm = (alarm_def *)data;
	char typestr[] = "actioncmds:      ";
	char actioncmd[2 * MAX_ACTION_LEN];
	//First thing  - send a special command to the robot board to turn the LCD on
	system(	"/usr/bin/robot/pipe /tmp/robot_pipe -2 3 0 0 0");
	if (log_level >= LOG_MED) printf("ProcessAlarm:typestr = [%s]\n",typestr);
	
	//Get the action type for the alarm.
	sscanf (alarm->action,"%5s",&typestr[11]);
	if (log_level >= LOG_MED) printf("typestr = [%s]\n",typestr);
	
	//Now use the typestr to lookup the system action command from the inifile
	strncpy(actioncmd,iniparser_getstring(ini, typestr, ""),MAX_ACTION_LEN);
	if (log_level >= LOG_MED) printf("actioncmd = [%s]\n",actioncmd);
//	strncat(actioncmd,&alarm->action[5],MAX_ACTION_LEN);
//	printf ("system string will be [%s]\n",actioncmd);
	if (alarm->directory == 0)
	{   //Just join the action command and the action value together
		sprintf (actioncmd,"%s %s",actioncmd,&alarm->action[6]);
	}
	else
	{
		//Need to get the real value from the directory specified in action
		//This function will fetch the file name and create the command in the actioncmd array.
		getvaluefromdirlist(actioncmd,alarm);
	}

	if (log_level >= LOG_MED) printf ("Alarm System string will be [%s]\n",actioncmd);
	system(actioncmd);
	//system("/usr/bin/robot/audioplayer -f/mnt/sd/Personalities/female/Sounds/tracking.mp3");
	alarm->count +=1; //Incerement the number of times this alarm has triggered.
	//Check if the alarm needs to be rescheduled (if its a recurring alarm)
	set_alarm_timer (alarm);		

    return FALSE;  //This will also cancel the timer
}

//Called once a day to check which alarms need to be set and set them
//Inputs:
//  data- pointer which is cast to be the clock config structure
//Returns -
//  false - to force the timer to be stopped 
//Notes - 
//  -Check all alarms that have a time set and dont already have a timer set
//  -Also if the timeadjust paramater is set then it a applies the offset to system clock.
//  -Finially the code sets the timer again for 00:00:10 the following day.
static gint setDateAlarms(gpointer data){
	clock_config *clk_cfg = (clock_config *)data;
	alarm_def *alarm;
	int i;
	
	if (log_level >= LOG_LOW) printf("SetDateAlarms started\n");
	for (i=0; i < clk_cfg->num_alarms;i++)
	{
		alarm = clk_cfg->alarms[i];
	 	if (log_level >= LOG_LOW) printf("Alarm %d enab=%d,year=%d,weekday=%d,tid=%d\n",i,alarm->enabled,alarm->year,alarm->weekday,alarm->tid);
		if (alarm->enabled &&     //The alarm is enabled
//			(alarm->year > 1900 || //A year or weekday is set
//			alarm->weekday > 0) &&
			(alarm->hour >=0 && alarm->minute >= 0) && //A time is set
			alarm->tid == 0)	  //The alarm is not already scheduled
		{
		 	if (log_level >= LOG_LOW) printf("Trying to set Alarm %d\n",i);
			alarm->count = 0; //Set the alarm count back to zero for the next day.
		 	set_alarm_timer(alarm); //So try to set the alarm.
		 }	
	}
	if (log_level >= LOG_LOW)
	{ 
		char datestring[20];
		printf ("Before adjust of %d sec (Time is %s)\n",clk_cfg->time_offset,printdifftime(datestring,0));
	}
	if (clk_cfg->time_offset !=0)
		adjustsystemtime (clk_cfg->time_offset);
	if (log_level >= LOG_LOW)
	{ 
		char datestring[20];
		printf ("After adjust time is %s\n",printdifftime(datestring,0));
	}
		
	//Set the timer for midnight again		
	setmidnighttimer(clk_cfg);
    return FALSE;  //Returning false causes this timer to be stopped and deleted.
}

//Adjust the current time by +/- a number of seconds.
//Call once a day to adjust for RSMedia clock drift.
void adjustsystemtime(int adjust)
{
	int ret=0;
	struct timeval offset;
	offset.tv_sec = (long) adjust;
	offset.tv_usec = 0L;
	ret = adjtime (&offset,NULL);
	if (log_level >= LOG_LOW) printf("Adjusted time by %d secs (ret = %d)\n",adjust,ret);
}

void set_alarm_timer (alarm_def *alarm)
{
	timestamp curr_time;
	gint32 diff=0;
	//long diff;
	
//   struct timeval time1;
   //int ierr;
   //ierr = gettimeofday(&time1, NULL);
   //printf("Now timeval = %ld secs\n",time1->tv_sec);
	
//	get_timestamp(&curr_time);  //DEBUG
	if (alarm->enabled != 0 ) {
		//Find diff b/n current and alarm time in seconds
		get_timestamp(&curr_time);

//DEBUG
		if (log_level >= LOG_HIGH) printf ("Current Date %d/%d/%d\n",curr_time.day,curr_time.month,curr_time.year);
//DEBUG
		if (log_level >= LOG_HIGH) printf ("Alarm Date %d/%d/%d\n",alarm->day,alarm->month,alarm->year);

		//If alram date is set and it matches the current date then continue.
		//Otherwise DONT  
		if (alarm->year > 1900) //If the alarm year is set 
		{
			if (alarm->year == curr_time.year &&
				alarm->month == curr_time.month &&
				alarm->day == curr_time.day)
			{
				if (log_level >= LOG_HIGH) printf ("Alarm date matches today!!");
				if (alarm->hour >=0 && alarm->minute >= 0) //If an alarm time is set.
				{
					
					diff = (alarm->hour*60 + alarm->minute) - (curr_time.hour*60 + curr_time.minute);
					if (diff < 0) //If difference is < 0 then alarm time has passed.
						diff = 0;
					else
						diff*=60; //Convert to seconds
					if (log_level >= LOG_MED) printf ("Alarm date set %d secs\n",diff);
				}
			}
		}
		else //A full date is not set - see if a time or recurrance alarm is set
		{
			if (alarm->recur_value > 0 )
			{
				//If a recur counter is set and the alarm count is greater then dont set the alarm again 
				if (alarm->recur_count != 0  && alarm->count >= alarm->recur_count)
				{
					if (log_level >= LOG_MED) printf("Alarm has run %d times. Alarm Recurrance is now stopped\n",alarm->count);
				}
				else
				{  //Its Ok to try and set the recuring alarm again
					if (log_level >= LOG_HIGH) printf("RECUR SET Recur value %d, Recur period %d, Hour %d, Min %d\n",
					alarm->recur_value,
					alarm->recur_period,
					alarm->hour,
					alarm->minute);
				
					if (alarm->recur_value*alarm->recur_period < 60*60*12) //Is recur period less than a day?
					{
						if (alarm->hour >= 0 && alarm->minute >=0 )
						{ 
							diff = (alarm->hour*60 + alarm->minute) - (curr_time.hour*60 + curr_time.minute);
							if (diff < 0 ) //If difference is < 0 then alarm time has passed.
							{
								if (alarm->count == 0)
								{  //Alarm has not triggered yet and the time has already past for today
									if (log_level >= LOG_MED) printf ("Alarm time past (%d mins ago) - Alarm not triggered\n",diff);
								}
								else 
								{ //We are recurring so set the alarm
									diff*=60; //Convert to seconds
									if (log_level >= LOG_MED) printf ("Alarm should still be occuring\n");
									//OLD Method
									//Loop adding the alarm period until we get to a number > 0.
									//while (diff <= 0 ) //Loop adding the recur period until we get a positive value!!
									//	diff+= alarm->recur_value*alarm->recur_period;
									//NEW Method
									//Now we need to find out the last time the alarm went off if it was set at the correct recur time after the original alarm time.
									//We use the modulus operator to help this. Then add the recur period on again to give us teh final new time (in seconds)
									diff = (diff%alarm->recur_value*alarm->recur_period) + (alarm->recur_value*alarm->recur_period);
									if (log_level >= LOG_MED) printf ("Alarm time recur past %d secs\n",diff);
								}
							}
							else if (diff == 0) //alarm time = current time 
							{ //alarm has proably just occured - so set again for 1 recurance ahead
								diff = alarm->recur_value*alarm->recur_period;
								if (log_level >= LOG_MED) printf ("Alarm time = now so recur %d secs\n",diff);
							}
							else //diff is > 0 so diff is already correct.
							{
								diff*=60; //Convert to seconds
								if (log_level >= LOG_MED) printf ("Alarm time recur ahead %d secs\n",diff);
							}
							//So far we have calculated alarm time accurate to the minute. We now need to correct for the fact we maybe a long way through that minute!!
							if (diff > 75) //Test greater than 75 to ensure we cant set an alarm < 15 secs away. 
 							{
								diff = diff - curr_time.second;
								if (log_level >= LOG_MED) printf ("Alarm time corrected to %d secs\n",diff);
							}
						}
						else //An alarm time is not set
						{	//So just set the recurrence from now 
							diff = alarm->recur_value*alarm->recur_period; //Calc the difference in seconds to the next alarm time 
							if (diff > 0 && diff < 15) diff = 15; //dont let alarms less than 15 secs away be set
							if (log_level >= LOG_MED) printf ("Alarm recur %d secs\n",diff);
						}
					}
					else //Recur value is set > 24 hours......we are not handling this yet!!
					{ 
						if (log_level >= LOG_LOW) printf ("Alarm - recurance > 24hours set - not supported. Alarm not set\n");
					}
				} //endif recur has occured less than recour_count times 
			} // endif recur value set
 
			if (diff == 0  && alarm->weekday > 0 ) //a weekday alarm is set
			{
				//DEBUG ONLY
				if (log_level >= LOG_HIGH) printf("Weekday check alarm weekday=%d, current weekday = %d\n", alarm->weekday,get_weekday(curr_time.month,curr_time.day,curr_time.year)); 
				//Check if weekday matches today
				if (alarm->weekday-1 == get_weekday(curr_time.month,curr_time.day,curr_time.year))
				{  //If set week day equals current time the set the alarm.
					if (log_level >= LOG_LOW) printf ("Alarm - weekday alarm set - Today matches day %d\n",alarm->weekday);					
					if (alarm->hour >= 0 && alarm->minute >=0) //If an alarm time is set.
					{
						diff = (alarm->hour*60 + alarm->minute) - (curr_time.hour*60 + curr_time.minute);
						if (diff < 0) //If difference is < 0 then alarm time has passed.
							diff = 0;
						else
							diff*=60; //Convert to seconds
						if (log_level >= LOG_MED) printf ("Alarm weekday set %d secs\n",diff);
					}
					//So far we have calculated alarm time accurate to the minute. We now need to correct for the fact we maybe a long way through a minute!!
					if (diff > 75) //Test greater than 75 to ensure we cant set an alarm < 15 secs away. 
					{
						diff = diff - curr_time.second;
						if (log_level >= LOG_MED) printf ("Alarm time corrected to %d secs\n",diff);
					}
				}
			}
  			//Time is set but recur value and date and weekday are not set  - so assume it is a daily alarm.			
			if (diff==0 && alarm->year <=1900 && alarm->recur_value <=0 && alarm->weekday <= 0 && alarm->hour >= 0 && alarm->minute >=0 )
			{
					diff = (alarm->hour*60 + alarm->minute) - (curr_time.hour*60 + curr_time.minute);
					if (diff < 0) //If difference is < 0 then alarm time has passed.
						diff = 0;
					else
						diff*=60; //Convert to seconds
					if (log_level >= LOG_MED) printf ("Alarm daily set %d secs\n",diff);
			}
			
		}

		if (log_level >= LOG_HIGH) printf ("Removing old timer %d\n",alarm->tid);
		if (alarm->tid)
			g_source_remove(alarm->tid);  //Destroy the timer if it existed

		//Create new timer
		if (diff > 0 )
		{
			
			if (log_level >= LOG_LOW)
			{ 
				char datestring[20];
				printf ("Alarm timer %d minutes away (Time will be %s)\n",diff/60,printdifftime(datestring,diff));
			}
			//convert diff from seconds to milliseconds
			diff = diff*1000;
			if (log_level >= LOG_MED) printf (" (%i ms)\n ",diff);
			alarm->tid = g_timeout_add((guint32) diff, processAlarm,alarm);
			if (log_level >= LOG_HIGH) printf ("Timer ID = %d\n ",alarm->tid);
		}
	}
}
#if 0
void checkfocus(GR_WINDOW_ID wid)
{
	int cur_wid = GrGetFocus();
	if (log_level >= LOG_MED) printf ("Time to refresh");
	if (wid != cur_wid) {
		//Current focus is NOT to our window , so lets steal it back!!
		//Make our window get focus
		GrSetFocus(wid);
		//Make window visible
		GrRaiseWindow(wid);
		GrMapWindow(wid);
		//GrClearWindow(wid, GR_TRUE);
		if (log_level >= LOG_MED)
			printf ("**CLOCK LOST FOCUS -stolen it back**\n");  //Debug
	}
}
#endif


static gint gdkwin_draw (gpointer data)
{
	GdkWindow *gdkwin = (GdkWindow*)data;
	GdkColor gdkcolor;
	int width,height;
	g_return_val_if_fail (gdkwin!=NULL, 0);
   	
	//Create a Graphic Context
	if (clk_gc == NULL) {
		clk_gc = gdk_gc_new (NULL);
		
		gdk_color_parse ("red", &gdkcolor);
		gdk_colormap_alloc_color(gdk_colormap_get_system(),&gdkcolor, TRUE,TRUE);
		if (log_level >= LOG_HIGH) printf ("Color =%x,%x,%x,%lx\n",gdkcolor.red,gdkcolor.green,gdkcolor.blue,gdkcolor.pixel);
		gdk_gc_set_foreground (clk_gc, &gdkcolor);
	}

	//Clear the window 
	if (pixbuf_bg == NULL)  //If no background picture then clear background
		gdk_window_clear(gdkwin);
	else
	{
		//Draw the background picture
		width = gdk_pixbuf_get_width (pixbuf_bg);
		height = gdk_pixbuf_get_height (pixbuf_bg);
    	gdk_pixbuf_render_to_drawable_alpha(pixbuf_bg, gdkwin,
	      0, 0, 0, 0,	
      	width , height ,
      	GDK_PIXBUF_ALPHA_BILEVEL, 128,
      	GDK_RGB_DITHER_NORMAL, 0, 0);
	}
	if (log_level >= LOG_MED) printf ("Drawing Screen\n");
	if (settime == SET_OFF)  //Ie user is not setting time
	{
		get_timestamp(&time_stamp); //Get current time
		paintdigits(gdkwin, clk_gc, &time_stamp); //draw the current time
		paint_date(gdkwin, clk_gc, &time_stamp); //Draw the current date
	}else  //User is setting the time
	{
		paintdigits(gdkwin, clk_gc ,&newtime); //draw the time the user is adjusting
		paint_settime(gdkwin, clk_gc,settime);	//draw the highlight around the element being set
		paint_date(gdkwin, clk_gc ,&newtime); //Draw the date the user is adjusting
	}
	if (log_level >= LOG_MED) printf ("Drawing Done!!\n");

	return 1;
}

static GdkFilterReturn gdkwin_event_handler (GdkXEvent *xevent,
GdkEvent *event, gpointer data)
{
    int need_redraw = FALSE;

//    gdk_window_get_user_data();  //Can we Use this to get a common data struct?????
//    Probably need to use this during main void gdk_window_set_user_data (GdkWindow *window,gpointer user_data);

//	enum SET_TIME settime=SET_OFF;
	GR_EVENT *gr_event;
	gr_event = (GR_EVENT *)xevent;
	if (log_level >= LOG_MED) printf ("Event Received =%s  wid = %d\n",psGetEventName(gr_event->type),gr_event->keystroke.wid);
	switch (gr_event->type)
	{
		case GR_EVENT_TYPE_KEY_DOWN:
			//case GR_EVENT_TYPE_KEY_UP:
			{
				switch (gr_event->keystroke.ch)
				{
					case RS_KEY_a:
						if (log_level >= LOG_LOW) printf ("=='a' key pressed - EXITING RSMALARMCLOCK APP NOW===\n");
						//Send a message to destroy the window??

						//gdk_window_destroy((GdkWindow*)data); //destroys the window but does not exit
						if (clk_gc)
							gdk_gc_destroy(clk_gc);
						if (tid_clk_refresh)
							g_source_remove(tid_clk_refresh);  //Destroy the timer
						if (tid_24hr)
							g_source_remove(tid_24hr);  //Destroy the timer

						//TODOP - Should free memory in an orderly fashion
						//Now close emtk - probably not the correct way to do it, but I cant find anything better to break the emtk_run loop
						emtk_close();
						break;
					case RS_KEY_x:  //'x' key
						need_redraw = TRUE;
						break;
					case RS_KEY_DOWN_L: //'Left Dn' key
					case RS_KEY_UP_L: //'Left Up' key
						if (settime != SET_OFF) {
							if (changetime(&newtime,settime,gr_event->keystroke.ch)) {
								need_redraw = TRUE;
							}
						}
						break;
					case RS_KEY_UP_R:			
						if (settime != SET_OFF)
							settime ++;
						if (settime > SET_YEAR)	settime = SET_HOURS;
						if (log_level >= LOG_MED) printf ("***Set Time = %d***\n",settime);
						//Force Repaint of the window
						need_redraw = TRUE;
						break;
					case RS_KEY_DOWN_R:
						if (settime != SET_OFF)
							settime --;
						if (settime < SET_HOURS) settime = SET_YEAR;
						if (log_level >= LOG_MED) printf ("***Set Time = %d***\n",settime);
						//Force Repaint of the window
						need_redraw = TRUE;
						break;
					case RS_KEY_select:  //115
						if (log_level >= LOG_MED) printf ("***Set Time = %d***\n",settime);
						if (settime == SET_OFF){
							settime = SET_HOURS;
							newtime = time_stamp;  //This will copy the timestamp data to newstamp struct?
							if (log_level >= LOG_MED) printf ("***Start set time mode = %d***\n",settime);
						}else { //Leaving set time mode so lets set the time
							setsystemtime(&newtime);
							
							//Restart alarm timers now the date/time is changed
							int i;
							for (i=0;i<clk_cfg.num_alarms;i++)
								set_alarm_timer(clk_cfg.alarms[i]);
								
							//Finially set the 24hour timer to set alarms for the next day.
							setmidnighttimer(&clk_cfg);
						}
						if (log_level >= LOG_MED) printf ("***Set Time = %d***\n",settime);
						//Force Repaint of the window
						need_redraw = TRUE;
						break;
				}
				
			}
			if (log_level >= LOG_LOW) printf ("Key Down Received scancode = %d  ch = %d mod=%d wid = %d\n",gr_event->keystroke.scancode,gr_event->keystroke.ch,gr_event->keystroke.modifiers,gr_event->keystroke.wid);
			break;

		case GR_EVENT_TYPE_EXPOSURE:
		case GR_EVENT_TYPE_FOCUS_IN:
			gdkwin_draw (data);
			//printf ("Event Received =%s  wid = %d\n",&psEventType[event.exposure.type][0],event.exposure.wid);
			break; //Test
		case GR_EVENT_TYPE_ERROR:
			if (log_level >= LOG_LOW) printf ("Error Event Received (code = %d)\n",gr_event->error.code);
				break; //Test

		case GR_EVENT_TYPE_CLOSE_REQ:  //Called when we are exiting??
			if (log_level >= LOG_LOW) printf ("CLOSE_REQ Received\n");

			//TODO What else do we need to destroy??
				
			break; //Test
					
		default:
			if (log_level >= LOG_HIGH) printf ("Unhandled event skipped=%s \n",psGetEventName(gr_event->general.type));
			//printf ("Key Down Received scancode = %d  ch = %d mod=%d wid = %d\n",event.keystroke.scancode,event.keystroke.ch,event.keystroke.modifiers,event.keystroke.wid);
			break;
	}

	if (need_redraw)
		gdkwin_draw(data);
		
	return GDK_FILTER_CONTINUE;
}

void setsystemtime(timestamp *newtime)
{
	//Could use set_time() in udftime.c but it doesnt seem to work?? (sets time & date wrong!!)
	//So instead we will use a system call to the date -s linux command.
	char date_string[20];
	settime = SET_OFF;
	sprintf(date_string,"date -s %02d%02d%02d%02d%04d",
		newtime->month,newtime->day,newtime->hour,newtime->minute,newtime->year);
	if (log_level >= LOG_MED) printf ("Settime with %s\n",date_string);
	system(date_string);
}

//SetMidnightTimer function- set a timer for 00:10 (ie 10mins after midnight) 
//Paramaters
// str an array of char theat the time/date string will be written into
// diff an int that represents the offset to add/subtract (in seconds)
//Returns 
// A string of format hh:mm:ss dd/mm/yy of the current time + diff 
void setmidnighttimer(clock_config *clk_cfg)
{
	timestamp curr_time;
	gint32 diff = 0;
	
	//Set a timer that triggers once a day. It will then set timers for any alarms that match todays date
	get_timestamp(&curr_time);
	//Find num of millesecs to 00:00:10 of the next day.
	if (log_level >= LOG_MED) {	
		printf ("DATTIMER curtime = %d:%d:%d\n",curr_time.hour,curr_time.minute,curr_time.second);
		printf ("DATTIMER secs today = %d\n",curr_time.hour*60*60 + curr_time.minute*60 + curr_time.second);
		printf("DATTIMER recur days = %d\n",RECUR_DAYS*1000);
	}
	diff = RECUR_DAYS*1000  - (curr_time.hour*60*60 + curr_time.minute*60 + curr_time.second)*1000 + 10*1000;
	
	tid_24hr = g_timeout_add(diff, setDateAlarms,clk_cfg);
	if (log_level >= LOG_LOW) printf ("Set Timer for %d msecs away id= %d\n ",diff,tid_24hr);
}

//Main entry point for the Alarm clock program
//Initialises the emtk windowing library
//Opens Config.ini file and reads config data (including alarms)
//Creates a new window to draw into
//Loads the graphic images for the clock digits
//Creates a gdk window handle (which is used for all drawing)
//Registers fonts and event handler (so keyboard and window events can be processed)
//starts timers 9a general one and one any alarms to occur in the next 24 hours)
//finially calls emtk_run() - This function never returns until its time to exit.

int main (int argc, char **argv)
{
	int window_id; //For emtk window id
	GdkWindow *gdkwin;
	int width = CLOCK_W_W;
	int height = CLOCK_W_H;
	int i;
//	timestamp curr_time;

	
	//Initialise emtk library and create a root window
	emtk_init (&argc, &argv);
	//Dont need to call emtk_root (since it was probably done by mediadaemon)	
	//emtk_root (WINDOW_X, WINDOW_Y, WINDOW_W, WINDOW_H-40);

	//Next open the ini file and get any configuration data
	ini = iniparser_load("config.ini");
	if (ini == NULL) {
		if (log_level >= LOG_LOW) printf ("Config File failed to Load, continuing anyway\n");
	}
	else {
		get_ini_data( ini, &clk_cfg);
		if (log_level >=LOG_MED)
			iniparser_dump(ini, stdout);
	}

	//Load the background picture (if available)
	if (clk_cfg.bg_name != NULL) {
		pixbuf_bg = gdk_pixbuf_new_from_file (clk_cfg.bg_name);
		if (pixbuf_bg == NULL) {
			printf("Failed to find background picture\n");
		} else {
			width = gdk_pixbuf_get_width (pixbuf_bg);
			height = gdk_pixbuf_get_height (pixbuf_bg);
		}
			
	}

	//Create a new window we can draw onto
	window_id = emtk_window_new (clk_cfg.x_offset, clk_cfg.y_offset , width, height);
	if (log_level >= LOG_LOW) printf("Created new wind for drawing \n  x=%d,y=%d,w=%d,h=%d\n",clk_cfg.x_offset, clk_cfg.y_offset , width, height);
	emtk_window_set_background_color(window_id,/*GRN_COLOR*/ /*MDBLUE_COLOR*/ BLACK_COLOR);
	emtk_window_show (window_id);

	//NOTE that the file can actually be .jpeg,png,gif format (but it must be named "demoapp.png"
	if (log_level >= LOG_LOW) printf ("Loading clock digit pictures\n");
	char name[20];
	for (i=0;i<10;i++) {
		sprintf(name,"%d.png",i);
		pixbuf[i] = gdk_pixbuf_new_from_file (name);
		if (pixbuf[i] !=NULL && log_level >= LOG_LOW) printf("Successfully loaded pixbuf[%d] from %s\n",i,name);
	}
	
	//Get gdk handle for the window emtk window
	gdkwin = emtk_window_get_drawable(window_id);
	//Add an event handler for this GDK window (the handle will be called for every window event)
	gdk_window_add_filter (gdkwin, gdkwin_event_handler, (gpointer)gdkwin);

	//Load the bold normal 12 pixel high font
	gdkfont = gdk_font_load("-adobe-helvetica-bold-r-normal--12-120-75-75-p-70-iso8859-1");	 
	/////printf ("FONT2 HEIGHT = %d\n",gdk_text_height(gdkfont,"Test GDK Test",13));	


	//Allow all messages to be received by our handler- we probably could just select some.....
///	GrSelectEvents(wid, GR_EVENT_MASK_ALL);
	//Set a timer to trigger at midnight. It will call setDateAlarms() which will set the date and weekday alarms for the next day.
	setmidnighttimer(&clk_cfg);	
	
	//Check and set timers for all alarms
	for (i=0;i< clk_cfg.num_alarms;i++)
		set_alarm_timer(clk_cfg.alarms[i]);

	// create timer  - it will trigger every 20 seconds and call gdkwin_draw() function.
	tid_clk_refresh = g_timeout_add (CLOCK_REFRESH_RATE, gdkwin_draw, gdkwin);
	
	//Call the GDK window drawing function to draw the first things on the screen
	gdkwin_draw(gdkwin);

	//Try and set focus to our window (so we receive all keyboard events).
	emtk_set_focus_window(window_id);
	
	struct timeval time1;
	gettimeofday(&time1, NULL);
	//Use the microsecond value to seed the random number generator 
	srandom(time1.tv_usec);
	
	//Send a special command to the robot board to turn the LCD on
	if (clk_cfg.forceLCDon == 1)
		system(	"/usr/bin/robot/pipe /tmp/robot_pipe -2 3 0 0 0");
	
	//Every thing is now setup so call emtk. Emtk will run in a forever loop handling the windows
	// (eg sending key events and drawing requests to windows)
		emtk_run ();
	emtk_close ();

	if (tid_clk_refresh) g_source_remove(tid_clk_refresh);

	//Clear any timers that are still running
	for (i=0;i< clk_cfg.num_alarms;i++)
		g_source_remove(clk_cfg.alarms[i]->tid);

	//Need to change cancelling alarms timers (add for loop 1-num_alarms)
	if (log_level >= LOG_LOW)
		printf("Exiting RSMAlarmClock now.....\n");
	return (0);
}

void paintdigits( GdkWindow *gdkwin, GdkGC *gc, timestamp *time_stamp)
{
	int h1,h2,m1,m2;
	int hour = time_stamp->hour;
	int width,height;

	if (clk_cfg.mode24hour == 0){
		if (hour >=12 )
			//draw a 'PM' on Screen
			gdk_draw_text(gdkwin,gdkfont,gc,105, 68,"PM", 2);
		else //draw a 'AM' on Screen
			gdk_draw_text(gdkwin,gdkfont,gc,105, 68,"AM", 2);

		//If time is 00:xx then set display 12:xx
		if (hour == 0)
			hour = 12;
		//If time is  13:xx-23:xx then display 01:xx-12:xx
		if (hour > 12)
			hour -=12;
	}
	//Just extract out the HH:MM digits
	h1 = hour/10;
	h2 = hour%10;
	m1 = time_stamp->minute/10;
	m2 = time_stamp->minute%10;
	if (log_level >= LOG_MED)
	   printf ("Time Numbers are :- %d,%d,:%d,%d\n",h1,h2,m1,m2);

///	GrDrawImageBits (wid,gc,CLOCK_H1_X, 2, pClockChars[h1]);
	width = gdk_pixbuf_get_width (pixbuf[h1]);
	height = gdk_pixbuf_get_height (pixbuf[h1]);
    gdk_pixbuf_render_to_drawable_alpha(pixbuf[h1], gdkwin,
      0, 0, CLOCK_H1_X, CLOCK_TOP,	
      width , height ,
      GDK_PIXBUF_ALPHA_BILEVEL, 128,
      GDK_RGB_DITHER_NORMAL, 0, 0);

	width = gdk_pixbuf_get_width (pixbuf[h2]);
	height = gdk_pixbuf_get_height (pixbuf[h2]);
    gdk_pixbuf_render_to_drawable_alpha(pixbuf[h2], gdkwin,
      0, 0, CLOCK_H2_X, CLOCK_TOP,	
      width , height ,
      GDK_PIXBUF_ALPHA_BILEVEL, 128,
      GDK_RGB_DITHER_NORMAL, 0, 0);

	width = gdk_pixbuf_get_width (pixbuf[m1]);
	height = gdk_pixbuf_get_height (pixbuf[m1]);
    gdk_pixbuf_render_to_drawable_alpha(pixbuf[m1], gdkwin,
      0, 0, CLOCK_M1_X, CLOCK_TOP,	
      width , height ,
      GDK_PIXBUF_ALPHA_BILEVEL, 128,
      GDK_RGB_DITHER_NORMAL, 0, 0);

	width = gdk_pixbuf_get_width (pixbuf[m2]);
	height = gdk_pixbuf_get_height (pixbuf[m2]);
    gdk_pixbuf_render_to_drawable_alpha(pixbuf[m2], gdkwin,
      0, 0, CLOCK_M2_X, CLOCK_TOP,	
      width , height ,
      GDK_PIXBUF_ALPHA_BILEVEL, 128,
      GDK_RGB_DITHER_NORMAL, 0, 0);
      
	//Draw the ":" between the hours and minutes
	gdk_draw_arc(gdkwin,gc,1,CLOCK_COLON_X + 2,CLOCK_TOP +14,
			  5, //width
			  6, //height
			  0, //andgle 1
			  360*64);

	gdk_draw_arc(gdkwin,gc,1,CLOCK_COLON_X + 2,CLOCK_TOP + 35,
			  5, //width
			  6, //height
			  0, //andgle 1
			  360*64);
}

void paint_settime(GdkWindow *gdkwin, GdkGC *gc,enum SET_TIME  settime)
{
	switch(settime){
		case SET_OFF:
		break;
		case SET_HOURS:
		case SET_MINUTES:
		case SET_DAY:
		case SET_MONTH:
		case SET_YEAR:

		gdk_draw_rectangle	 (gdkwin,
			  gc,
			  0,
			  HighLightPostiton[settime-1].x,
			  HighLightPostiton[settime-1].y,
			  HighLightPostiton[settime-1].width,
			  HighLightPostiton[settime-1].height);
			if (log_level >= LOG_MED) printf ("SET Time cords = x=%d,y=%d,w=%d,h=%d\n",HighLightPostiton[settime-1].x,HighLightPostiton[settime-1].y,HighLightPostiton[settime-1].width,HighLightPostiton[settime-1].height);
		break;
	}

}


void paint_date(GdkWindow *gdkwin, GdkGC *gc,timestamp *time_stamp)
{
	static char months[12][5]={"Jan ","Feb ","Mar","Apr","May","Jun","Jul ","Aug","Sep","Oct","Nov","Dec"};
	char date_string[20];
	sprintf (date_string,"%02d %s %d",time_stamp->day,&months[(time_stamp->month)-1][0],time_stamp->year );
	gdk_draw_text(gdkwin,gdkfont,gc,4,68,date_string, strlen(date_string));	

	if (log_level >= LOG_MED) printf ("Date String:-%s\n",date_string);
}

//Returns TRUE if time was changed (and a redraw should be performed)
GR_BOOL changetime(timestamp *newtime,enum SET_TIME settime,GR_KEY key)
{
	GR_BOOL changed = GR_FALSE;
	switch (key)
	{
		case 105: //Up key
			if (settime == SET_HOURS) newtime->hour++;
			if (settime == SET_MINUTES) newtime->minute++;
			if (settime == SET_DAY) newtime->day++;
			if (settime == SET_MONTH) newtime->month++;
			if (settime == SET_YEAR)  newtime->year++;
			changed = GR_TRUE;
			break;
		case 106: //Up key
			if (settime == SET_HOURS) newtime->hour--;
			if (settime == SET_MINUTES) newtime->minute--;
			if (settime == SET_DAY) newtime->day--;
			if (settime == SET_MONTH) newtime->month--;
			if (settime == SET_YEAR)  newtime->year--;
			changed = GR_TRUE;
			break;
		default:
			break;
	}
	//Validate new settings
	//Note need to check for hour and minute =0-1 because minute and hour are unsigned its (do they wont goto -1)
	if (newtime->hour < 0 || newtime->hour == (unsigned int) -1) newtime->hour = 23;
	if (newtime->hour > 23) newtime->hour = 0;
	if (newtime->minute < 0 || newtime->minute == (unsigned int)-1) newtime->minute = 59;
	if (newtime->minute > 59) newtime->minute = 0;
	if (newtime->day > 31) newtime->day = 1;
	if (newtime->day < 1) newtime->day = 31;
	if (newtime->month > 12) newtime->month = 1;
	if (newtime->month < 1) newtime->month = 12;
	return (changed);
}

//DEBUG function- print out the current time plus a diff to a string 
//Paramaters
// str an array of char theat the time/date string will be written into
// diff an int that represents the offset to add/subtract (in seconds)
//Returns 
// A string of format hh:mm:ss dd/mm/yy of the current time + diff 
char *printdifftime(char *str,int diff)
{
	timestamp tstamp;
	struct timeval time2;
	gettimeofday(&time2, NULL);
	time2.tv_sec += diff;
	udf_time_to_stamp(&tstamp, time2.tv_sec, 0);
	if (str) { 
		sprintf(str,"%d:%d:%d %d/%d/%d",tstamp.hour,tstamp.minute,tstamp.second,tstamp.day,tstamp.month,tstamp.year);
		return str;
	}else
	return NULL;
}
