#Stop any exitsing images
killall imageviewer

#Start a new imageview
#use -i 5000 to make it pause for 5 secsonds then es\xit
/usr/bin/robot/imageviewer -c -f $1 &
echo image view started
