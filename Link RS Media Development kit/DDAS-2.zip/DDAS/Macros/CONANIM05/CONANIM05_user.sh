#number of Bcons: 4
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My Macros\Hello Shayne.mp3
#C:\Documents and Settings\Shayne\My Documents\My RS Media\Photo\SHAYNE.jpg
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My BodyCons\I'm Das.bcn
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My Macros\Hello Shayne.mp3
#Start Macro|StartEvent|1|
#SHAYNE.jpg|Action|1|/usr/bin/robot/scripts/display_image.sh "SHAYNE.jpg" 10000 |\Images\actions\display-picture.gif
#Hello Shayne.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "Hello Shayne.mp3" 0 0   |\Images\actions\play-sound.gif
#I'm Das.bcn|Bodycons|1||./I'm Das.bcn|1
#RS2 Burp|Action|1|/usr/bin/robot/send_robot_cmd 0xff 0x05 0x01  0x373 0x00  
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#RS2 Free Roam|Action|1|/usr/bin/robot/send_robot_cmd 0xff 0x05 0x01  0x382 0x00  
#End of Macro|EndEvent|0|
#code section:
#!bash
PATH=/usr/bin/robot/state:/usr/bin/robot/script:$PATH

/usr/bin/robot/scripts/display_image.sh "SHAYNE.jpg" 10000 
/usr/bin/robot/scripts/play_audio_noui.sh "Hello Shayne.mp3" 0 0   
./I'm Das.bcn
/usr/bin/robot/send_robot_cmd 0xff 0x05 0x01  0x373 0x00  
/usr/bin/robot/scripts/clear_screen.sh  
/usr/bin/robot/send_robot_cmd 0xff 0x05 0x01  0x382 0x00  
