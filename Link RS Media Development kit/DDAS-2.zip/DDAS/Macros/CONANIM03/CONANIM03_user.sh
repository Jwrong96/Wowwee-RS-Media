#number of Bcons: 1
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My BodyCons\swim.bcn
#Start Macro|StartEvent|1|
#swim.bcn|Bodycons|1||./swim.bcn|1
#End of Macro|EndEvent|0|
#code section:
#!bash
PATH=/usr/bin/robot/state:/usr/bin/robot/script:$PATH

./swim.bcn
