#number of Bcons: 2
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My Macros\VIDREC name and number.mp3
#C:\Documents and Settings\Shayne\My Documents\My RS Media\My Macros\Thank you.mp3
#Start Macro|StartEvent|1|
#VIDREC name and number.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "VIDREC name and number.mp3" 0 0   |\Images\actions\play-sound.gif
#Track Largest Human Color|Action|1|/usr/bin/robot/scripts/track_color.sh human 5000 |\Images\actions\track-colors.gif
#Record Video For A Given Time|Action|1|/usr/bin/robot/scripts/record_video_start.sh 10000 |\Images\actions\record-stop-movie.gif
#Thank you.mp3|Action|1|/usr/bin/robot/scripts/play_audio.sh "Thank you.mp3" 0 0   |\Images\actions\play-sound.gif
#End of Macro|EndEvent|0|
#code section:
#!bash
PATH=/usr/bin/robot/state:/usr/bin/robot/script:$PATH

/usr/bin/robot/scripts/play_audio_noui.sh "VIDREC name and number.mp3" 0 0   
/usr/bin/robot/scripts/track_color.sh human 5000 
/usr/bin/robot/scripts/record_video_start.sh 10000 
/usr/bin/robot/scripts/play_audio.sh "Thank you.mp3" 0 0   
