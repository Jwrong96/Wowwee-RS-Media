This is a placeholder file and this README file can
be deleted. But do NOT delete the rsmdump directory!
