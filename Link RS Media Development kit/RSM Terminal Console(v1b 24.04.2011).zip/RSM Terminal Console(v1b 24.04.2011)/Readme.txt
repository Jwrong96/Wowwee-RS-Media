Program name: RSM TERMINAL CONSOLE 
Version: V1b
Date: 24.04.2011
Author: Gareth Haylings


INSTALLATION INSTRUCTIONS
=========================
1)Unzip RSM Terminal Console(v1b 24.04.2011).zip

2)From the file unzipped open the INSTALL folder and run �setup.exe�

3)If you intend to connect to you robot via IP address copy the contents of the ROBOT FILES folder to the root of SD card that you use with your RSMEDIA(This contains TINYFTP)




ABOUT "TINYFTP"
===============
Please note Dimitur Kirov wrote the TINYFTP program and it was compiled for the RS Media by Helibot from robocommunity

The link TINYFTP source code is http://sourceforge.net/projects/tinyftp/
I have included the source code for TINYFTP in the EXTRAS folder.




DISCLAIMER
==========
This software is free to download and free use. When installing and using the software you do so at your own risk and no responsibility will be taken by the developer for any damage caused through the installation or use of the software.

