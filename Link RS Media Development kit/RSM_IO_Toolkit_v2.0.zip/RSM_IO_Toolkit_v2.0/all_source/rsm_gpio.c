/****************************************************************************/
//Name  : rsm_gpio.c
//Author: Helibot
//Date  : Feb 2008
//Revised :May 2014
//
//RSMedia IO Toolkit for driving Inputs and Outputs on the Linux Media board
//
//This tookit allows setup of GPIO (General Purpose IO) pins for the RS Media Robot
//It does this by supplying functions to allow pins to be setup, change outputs and read inputs.
//It is written to run under linux and use the 'hwb' character device.
//'hwb' is a hardware bridge device driver for linux.
//'hwb' allows user mode programs to write/read from the MC9328MXL processor registers.
//To use the 'hwb' device the program must open '/tmp/hwb' device.
//
//The hardware bridge driver can be loaded by 'insmod hwb.o' from linux command line
//A linux 'special file' must also be created.  use 'mknod /tmp/hwb c 252 0'
////
//The tooklit functions provided aim to hide most implementation from the main program
//To initialise an GPIO signal as an input call
//	setupGPIO_Input(dev,pinNum);
//To read the input call
//  readGPIO(dev,pinNum)
//
//To setup a pin as a output call
//  setupGPIO_Output(dev,pinNum,value)
//To set an output to high or low call 
//  setGPIO(dev,value)
/****************************************************************************/

#include <stdio.h>
#include <fcntl.h>

//Must have kernel sources available to include the next include file.
//#include <asm/arch/hardware.h>  //But seems this is now not required to compile!

#include "rsm_gpio.h"


#define	CMD_READ	0
#define	CMD_WRITE	1

int debug = 0;  //Set to 1 to enable printing of debug to console/std out.

struct
{
	unsigned long	addr;
	unsigned long	data;
	unsigned char	command;		// 0 = read, 1 = write
} hwb_command;

unsigned long readreg(int dev,unsigned long addr)
{
	unsigned long data = 0;
	hwb_command.addr = addr;
	hwb_command.data = 0L;
	hwb_command.command = CMD_READ;
	//if (dev)
		//return 0;

	write(dev, (void *)&hwb_command, sizeof(hwb_command));
	read(dev, (void *)&data, sizeof(data));
	//printf ("regread() = (0x%08x) : 0x%08x\n",addr,data);    
	return data;
}

void writereg(int dev,unsigned long addr,unsigned long data)
{
	hwb_command.addr = addr;
	hwb_command.data = data;
	hwb_command.command = CMD_WRITE;
	if (dev)
		write(dev, (void *)&hwb_command, sizeof(hwb_command));
	return;
}

void dumpregs (int dev)
{
	printf("GPIO_DDIR (0x%08X) = 0x%08X\n",GPIO_DDIR,readreg(dev,GPIO_DDIR));
	printf("GPIO_OCR1 (0x%08X) = 0x%08X\n",GPIO_OCR1,readreg(dev,GPIO_OCR1));
	printf("GPIO_OCR2 (0x%08X) = 0x%08X\n",GPIO_OCR2,readreg(dev,GPIO_OCR2));
	printf("GPIO_DR (0x%08X) = 0x%08X\n",GPIO_DR,readreg(dev,GPIO_DR));
	printf("GPIO_GIUS (0x%08X) = 0x%08X\n",GPIO_GIUS,readreg(dev,GPIO_GIUS));
	printf("GPIO_SSR (0x%08X) = 0x%08X\n",GPIO_SSR,readreg(dev,GPIO_SSR));
	printf("GPIO_PUEN (0x%08X) = 0x%08X\n",GPIO_PUEN,readreg(dev,GPIO_PUEN));
}

void setupGPIO_Input(int dev,int pinNum)
{
	unsigned long data ,data2;
	//Set bits in GPIO InUse register
	data = readreg(dev,GPIO_GIUS);
	if (debug) printf ("Read GPIO_GIUS = 0x%08X\n",data);	
	//Set bits to one to make OutPuts
	data = data | (	1>>pinNum);
	if (debug) printf ("Write GPIO_GIUS as 0x%08X\n",data);
	writereg(dev,GPIO_GIUS,data);

	//Set bits in DDIR to be Outputs (clear a bit to make it an input)
	data = readreg(dev,GPIO_DDIR);
	if (debug) printf ("Read GPIO_DDIR = 0x%08X\n",data);
	//Set bits to one to make OutPuts	
	data = data & ~(1<<pinNum);
	if (debug) printf ("Write GPIO_DDIR as 0x%08X\n",data);
	writereg(dev,GPIO_DDIR,data);

	//Set bits in PuulUpEnable Reg (set a 1 to enable the pull up resistors (for both input & outputs))
	data = readreg(dev,GPIO_PUEN);
	if (debug) printf ("Read GPIO_PUEN = 0x%08X\n",data);
	//Set bits to one to enable Pullup resistors	
	data = data | 1<<pinNum;
	if (debug) printf ("Write GPIO_PUEN as 0x%08X\n",data);
	writereg(dev,GPIO_PUEN,data);
}

void setupGPIO_Output(int dev,int pinNum,int value)
{
	unsigned long data ,data2;
	//Set bits in GPIO InUse register
	data = readreg(dev,GPIO_GIUS);
	if (debug) printf ("Read GPIO_GIUS = 0x%08X\n",data);	
	//Set bits to one to make OutPuts
	data = data | (	1>>pinNum);
	if (debug) printf ("Write GPIO_GIUS as 0x%08X\n",data);
	writereg(dev,GPIO_GIUS,data);

  //Configure Output bits in the OutConfReg1&2 to be set by Data Reg
	if(pinNum < 16)
	{
		data = readreg(dev,GPIO_OCR1);
		if (debug) printf ("Read GPIO_OCR1 = 0x%08X\n",data);
		//Set bits 2*pinNum + 2*pinNum -1 to 1 to make output be set by value in DataReg
		data = data | (1<<((2*pinNum)+1)) | (1<<(2*pinNum));
		if (debug) printf ("Write GPIO_OCR1 as 0x%08X\n",data);
		writereg(dev,GPIO_OCR1,data);
	}else if (pinNum >=16)
	{
		data = readreg(dev,GPIO_OCR2);
		//printf ("Read GPIO_OCR2 = 0x%08X\n",data);
		//Set bits (2*pinNum-32) + (2*pinNum-32) -1 to 1 to make output be set by value in DataReg
		data = data | (1<<((2*pinNum-32)+1)) |(1<<(2*pinNum-32));
		if (debug) printf ("Write GPIO_OCR2 as 0x%08X\n",data);
		writereg(dev,GPIO_OCR2,data);
	}		

	//Set bits in DDIR to be Outputs (set each bit to make it an output)
	data = readreg(dev,GPIO_DDIR);
	if (debug) printf ("Read GPIO_DDIR = 0x%08X\n",data);
	//Set bits to one to make OutPuts	
	data = data | 1<<pinNum;
	if (debug) printf ("Write GPIO_DDIR as 0x%08X\n",data);
	writereg(dev,GPIO_DDIR,data);

	//Set bits in PuulUpEnable Reg (set a 1 to enable the pull up resistors (for both input & outputs))
	data = readreg(dev,GPIO_PUEN);
	if (debug) printf ("Read GPIO_PUEN = 0x%08X\n",data);
	//Set bits to one to enable Pullup resistors	
	data = data | 1<<pinNum;
	if (debug) printf ("Write GPIO_PUEN as 0x%08X\n",data);
	writereg(dev,GPIO_PUEN,data);


	//Finially set the bits in DR to high or low (set 1 to make the output high)
	data = readreg(dev,GPIO_DR);
	if (debug) printf ("Read GPIO_DR = 0x%08X\n",data);
	if (value == 0)
	{
		//Set bits to zero to turn outputs OFF	
		data = data & ~(1<<pinNum);
	} else
	{
		//Set bits to 1 to turn outputs On
		data = data | (1<<pinNum);
	}
	if (debug) printf ("Write GPIO_DR as 0x%08X\n",data);
	writereg(dev,GPIO_DR,data);
		
}

void setGPIO(int dev,int pinNum, int value)
{
	unsigned long data,orig_data;
	data = readreg(dev,GPIO_DR);
	//printf ("Read GPIO_DR = 0x%08X\n",data);
	if (value == 0 )
	{
		//Set bits to zero to turn outputs OFF	
		data = data & ~(1<<pinNum);
	} else
	{
		//Set bits to 1 to turn outputs On
		data = data | (1<<pinNum);
	}
	writereg(dev,GPIO_DR,data);
}

int readGPIO(int dev,int pinNum)
{
	unsigned long data;
	data = readreg(dev,GPIO_SSR);
	if (data & (1<<pinNum))
		return 1;
	else
		return 0;
}
