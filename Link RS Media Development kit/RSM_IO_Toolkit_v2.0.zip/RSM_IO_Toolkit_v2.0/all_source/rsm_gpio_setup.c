/****************************************************************************/
//Name  : rsm_gpio_setup.c
//Author: Helibot
//Date  : May 2014
//
//This file is a simple programn to configure a I/O pin for RSMedia
//The command agrguements specify the PIN to setup , whether is an input or an output.
//If its an output then you need to also specify the initial value to be 0 (low) or 1(high)
//This code uses the functions in rsm_gpio.c to setup and use 
//GPIO (General Purpose I/O) pins for the RS Media Robot
//See rsm_gpio.h for function descriptions.
//
//The user program must open the "/tmp/hwb" device then pass the handle returned
// as the first arg to all rsm_gpio functions.
/****************************************************************************/

#include <stdio.h>
#include <fcntl.h>

#include "rsm_gpio.h"

int check_pin(char *str);

int main (int argc, char *argv[])
{
	int hwb;
	char *pAddrStr;
	int pin,direction,value;

	if (argc != 3 && argc != 4)
	{
		printf("Invalid Args - use rsm_gpio_setup PIN_NAME [I|O] [0|1]\n");
		return 0;
	}
	//Call func to get the number for the pin from the string provided
	pAddrStr=argv[1];
	pin = check_pin(pAddrStr);
	printf ("Pin = %d\n",pin);			
	if (pin==0) {
		printf("Invalid Pinname %s\n",pAddrStr);
		return 0;
	}

	//Check parameter 2 to check it is "I" or "O".
	direction = -1;
	if (strcmp(argv[2],"I")==0) direction = 0; //0=input			
	if (strcmp(argv[2],"O")==0) direction = 1; //1=output			
	if (direction == -1) {
		printf("Invalid direction %s. Must be either I or O\n",argv[2]);
		return 0;
	}		

	//Check parameter 3 to check it is "0" or "1".
	if (direction == 1) //Only need value we are setting up an output
	{
		value = -1;
		if (strcmp(argv[3],"0")==0) value = 0;
		if (strcmp(argv[3],"1")==0) value = 1;
		if (value == -1) {
			printf("Invalid value %s. Must be either 0 or 1\n",argv[3]);
			return 0;
		}
	}

	if ((hwb = open("/dev/hwb", O_RDWR)) < 0)          
	{                                                 
		if ((hwb = open("/tmp/hwb", O_RDWR)) < 0)        
		{                                               
			printf("H/W bridge open error !\n");
			printf("Have you installed the hardware bridge driver??\n");
			printf("Use insmod hwb.o\n");          
			printf("Have you made the /tmp/hwb node in /tmp??\n");
			printf("Use mknod /tmp/hwb c 252 0\n");          
			return -1;                                    
		}                                               
	}

	if (direction == 1)  {//Output
		setupGPIO_Output(hwb,pin,value);
		printf("Setup PD%d as output\n",pin);
	}
	else	{//input
		setupGPIO_Input(hwb,pin);
		printf("Setup PD%d as input\n",pin);
	}

	close(hwb);

	return 1;
}

struct tPin_name
{
	char name[6];
	int	value;
};

struct tPin_name pinname_lookup[] = {
{"J11_9",11},
{"J11_12",17},
{"J11_14",19},
{"J11_15",20},
{"J11_16",21},
{"J11_21",26},
{"J11_1",6},
{"J11_2",7},
{"J11_5",8},
{"J11_4",9},
{"J11_3",10},
{"J11_8",12},
{"J11_7",13},
{"J11_6",14},
{"J11_10",15},
{"J11_11",16},
{"J11_13",18},
{"J11_17",22},
{"J11_18",23},
{"J11_19",24},
{"J11_20",25},
{"J11_22",27},
{"J11_23",28},
{"J11_24",29},
{"J11_25",30},
{"T25",31},
{"PD6",6},
{"PD7",7},
{"PD8",8},
{"PD9",9},
{"PD10",10},
{"PD11",11},
{"PD12",12},
{"PD13",13},
{"PD14",14},
{"PD15",15},
{"PD16",16},
{"PD17",17},
{"PD18",18},
{"PD19",19},
{"PD20",20},
{"PD21",21},
{"PD22",22},
{"PD23",23},
{"PD24",24},
{"PD25",25},
{"PD26",26},
{"PD27",27},
{"PD28",28},
{"PD29",29},
{"PD30",30},
{"PD31",31}
};

int check_pin(char *str)
{
	int i = 0;
	int max = sizeof(pinname_lookup)/sizeof(pinname_lookup[0]);
	for (i=0; i<max;i++) {
		//printf ("%s = %d\n",pinname_lookup[i].name,pinname_lookup[i].value);
		if (strcmp(pinname_lookup[i].name,str)==0) break;
	}
	return pinname_lookup[i].value;
}

