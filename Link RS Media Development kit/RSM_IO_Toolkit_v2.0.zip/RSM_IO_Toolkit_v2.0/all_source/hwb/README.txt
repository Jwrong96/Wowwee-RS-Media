HWB
===
NOTE that hwb.c was compiled in the Freescale Redhat 7.3 Linux VMWARE virtual machine.
It's probably possible to install these into another linux and complete compile but would require some fiddling.
There should really be any need to recompile this hwb.o though.

Note that to compile the hwb.c in the Redhat virtual machine then you need to extract the kernel source files first.
Follow these instructions:-
cd /home/vm_user/BSP/MX1/mx1_rel_0.3.8/Kernel
tar -x -z -f Source/Kernel.tgz
chmod -R u+=r Source

When compiling against the kernel source (eg making a loadable kernel module) then ensure that the makefile INCLUDE points to the new kernel sources.
INCLUDE := /home/vm_user/BSP/MX1/mx1_rel_0.3.8/Kernel/Source/include

See the include Makefile for example (hwb.c is currently commented out though!)

Kernel source files are only required when compiling the hwb.o file.
Other files do not require kernel sources.

UTILITIES
=========
This folder also contains two utilities for the hwb.
'regread' and 'regwrite' can be used to read any processor register.
For example you can use the 'regread' utility to read the realtime clock register
(It should get a different result every time you run the command ,since the realtime clock counter changes every second)

./regread 204004 
(0xf0204004) : 0x00000039

Regread and regwrite are useful for debugging programs that manipulate the microprocessor registers.
 