#include <stdio.h>
#include <fcntl.h>

#define	CMD_READ	0
#define	CMD_WRITE	1

struct
{
	unsigned long	addr;
	unsigned long	data;
	unsigned char	command;		// 0 = read, 1 = write
} hwb_command;

unsigned char HexChar2Num(char c)
{
	// convert to upper case if necessary
	if (c > 'F')
		c -= ('a'-'A');

	if (c > '9')
		return (c - 'A' + 10);
	else
		return (c - '0');
}

int main (int argc, char *argv[])
{
	int hwb;
	unsigned long addr;
	char *pAddrStr, *pCountStr;
	long data, wordCount, i;

	if ((argc < 2) || (argc > 3))
	{
		printf("regread address [word count]\n");
		return -1;
	}

	if ((hwb = open("/dev/hwb", O_RDWR)) < 0)
	{
		if ((hwb = open("/tmp/hwb", O_RDWR)) < 0)
		{
			printf("H/W bridge open error !\n");
			return -1;
		}
	}

	addr = 0;
	pAddrStr = argv[1];
	if (*pAddrStr == '0')
	{
		pAddrStr += 2;
	}
	while (*pAddrStr > 0)
		addr = (addr << 4) | HexChar2Num(*(pAddrStr++));

	wordCount = 1;
	if (argc == 3)	// need to extract word count
	{
		wordCount = 0;
		pCountStr = argv[2];
		if (*pCountStr == '0')
		{
			pCountStr += 2;
		}
		while (*pCountStr > 0)
			wordCount = (wordCount << 4) | HexChar2Num(*(pCountStr++));
	}
    
//
	printf("read address: 0x%08x\n", addr);
	for (i=0; i<wordCount; i++)
	{
		hwb_command.addr = addr;
		hwb_command.command = CMD_READ;
		write(hwb, (void *)&hwb_command, sizeof(hwb_command));

		read(hwb, (void *)&data, sizeof(data));
	   		
		printf("(0x%08x) : 0x%08x\n", addr, data);
		addr += 4;
	}
  printf("done\n");

	close(hwb);
	return 0;
}
