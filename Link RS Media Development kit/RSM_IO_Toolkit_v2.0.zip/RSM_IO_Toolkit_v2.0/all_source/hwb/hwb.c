#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/arch/hardware.h>


#define	HWB_MAJOR	252
#define HWB_NAME "hwb"

#define	CMD_READ	0
#define	CMD_WRITE	1

// functions and interface
int hwb_open(struct inode *inode, struct file *filp);
int hwb_release(struct inode *inode, struct file *filp);
ssize_t hwb_read(struct file *filp, char *buf, size_t size, loff_t *l);
ssize_t hwb_write(struct file *filp, const char *buf, size_t size, loff_t *l);

struct file_operations hwb_fops = {
	open:          hwb_open,
	release:       hwb_release,
	read:          hwb_read,
	write:			hwb_write,
};

unsigned long	dataToReturn;

typedef struct
{
	unsigned long	addr;
	unsigned long	data;
	unsigned char	command;		// 0 = read, 1 = write
} hwb_command_t;

int hwb_open(struct inode *inode, struct file *filp)
{
	MOD_INC_USE_COUNT;
	return 0;
}

int hwb_release(struct inode *inode, struct file *filp)
{
	MOD_DEC_USE_COUNT;
	return 0;
}

ssize_t hwb_read(struct file *filp, char *buf, size_t size, loff_t *l)
{
	*((unsigned long *)buf) = dataToReturn;
	return size;
}

ssize_t hwb_write(struct file *filp, const char *buf, size_t size, loff_t *l)
{
	hwb_command_t	*p;

	p = (hwb_command_t *)buf;
	if (p->command == CMD_READ)
	{
//		printk("Read register 0x%08x\n", (int)(p->addr));
//		printk("\nhwb-Read reg PA=0x%08x,VA=0x%08x\n",(int)(p->addr),(int)(IO_ADDRESS(p->addr)));
		
		dataToReturn = *((unsigned long *)(IO_ADDRESS(p->addr)));
	}
	else
	{
//	printk("\nhwb-Write reg 0x%08x = 0x%08x\n", (int)(p->addr), (int)(p->data));
		*((unsigned long *)(IO_ADDRESS(p->addr))) = p->data;
	}
	return size;
}

int init_module()
{
	int result;
	
	/* register our character device */		
	result = register_chrdev(HWB_MAJOR, HWB_NAME, &hwb_fops);
	
    if (result < 0)
    {
        printk(KERN_WARNING "hwbrdge: unable to get major %d\n", HWB_MAJOR);
        return result;
    }
    else
    {
        printk("make node for hwbridge with 'mknod %s c %d 0'\n",HWB_NAME, HWB_MAJOR);
 	 	}
    return 0;
}

void cleanup_module()
{
	printk("Freed resources: MOD_IN_USE = %d\n", MOD_IN_USE); 
	unregister_chrdev(HWB_MAJOR, HWB_NAME);
	printk("Unregistered device hwb: major %d\n",HWB_MAJOR);
}
