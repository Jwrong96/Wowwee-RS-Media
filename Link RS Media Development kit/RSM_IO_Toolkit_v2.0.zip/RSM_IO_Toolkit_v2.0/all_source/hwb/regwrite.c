#include <stdio.h>
#include <fcntl.h>

#define	CMD_READ		0
#define	CMD_WRITE	1

struct
{
	unsigned long	addr;
	unsigned long	data;
	unsigned char	command;		// 0 = read, 1 = write
} hwb_command;

unsigned char HexChar2Num(char c)
{
	// convert to upper case if necessary
	if (c > 'F')
		c -= ('a'-'A');

	if (c > '9')
		return (c - 'A' + 10);
	else
		return (c - '0');
}

int main (int argc, char *argv[])
{
	int hwb;
	unsigned long addr;
	char *pAddrStr, *pValueStr;
	long data;

	if (argc != 3)
	{
		printf("regwrite address value\n");
		return 0;
	}

	if ((hwb = open("/dev/hwb", O_RDWR)) < 0)
	{
		if ((hwb = open("/tmp/hwb", O_RDWR)) < 0)
		{
			printf("H/W bridge open error !\n");
			return 0;
		}
	}

	addr = 0;
	pAddrStr = argv[1];
	if (*pAddrStr == '0')
	{
		pAddrStr += 2;
	}
	while (*pAddrStr > 0)
		addr = (addr << 4) | HexChar2Num(*(pAddrStr++));

	data = 0;
	pValueStr = argv[2];
	if (*pValueStr == '0')
	{
		pValueStr += 2;
	}
	while (*pValueStr > 0)
		data = (data << 4) | HexChar2Num(*(pValueStr++));

	hwb_command.addr = addr;
	hwb_command.data = data;
	hwb_command.command = CMD_WRITE;
	printf ("addr = 0x%08x , val = 0x%08x\n",hwb_command.addr,hwb_command.data);
	write(hwb, (void *)&hwb_command, sizeof(hwb_command));
  printf ("Write Done\n");
	close(hwb);
	return 0;
}
