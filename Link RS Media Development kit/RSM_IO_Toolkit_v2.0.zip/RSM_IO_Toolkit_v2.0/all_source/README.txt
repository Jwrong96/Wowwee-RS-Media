This folder contains all the source code for all programs in the RSM IO Toolkit.

All programs can be compiled in the RSM DevKit (As available here http://sourceforge.net/projects/rsmediadevkit/files/RSMDev1.5/)
Extract all files into directory .../src_robot/rsmiotoolkit and then cd to the directory and execute
make
All programs should be successfully built.

NOTE that hwb.c was compiled in the Redhat 7.3 VM from Freescale. 
It requires the Kernel headers to be extracted before it can be built.
It's probably possible to install these into another linux and complete the compile but it would require some fiddling.
There should not really be any need to recompile hwb.o the one supplied should work for all RSMedias.
