/****************************************************************************/
//Name  : rsm_gpio.h
//Author: Helibot
//Date  : Feb 2008
//
//RSMedia IO Toolkit for driving Inputs and Outputs on the Linux Media board
//
//This tookit allows setup of GPIO (General Purpose IO) pins for the RS Media Robot
//It does this by supplying functions to allow pins to be setup, change outputs and read inputs.
//It is written to run under linux and use the 'hwb' character device.
//'hwb' is a hardware bridge device driver for linux.
//'hwb' allows user mode programs to write/read from the MC9328MXL processor registers.
//To use the 'hwb' device the program must open '/tmp/hwb' device.
//
//The hardware bridge driver can be loaded by 'insmod hwb.o' from linux command line
//A linux 'special file' must also be created.  use 'mknod /tmp/hwb c 252 0'
////
//The tooklit functions provided aim to hide most implementation from the main program
//To initialise an GPIO signal as an input call
//	setupGPIO_Input(dev,pinNum);
//To read the input call
//  readGPIO(dev,pinNum)
//
//To setup a pin as a output call
//  setupGPIO_Output(dev,pinNum,value)
//To set an output to high or low call 
//  setGPIO(dev,value)
/****************************************************************************/


//Set GPIO_BASE_ADDR to MC9328MXL GPIO Port D
#define GPIO_BASE_ADDR	0x0021C300

//Define GPIO configuration regisers for the MC9328MXL
#define GPIO_DDIR			GPIO_BASE_ADDR+0x00  //  32bit gpio data direction reg
#define GPIO_OCR1			GPIO_BASE_ADDR+0x04  //  32bit gpio output config 1 reg
#define GPIO_OCR2			GPIO_BASE_ADDR+0x08  //  32bit gpio output config 2 reg
#define GPIO_ICONFA1	GPIO_BASE_ADDR+0x0C  //  32bit gpio input config A1 reg
#define GPIO_ICONFA2	GPIO_BASE_ADDR+0x10  //  32bit gpio input config A2 reg
#define GPIO_ICONFB1	GPIO_BASE_ADDR+0x14  //  32bit gpio input config B1 reg
#define GPIO_ICONFB2	GPIO_BASE_ADDR+0x18  //  32bit gpio input config B2 reg
#define GPIO_DR				GPIO_BASE_ADDR+0x1C  //  32bit gpio data reg
#define GPIO_GIUS			GPIO_BASE_ADDR+0x20  //  32bit gpio in use reg
#define GPIO_SSR			GPIO_BASE_ADDR+0x24  //  32bit gpio sample status reg
#define GPIO_ICR1			GPIO_BASE_ADDR+0x28  //  32bit gpio interrupt ctrl 1 reg
#define GPIO_ICR2			GPIO_BASE_ADDR+0x2C  //  32bit gpio interrupt ctrl 2 reg
#define GPIO_IMR			GPIO_BASE_ADDR+0x30  //  32bit gpio interrupt mask reg
#define GPIO_ISR			GPIO_BASE_ADDR+0x34  //  32bit gpio interrupt status reg
#define GPIO_GPR			GPIO_BASE_ADDR+0x38  //  32bit gpio general purpose reg
#define GPIO_SWR			GPIO_BASE_ADDR+0x3C  //  32bit gpio software reset reg
#define GPIO_PUEN			GPIO_BASE_ADDR+0x40  //  32bit gpio pull up enable reg

//Define the RSMedia media Circuit board pads to be the correct PORT D GPIO bits
//This group of Pads are available on the TOP of the RSMedia board
//These have all been confirmed to be correct and available for reuse as IO 
#define J11_9  11 //(=PD11 = Bit 11 in GPIO config regs)
#define J11_12 17 //(=PD17 = Bit 17 in GPIO config regs)
#define J11_14 19 //(=PD19 = Bit 19 in GPIO config regs)
#define J11_15 20 //(=PD20 = Bit 20 in GPIO config regs)
#define J11_16 21 //(=PD21 = Bit 21 in GPIO config regs)
#define J11_21 26 //(=PD26 = Bit 26 in GPIO config regs)
//This group of Pads are available on the bottom of the RSMedia board
//These have not been confirmed (by the author) to be correct and available for reuse
//as inputs or outputs
#define J11_1 6   //(=PD6 = Bit 6 in GPIO config regs)
#define J11_2 7   //(=PD7 = Bit 7 in GPIO config regs) 
#define J11_5 8   //(=PD8 = Bit 8 in GPIO config regs)
#define J11_4 9   //(=PD9 = Bit 9 in GPIO config regs)
#define J11_3 10  //(=PD10 = Bit 10 in GPIO config regs)
#define J11_8 12  //(=PD12 = Bit 12 in GPIO config regs)
#define J11_7 13  //(=PD13 = Bit 13 in GPIO config regs)
#define J11_6 14  //(=PD14 = Bit 14 in GPIO config regs)
#define J11_10 15 //(=PD15 = Bit 15 in GPIO config regs)
#define J11_11 16 //(=PD16 = Bit 16 in GPIO config regs)
#define J11_13 18 //(=PD18 = Bit 18 in GPIO config regs)
#define J11_17 22 //(=PD22 = Bit 22 in GPIO config regs)
#define J11_18 23 //(=PD23 = Bit 23 in GPIO config regs)
#define J11_19 24 //(=PD24 = Bit 24 in GPIO config regs)
#define J11_20 25 //(=PD25 = Bit 25 in GPIO config regs)
#define J11_22 27 //(=PD27 = Bit 27 in GPIO config regs)
#define J11_23 28 //(=PD28 = Bit 28 in GPIO config regs)
#define J11_24 29 //(=PD29 = Bit 29 in GPIO config regs)
#define J11_25 30 //(=PD30 = Bit 30 in GPIO config regs)
#define T25 31    //(=PD31 = Bit 31 in GPIO config regs)

//OR use the PDxx pin definitions for the port number
#define PD6 6   // Bit 6 in GPIO config regs)
#define PD7 7   // Bit 7 in GPIO config regs)
#define PD8 8   // Bit 8 in GPIO config regs)
#define PD9 9   // Bit 9 in GPIO config regs)
#define PD10 10 // Bit 10 in GPIO config regs)
#define PD11 11 // Bit 11 in GPIO config regs)
#define PD12 12 // Bit 12 in GPIO config regs)
#define PD13 13 // Bit 13 in GPIO config regs)
#define PD14 14 // Bit 14 in GPIO config regs)
#define PD15 15 // Bit 15 in GPIO config regs)
#define PD16 16 // Bit 16 in GPIO config regs)
#define PD17 17 // Bit 17 in GPIO config regs)
#define PD18 18 // Bit 18 in GPIO config regs)
#define PD19 19 // Bit 19 in GPIO config regs)
#define PD20 20 // Bit 20 in GPIO config regs)
#define PD21 21 // Bit 21 in GPIO config regs)
#define PD22 22 // Bit 22 in GPIO config regs)
#define PD23 23 // Bit 23 in GPIO config regs)
#define PD24 24 // Bit 24 in GPIO config regs)
#define PD25 25 // Bit 25 in GPIO config regs)
#define PD26 26 // Bit 26 in GPIO config regs)
#define PD27 27 // Bit 27 in GPIO config regs)
#define PD28 28 // Bit 28 in GPIO config regs)
#define PD29 29 // Bit 29 in GPIO config regs)
#define PD30 30 // Bit 30 in GPIO config regs)
#define PD31 31 // Bit 31 in GPIO config regs)

extern unsigned long readreg(int dev,unsigned long addr);

extern void writereg(int dev,unsigned long addr,unsigned long data);

extern void dumpregs (int dev);

extern void setupGPIO_Input(int dev,int pinNum);

extern void setupGPIO_Output(int dev,int pinNum,int value);

extern void setGPIO(int dev,int pinNum, int value);

extern int readGPIO(int dev,int pinNum);
