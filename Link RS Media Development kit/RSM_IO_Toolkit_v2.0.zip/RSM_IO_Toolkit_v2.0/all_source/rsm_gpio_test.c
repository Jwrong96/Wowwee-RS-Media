/****************************************************************************/
//Name  : rsm_gpio_test.c
//Author: Helibot
//Date  : Feb 2008
//Revised : May 2014
//
//This file is a simple example program to exercise the rsm_gpio functions.
//This code uses the functions in rsm_gpio.c to setup and use 
//GPIO (General Purpose I/O) pins for the RS Media Robot
//See rsm_gpio.h for function descriptions.
//
//The user program must open the "/tmp/hwb" device then pass the handle returned
// as the first arg to all rsm_gpio functions.
/****************************************************************************/

#include <stdio.h>
#include <fcntl.h>

#include "rsm_gpio.h"

int main()
{
	int hwb,i=0;
	
	if ((hwb = open("/dev/hwb", O_RDWR)) < 0)          
	{                                                 
		if ((hwb = open("/tmp/hwb", O_RDWR)) < 0)        
		{                                               
			printf("H/W bridge open error !\n");
			printf("Have you installed the hardware bridge driver??\n");
			printf("Use insmod hwb.o\n");          
			printf("Have you made the /tmp/hwb node in /tmp??\n");
			printf("Use mknod /tmp/hwb c 252 0\n");          
			return -1;                                    
		}                                               
	}

	//printf("\n**Reading some Port D Register values:-  **\n");
	//dumpregs(hwb);
	
	printf("\n**Setting up 1 input & 4 oputputs in RSM GPIO Port D Registers **\n");
	setupGPIO_Output(hwb,PD11,0);
	setupGPIO_Output(hwb,PD17,0);
	setupGPIO_Input(hwb,PD19);
	setupGPIO_Output(hwb,PD20,0);
	setupGPIO_Output(hwb,PD21,0);
	printf("**Setup Done**\n");

	//printf("\n**Reading some Port D Register values:-  **\n");
	//dumpregs(hwb);

	//The following test code toggles the state of PD11 output between 0 and 1 every second
	//It also prints the input value from PD19
	while (i<10)
	{
		setGPIO(hwb,PD11,1);
		printf("PD11out = 1; PD19in = %d\n",readGPIO(hwb,PD19));	
		sleep(1);
		setGPIO(hwb,PD11,0);
		printf("PD11out = 0; PD19in = %d\n",readGPIO(hwb,PD19));	
		sleep(1);
		i++;
	}

	close(hwb);
	return 0;
}
