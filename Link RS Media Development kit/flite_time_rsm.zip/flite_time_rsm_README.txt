This document describes how to run the  flite_time_rsm program for RSMedia robot.
Flite_time is a program that will speak the time in a human friendly format.
For example the command line
./flite_time_rsm 11:03
rsults in RSMedia staying "The time is just past 11 oclock in the morning"

./flite_time_rsm 12:00
results in RSMedia staying " The time is exactly midday"

The voice used is better quality than flite_rsm_1.3,  it sounds very natural.

Installation
========
1)Unzip the archive to a directory on the PC.
2)Copy the flite_time_rsm binary to an SD card Application directory. EG
copy flite_time_rsm  <SD CARD DRIVE>:/Application
3)Put the card in the RSM Media and boot the robot.

Running flite_rsm on RSMedia
=======================
4)Activate the usb console (or serial hack) so you have a linux command line.
5)change to the application directory
  >cd /mnt/sd/Application
and run the program
  >./flite_time_rsm 22:09
 This should create a wav output and play it to the RSM speakers.

Have fun!!

For details about how Flite is recompiled for RSMedia see http://rsmediadevkit.svn.sourceforge.net/viewvc/rsmediadevkit/text_to_speech/flite-1.3/

Helibot 
Jan 2010