This document describes how to run the  flite_rsm program for RSMedia robot.
Flite is a simple Text to Speech converter.
Helibot recompiled the flite V1.0 to work with RSMedia. The recompiled version is flite_rsm.

Installation
========
1)Unzip the archive to a directory on the PC.
2)Copy the flite_rsm binary to an SD card Application directory. EG
copy flite_rsm <SD CARD DRIVE>:/Application
  Optionally you can also copy the play_wave binary to the SD card Application directory.
3)Put the card in the RSM Media and boot the robot.

Running flite_rsm on RSMEdia
=======================
4)Activate the usb console (or serial hack) so you have a linux command line.
5)change to the application directory
  >cd /mnt/sd/Application
and run the program
  >./flite_rsm -t "hello world"
 This should create a wav file for "hello world" and play it to the RSM speakers.

6) You can also create it as a wav file using
  >./flite_rsm -t "hello world" /tmp/output.wav
  You will then need the play_wave binary to play it back.  Use command
 >./play_wave /tmp/output.wav.
You could also copy the outpout.wav file to the SD card then play it on the PC.

Note that if you try to play the output.wav file using the RSMedia audioplayer (eg with /usr/bin/robot/audioplayer -f /tmp/output.wav)  then it will play at double speed. (Because the wav file generated is a mono file, RSMedia audioplayer will treat it as stereo and end up playing it a x 2 speed).

Have fun!!

Helibot 
Dec 2009