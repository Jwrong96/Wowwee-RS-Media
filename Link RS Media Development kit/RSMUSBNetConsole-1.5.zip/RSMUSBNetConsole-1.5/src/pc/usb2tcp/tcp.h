/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: tcp.h
 * Description 	: TCP/IP socket management
 * Authors		: Christophe Buguet (cbuguet@users.sourceforge.net)
 *				  Gerald Villemure (gvillemure@users.sourceforge.net)
 *
 * $Id: tcp.h,v 1.1 2004/09/09 19:58:57 cbuguet Exp $
 */

#ifndef _TCP_H_
#define _TCP_H_

#include <winsock.h>

/* Constants */
#define WSA_ACCEPT				0
#define WSA_READ				1
#define WSA_WRITE				2

/* Global vars */
SOCKET	g_sockServer;

/* Functions */
int		InitWinsock(void);
int		CloseWinsock(void);
int		StartTcpSocket(char *sIFace, unsigned short iPort, HWND hWnd);

BOOL	AcceptConnection(SOCKET *cl_sock);
BOOL	CloseConnection(SOCKET *cl_sock);

int		ReadSocketData(SOCKET *cl_sock, char *sData, int iMaxSize);
int		WriteSocketData(SOCKET *cl_sock, char *sData, int iSize);


#endif /* _TCP_H_ */