/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: usb.h
 * Description 	: USB port management functions
 * Authors		: Helibot 2009
 *
 */

#ifndef _USB_H_
#define _USB_H_


/* the device's vendor and product id */
#define MY_VID 0x425  //RSMEDIA USBSERIAL MODE
#define MY_PID 0xA0

//#define MY_VID 0xC45	//USB Flexible Camera
//#define MY_PID 0x6005

/* the device's endpoints */
#define EP_IN 0x81
#define EP_OUT 0x02

#define BUF_SIZE 32

/* Win32 messages */
#define USB_READ	3
#define USB_WRITE	4

/* Error codes */
#define SPERR_OK 0
#define SPERR_FAIL -1

/* Buffer sizes */
#define INPUT_BUFFER_SIZE 1024
#define OUTPUT_BUFFER_SIZE 1024

/* Functions */
void	DisposeUsb(void);

int		OpenUsb(int iUsbvid,int iUsbpid);

int		ReadBytes(LPCSTR *lpszBuffer, int iSize);
int		WriteBytes(LPCSTR lpszBuffer, int iSize);


/* Extern vars */
//extern OVERLAPPED	ovRead, ovWrite;

extern OVERLAPPED usbGetOverlappedUSBRead();
extern OVERLAPPED usbGetOverlappedUSBWrite();


#include "libusb.h"   //Include libusb public header file.

// Need some extra definitions from LIBUSB to get access to the CONTEXT so we can wait on TCP AND USB events.
//  *****WARNING****
//THIS MEANS THAT WE ARE USING INTERNAL STRUCTURES FROM LIBUSB_WIN32. 
//IF THE INTERNAL STRUCTURES ARE CHANGED IN FUTURE VERSIONS THEN THIS MAY BREAK USB2TCP
//Currently it works with libusb-win32-device-bin-0.1.12.1
typedef struct {
  unsigned int timeout;
  union {
    struct
    {
      unsigned int configuration;
    } configuration;
    struct
    {
      unsigned int interface1;
      unsigned int altsetting;
    } interface2;
    struct
    {
      unsigned int endpoint;
      unsigned int packet_size;
    } endpoint;    
    struct
    {
      unsigned int type;
      unsigned int recipient;
      unsigned int request;
      unsigned int value;
      unsigned int index;
    } vendor;
    struct
    {
      unsigned int recipient;
      unsigned int feature;
      unsigned int index;
    } feature;
    struct
    {
      unsigned int recipient;
      unsigned int index;
      unsigned int status;
    } status;
    struct
    {
      unsigned int type;
      unsigned int index;
      unsigned int language_id;
      unsigned int recipient;
    } descriptor;    
    struct
    {
      unsigned int level;
    } debug;
    struct
    {
      unsigned int major;
      unsigned int minor;
      unsigned int micro;
      unsigned int nano;
    } version;
  };
} libusb_request;    //copied from driver_api.h
 

typedef struct {
  usb_dev_handle *dev;  //In the public API for libusb.h
  libusb_request req;	//
  char *bytes;
  int size;
  DWORD control_code;
  OVERLAPPED ol;
} usb_context_t;

extern usb_context_t *pread_usb_context;
extern usb_context_t *pwrite_usb_context;

#endif /* _USB_H_ */
