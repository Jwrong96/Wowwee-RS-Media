md5sum rfs_default.cramfs
wc -c rfs_default.cramfs

md5sum rfs_system.cramfs
wc -c rfs_system.cramfs
