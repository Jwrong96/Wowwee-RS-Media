/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: bridge.h
 * Description 	: Bridge TCP <-> USB management
 * Author       : Helibot
 *
 * Authors		: Christophe Buguet (cbuguet@users.sourceforge.net)
 *				  Gerald Villemure (gvillemure@users.sourceforge.net)
 *
 * $Id: bridge.h,v 1.1 2004/09/09 19:58:57 cbuguet Exp $
 */

#ifndef _BRIDGE_H_
#define _BRIDGE_H_

#include <windows.h>

/* Constants */
#define	MAX_EVENTS	5
#define STR_SIZE	80
#define THREAD_QUEUE_STARTED	WM_USER + MAX_EVENTS

/* Structure for bridge data */
typedef struct _BRIDGETAG {
	/* COM data */
//	long		lComPort;
	DCB			dcb;
	
	/* TCP networking data */
	long		lTcpPort;
	char		sBindAddr[STR_SIZE];
	SOCKET		sockClient;
	struct sockaddr_in	sockAddr;
	int			iNameLen;
	int			iUsbvid;
	int			iUsbpid;	
	int			iUsbdelay;	
} BRIDGE, *LPBRIDGE;


/* Functions */
DWORD WINAPI StartBridgeThread(LPVOID lpParameter);

/* Global variables */
extern LPBRIDGE		g_lpBridgeCfg;
extern HANDLE		g_hEvent[MAX_EVENTS];

#endif /* _BRIDGE_H_ */
