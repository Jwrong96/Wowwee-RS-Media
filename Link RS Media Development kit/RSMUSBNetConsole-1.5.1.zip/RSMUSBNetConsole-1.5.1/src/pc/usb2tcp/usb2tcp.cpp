/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: main.c
 * Description 	: Application entry point
 * Author       : Helibot
 * Authors		: Christophe Buguet (cbuguet@users.sourceforge.net)
 *				  Gerald Villemure (gvillemure@users.sourceforge.net)
 *
 *
 * File 		: main.c
 * Description 	: Application entry point
 */
//#include "stdafx.h"

#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include <process.h>
#include "bridge.h"
//#include "service.h"
//#include "registry.h"
//#include "error.h"

#include "usb.h"   //Debug??

/* Global variables */
BRIDGE		g_bridgeCfg;
LPBRIDGE	g_lpBridgeCfg;
HANDLE		g_hEvent[MAX_EVENTS];
HANDLE		hThread;
FILE		*myout;

/* Local variables */
int			orig;

/* Local functions */
int		main(int argc, char* argv[]);
void	ShowHelp();



/**
 * Displays help
 */
void ShowHelp()
{
	fprintf(stderr,
		"\n"
		"------------------------------------------------------\n"
		"USB to TCP bridge"
		"Helibot 2009\n"
		"Bridging RSMedia USB Serial data to a TCP port\n"
		"------------------------------------------------------\n\n"
		"Optional Command line paramaters:\n"
		"  tcp/[port]    : Use TCP port [port] (default TCP port is 222)\n"
		"  vid/[hex num] : Use USB VID of [hex num] (default vid is 0425)\n"
		"  pid/[hex num] : Use USB PID of [hex num] (default pid is 00A0)\n"
		"  dly/[num]     : Use num ms delay b/n send data to USB (default 20 millisecs)\n"
		"  --help : Displays this help message\n\n");
}



/**
 * Application entry point
 *
 * @param hInstance Handle to current instance
 * @param hPrevInstance Handle to previous instance
 * @param lpCmdLine Pointer to command line
 * @param nCmdShow Show state of window
 */
int main(int argc, char *argv[])
{
	char	sModuleName[512];
///	char	sExePath[512];
///	char	sLogFile[32];
///	int		iParam = -1;
	long	lTcp = 222;
	int		iUsbvid = MY_VID;
	int		iUsbpid = MY_PID;
	int		iUsbdelay = 20;
	int		cnt;

	// Gets the EXE name and full path
	GetModuleFileName(NULL, sModuleName, sizeof(sModuleName));


	myout = stdout;
	// Manages arguments
	cnt = argc;
	while (cnt-- > 1) {
		sscanf(argv[cnt], "tcp/%ld", &lTcp);
		sscanf(argv[cnt], "vid/%x", &iUsbvid);
		sscanf(argv[cnt], "pid/%x", &iUsbpid);
		sscanf(argv[cnt], "dly/%d", &iUsbdelay);
	}
	// Help screen
	if (argc >=2 && strcmp(argv[1], "--help") == 0) {
		ShowHelp();
		return 0;
	}
	fprintf(stdout, "Using Tcp port %d \n", lTcp);
	fprintf(stdout, "Using USB Vid %x \n", iUsbvid);
	fprintf(stdout, "Using USB Pid %x \n", iUsbpid);
	fprintf(stdout, "Using USB Delay %d \n", iUsbdelay);
	fprintf(stdout, "use '%s -- help' for help\n\n", argv[0]);
	
		// Allocate bridge struct memory
		g_lpBridgeCfg = &g_bridgeCfg;

		// Allocate bridge struct memory
		g_lpBridgeCfg->lTcpPort = lTcp;

		strcpy(g_lpBridgeCfg->sBindAddr, "0.0.0.0");

		g_lpBridgeCfg->iUsbvid = iUsbvid;
		g_lpBridgeCfg->iUsbpid = iUsbpid;
		g_lpBridgeCfg->iUsbdelay = iUsbdelay;

		fprintf(stdout, "Starting - Press Ctrl+C to stop program\n");

		StartBridgeThread(NULL);


//#ifndef _DEBUG
	// Closes myout
	if ((myout != NULL) && (myout != stdout)) {
		fclose(myout);
	}
//#endif

	return 0;
}