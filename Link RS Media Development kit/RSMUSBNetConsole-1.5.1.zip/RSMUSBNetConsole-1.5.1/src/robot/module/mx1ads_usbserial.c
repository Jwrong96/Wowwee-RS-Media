/*
 * USB Serial driver for Motorola MXL-ADS
 *
 * 2003-11-14 Sam Cheng (sam@emsoftltd.com)
 *              USB serial driver for MXL-ADS (Modify from MX1 usb mass storage driver)
*
 *2009-04-16 Helibot - modify for use as RSMedia USB serial device.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/compatmac.h>
#include <linux/hdreg.h>
#include <linux/vmalloc.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/blkpg.h>
#include <linux/init.h>
//#include <linux/sched.h>
//#include <linux/wait.h>

/* type definition */
typedef	unsigned char	U8;
typedef	unsigned short	U16;
typedef	unsigned long	U32;
typedef	U8 				*P_U8;
typedef	U16 				*P_U16;
typedef	U32 				*P_U32;

#define MX1ADS_USBSERIAL_MAJOR		188

/* error code definition */
#define ERR_USB_NO_SUPPORT      0x1A00

// device status definition
#define USB_DRV_NOT_READY       0
#define USB_DRV_READY           1

/* interrupt source definition */
#define USB_INTR_SOURCE0        47
#define USB_INTR_SOURCE1        48
#define USB_INTR_SOURCE2        49
#define USB_INTR_SOURCE3        50
#define USB_INTR_SOURCE4        51
#define USB_INTR_SOURCE5        52
#define USB_INTR_SOURCE6        53

// PORT A registers
#define PORTA_BASE      0xF021C000
#define _reg_PTA_GIUS   (*((volatile U32 *)(PORTA_BASE+0x20)))
#define _reg_PTA_OCR1   (*((volatile U32 *)(PORTA_BASE+0x04)))
#define _reg_PTA_PUEN   (*((volatile U32 *)(PORTA_BASE+0x40)))
#define _reg_PTA_DDIR   (*((volatile U32 *)(PORTA_BASE+0x00)))
#define _reg_PTA_DR     (*((volatile U32 *)(PORTA_BASE+0x1C)))
#define _reg_PTA_GPR    (*((volatile U32 *)(PORTA_BASE+0x38)))

// PORT B registers
#define PORTB_BASE      0xF021C100
#define _reg_PTB_GIUS   (*((volatile U32 *)(PORTB_BASE+0x20)))
#define _reg_PTB_OCR1   (*((volatile U32 *)(PORTB_BASE+0x04)))
#define _reg_PTB_PUEN   (*((volatile U32 *)(PORTB_BASE+0x40)))
#define _reg_PTB_DDIR   (*((volatile U32 *)(PORTB_BASE+0x00)))
#define _reg_PTB_DR     (*((volatile U32 *)(PORTB_BASE+0x1C)))
#define _reg_PTB_GPR    (*((volatile U32 *)(PORTB_BASE+0x38)))

// PORT C registers
#define PORTC_BASE      0xF021C200
#define _reg_PTC_GIUS   (*((volatile U32 *)(PORTC_BASE+0x20)))
#define _reg_PTC_DDIR   (*((volatile U32 *)(PORTC_BASE+0x00)))
#define _reg_PTC_SSR    (*((volatile U32 *)(PORTC_BASE+0x24)))
#define _reg_PTC_ICR1   (*((volatile U32 *)(PORTC_BASE+0x28)))
#define _reg_PTC_ICR2   (*((volatile U32 *)(PORTC_BASE+0x2C)))
#define _reg_PTC_IMR    (*((volatile U32 *)(PORTC_BASE+0x30)))
#define _reg_PTC_ISR    (*((volatile U32 *)(PORTC_BASE+0x34)))

// CS4 registers
#define _reg_CS4_CTRLH  (*((volatile U32 *)0xF0220020))
#define _reg_CS4_CTRLL  (*((volatile U32 *)0xF0220024))

// AITC registers
#define AITC_BASE               0xF0223000
#define _reg_AITC_NIMASK        (*((volatile U32 *)(AITC_BASE+0x04)))
#define _reg_AITC_INTENNUM      (*((volatile U32 *)(AITC_BASE+0x08)))
#define _reg_AITC_INTDISNUM     (*((volatile U32 *)(AITC_BASE+0x0C)))
#define _reg_AITC_INTTYPEH      (*((volatile U32 *)(AITC_BASE+0x18)))
#define _reg_AITC_INTTYPEL      (*((volatile U32 *)(AITC_BASE+0x1C)))
#define _reg_AITC_NIPRIORITY1   (*((volatile U32 *)(AITC_BASE+0x38)))
#define _reg_AITC_NIVECSR       (*((volatile U32 *)(AITC_BASE+0x40)))

// Timer 1 registers
#define TIMER1_BASE             0xF0202000
#define _reg_TMR_TCTL1          (*((volatile U32 *)(TIMER1_BASE+0x00)))
#define _reg_TMR_TPRER1         (*((volatile U32 *)(TIMER1_BASE+0x04)))
#define _reg_TMR_TCMP1          (*((volatile U32 *)(TIMER1_BASE+0x08)))
#define _reg_TMR_TSTAT1         (*((volatile U32 *)(TIMER1_BASE+0x14)))

// Real Time Clock registers
#define RTC_BASE                0xF0204000
#define _reg_RTC_RCCTL          (*((volatile U32 *)(RTC_BASE+0x10)))
#define _reg_RTC_RTCISR         (*((volatile U32 *)(RTC_BASE+0x14)))
#define _reg_RTC_RTCIENR        (*((volatile U32 *)(RTC_BASE+0x18)))

#define FRR         0x0100  // Free Running/Restart (bit 8)
#define IRQEN       0x0010  // IRQ enable (bit 4)
#define CLKSOURCE   0x000E  // clock source (bit 3-1)
#define TEN         0x0001  // timer enable (bit 0)

// Clock control module registers
#define CCM_BASE						0xF021B000
#define _reg_CCM_CSCR				(*((volatile U32 *)(CCM_BASE+0x00)))
#define _reg_CCM_MPCTL0				(*((volatile U32 *)(CCM_BASE+0x04)))

// USBD registers
#define USBD_BASE						0xF0212000
#define _reg_USBD_STAT				(*((volatile U32 *)(USBD_BASE+0x008)))
#define _reg_USBD_CTRL				(*((volatile U32 *)(USBD_BASE+0x00C)))
#define _reg_USBD_CFGBSY			(*((volatile U32 *)(USBD_BASE+0x010)))
#define _reg_USBD_EPBUF				(*((volatile U32 *)(USBD_BASE+0x014)))
#define _reg_USBD_INTR_STAT		(*((volatile U32 *)(USBD_BASE+0x018)))
#define _reg_USBD_INTR_MASK		(*((volatile U32 *)(USBD_BASE+0x01C)))
#define _reg_USBD_ENABLE			(*((volatile U32 *)(USBD_BASE+0x024)))
#define _reg_USBD_EP0_STAT			(*((volatile U32 *)(USBD_BASE+0x030)))
#define _reg_USBD_EP0_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x034)))
#define _reg_USBD_EP0_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x038)))
#define _reg_USBD_EP0_FDAT			(*((volatile U32 *)(USBD_BASE+0x03C)))
#define _reg_USBD_EP0_FCTRL		(*((volatile U32 *)(USBD_BASE+0x044)))
#define _reg_USBD_EP0_FALRM		(*((volatile U32 *)(USBD_BASE+0x050)))
#define _reg_USBD_EP1_STAT			(*((volatile U32 *)(USBD_BASE+0x060)))
#define _reg_USBD_EP1_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x064)))
#define _reg_USBD_EP1_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x068)))
#define _reg_USBD_EP1_FDAT			(*((volatile U32 *)(USBD_BASE+0x06C)))
#define _reg_USBD_EP1_FCTRL		(*((volatile U32 *)(USBD_BASE+0x074)))
#define _reg_USBD_EP1_FALRM		(*((volatile U32 *)(USBD_BASE+0x080)))
#define _reg_USBD_EP2_STAT			(*((volatile U32 *)(USBD_BASE+0x090)))
#define _reg_USBD_EP2_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x094)))
#define _reg_USBD_EP2_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x098)))
#define _reg_USBD_EP2_FDAT			(*((volatile U32 *)(USBD_BASE+0x09C)))
#define _reg_USBD_EP2_FCTRL		(*((volatile U32 *)(USBD_BASE+0x0A4)))
#define _reg_USBD_EP2_FALRM		(*((volatile U32 *)(USBD_BASE+0x0B0)))
#define _reg_USBD_EP3_STAT			(*((volatile U32 *)(USBD_BASE+0x0C0)))
#define _reg_USBD_EP3_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x0C4)))
#define _reg_USBD_EP3_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x0C8)))
#define _reg_USBD_EP3_FDAT			(*((volatile U32 *)(USBD_BASE+0x0CC)))
#define _reg_USBD_EP3_FCTRL		(*((volatile U32 *)(USBD_BASE+0x0D4)))
#define _reg_USBD_EP3_FALRM		(*((volatile U32 *)(USBD_BASE+0x0E0)))
#define _reg_USBD_EP4_STAT			(*((volatile U32 *)(USBD_BASE+0x0F0)))
#define _reg_USBD_EP4_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x0F4)))
#define _reg_USBD_EP4_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x0F8)))
#define _reg_USBD_EP4_FDAT			(*((volatile U32 *)(USBD_BASE+0x0FC)))
#define _reg_USBD_EP4_FCTRL		(*((volatile U32 *)(USBD_BASE+0x104)))
#define _reg_USBD_EP4_FALRM		(*((volatile U32 *)(USBD_BASE+0x110)))
#define _reg_USBD_EP5_STAT			(*((volatile U32 *)(USBD_BASE+0x120)))
#define _reg_USBD_EP5_INTR_STAT	(*((volatile U32 *)(USBD_BASE+0x124)))
#define _reg_USBD_EP5_INTR_MASK	(*((volatile U32 *)(USBD_BASE+0x128)))
#define _reg_USBD_EP5_FDAT			(*((volatile U32 *)(USBD_BASE+0x12C)))
#define _reg_USBD_EP5_FCTRL		(*((volatile U32 *)(USBD_BASE+0x134)))
#define _reg_USBD_EP5_FALRM		(*((volatile U32 *)(USBD_BASE+0x140)))

#define MDEVREQ_MASK					0x00000008
#define EOT_MASK						0x00000004
#define DEVREQ_MASK					0x00000002
#define EOF_MASK						0x00000001
#define WFR_MASK						0x20000000
#define CMD_OVER_MASK				0x00000040
#define SOF_MASK						0x00000040
#define RST_STOP_MASK				0x00000020
#define RST_START_MASK				0x00000010
#define CFG_CHG_MASK					0x00000001
#define ZLPS_MASK						0x00000004
#define FORCE_STALL_MASK			0x00000001
// PLAM
#define USB_DIV_MASK				0x1C000000
// end PLAM

void _iUsbDelay(U32 count);
void _iUsbLoadEPconfig(void);
void _iUsbReset(void);
void _iUsbProcessCommand(void);
void usb_interrupt(int irq, void *dev_id, struct pt_regs *regs);
void ep0_interrupt(int irq, void *dev_id, struct pt_regs *regs);
void ep1_interrupt(int irq, void *dev_id, struct pt_regs *regs);
void ep2_interrupt(int irq, void *dev_id, struct pt_regs *regs);
void _iUsbHandleDevReq(void);
void _iUsbHandleGetDevDscptr(void);
void _iUsbHandleGetConfDscptr(void);
void _iUsbHandleGetStrDscptr(void);
void _iUsbReturnStrDscptr0(void);
void _iUsbReturnStrDscptr2(void);
void _iUsbReturnStrDscptr3(void);


U8      _gUsbMode;          // operation mode of driver
U8      _gUsbDrvStatus[2];  // Drive status

U32	gEPconfigData[55] = {
	// EP0
	0x00000000,
	0x00000000,
	0x00000008,
	0x00000000,
	0x00000000,
	// EP1
	0x00000014,		// EP#:1, CF#: 1, IF#:0
	0x00000014,		// BULK, IN
	0x00000020,		// MAX PS: 32
	0x000000C0,		// 0xC0, except for EP0
	0x00000001,		// FIFO#: 1
	// EP2
	0x00000024,		// EP#:2, CF#: 1, IF#:0
	0x00000010,		// BULK, OUT
	0x00000020,		// MAX PS: 32
	0x000000C0,		// 0xC0, except for EP0
	0x00000002,		// FIFO#: 2
	// EP3
	0x00000034,		// EP#:3, CF#: 1, IF#:0
	0x0000001C,		// INTR, IN
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000003,		// FIFO#: 3
	// EP4
	0x00000044,		// EP#:4, CF#: 1, IF#:0
	0x00000018,		// INTR, OIUT
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000004,		// FIFO#: 4
	// EP5
	0x00000054,		// EP#:5, CF#: 1, IF#:0
	0x0000001C,		// INTR, IN
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000005,		// FIFO#: 5
	// EP6
	0x00000018,		// EP#:1, CF#: 2, IF#:0
	0x00000014,		// BULK, IN
	0x00000020,		// MAX PS: 32
	0x000000C0,		// 0xC0, except for EP0
	0x00000001,		// FIFO#: 1
	// EP7
	0x00000028,		// EP#:2, CF#: 2, IF#:0
	0x00000010,		// BULK, OUT
	0x00000020,		// MAX PS: 32
	0x000000C0,		// 0xC0, except for EP0
	0x00000002,		// FIFO#: 2
	// EP8
	0x00000038,		// EP#:3, CF#: 2, IF#:0
	0x0000001C,		// INTR, IN
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000003,		// FIFO#: 3
	// EP9
	0x00000048,		// EP#:4, CF#: 2, IF#:0
	0x00000018,		// INTR, OIUT
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000004,		// FIFO#: 4
	// EP10
	0x00000058,		// EP#:5, CF#: 2, IF#:0
	0x0000001C,		// INTR, IN
	0x00000010,		// MAX PS: 16
	0x000000C0,		// 0xC0, except for EP0
	0x00000005,		// FIFO#: 5
	};

P_U8	_gpUsbBufPtr;           // pointer to buffer data
U32   _gUsbNumSector;         // number of sector to read/write
U32   _gUsbCurSector;         // current sector being read/write
U32   _gUsbPacketCount=0;       // USB packet count
U8	_gCBW[256];					// command block wrapper
U8  _gUsbDevReq[8];     /* device request from host */

const U32 _gUsbDevDscptr[5] = {
    0x12011001, 0x00000008, 0x2504A000, 0x00130000, 0x00000101 };		// assume big endian

const U32 _gUsbConfDscptr[8] = {
    0x09022000, 0x010100C0, 0x01090400, 0x0002FFFF,
    0xFF040705, 0x81022000, 0x00070502, 0x02200000};
const U32 _gUsbStrDscptr0 = 0x04030904;

const U32 _gUsbStrDscptr2[7] =  {
	 0x18034D00, 0x58003100, 0x20005500, 0x53004200,
	 0x20006400, 0x65006D00, 0x00006F00};

const U32 _gUsbStrDscptr3[6] = {
    0x16034300, 0x39004600, 0x39003100, 0x43003100,
    0x41004600, 0x00003900};


#define MAX_BUFFER_SIZE	32
#define dprintk(a...)	printk(##a)

static int opened;
static unsigned char data_buffer[MAX_BUFFER_SIZE];
static spinlock_t data_lock;
static int data_ptr_out;
static int data_ptr_in;

//static DECLARE_WAIT_QUEUE_HEAD(wq); 
static wait_queue_head_t usb_ser_wait;

static int data_ready = 0;



void ep0_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{

    U32 fifoWord;
    U8  i, j;

    /* read device request data from FIFO */
    j = 0;
    for (i=0; i<2; i++)
    {
        fifoWord = _reg_USBD_EP0_FDAT;
        _gUsbDevReq[j++] = (U8)(fifoWord >> 24);
        _gUsbDevReq[j++] = (U8)(fifoWord >> 16);
        _gUsbDevReq[j++] = (U8)(fifoWord >> 8);
        _gUsbDevReq[j++] = (U8)fifoWord;
    }
    /* decode device request */
    if ((_gUsbDevReq[0] = 0x80) && (_gUsbDevReq[1] = 0x06))
    {
        switch (_gUsbDevReq[3])
        {
            case 0x01:  // device descriptor
                _iUsbHandleGetDevDscptr();
                break;
            case 0x02:  // configuration descriptor
                _iUsbHandleGetConfDscptr();
                break;
            case 0x03:  // string descriptor
                _iUsbHandleGetStrDscptr();
                break;
        }
    }

   // turn on SOF interrupt to signal CMD_OVER bit
   _reg_USBD_INTR_MASK &= ~(SOF_MASK);
   _reg_USBD_EP0_INTR_STAT = 0x1FF;   // clear all interrupts
}

//Helibot - Note that EP1 interrupt is NOT enabled so this code never gets executed.
//Also not that _gUsbPacketCount is never incremented anywhere , so this code is unlikely to work well!!
void ep1_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{
	U32	i;
	printk("USB serial driver. EP1_interrupt\n");

	// we use EOF interrupt for EP1 only
	--_gUsbPacketCount;
	if (_gUsbPacketCount > 0)
	{
//		for (i=0; i<7; i++)
//			_reg_USBD_EP1_FDAT = *(_gpUsbBufPtr++);
//		_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
//		_reg_USBD_EP1_FDAT = *(_gpUsbBufPtr++);
		for (i=0; i<31; i++)
	   	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = *(_gpUsbBufPtr++);
		_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
   	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = *(_gpUsbBufPtr++);
	}
	else
	{
		// now the CSW
		_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
		for (i=0; i<4; i++)
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
		_reg_USBD_EP1_FDAT = 0;		// data residue
		_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
		*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed

		_reg_USBD_EP1_INTR_MASK |= EOF_MASK;	// disable interrupt
	}
	_reg_USBD_EP1_INTR_STAT |= EOF_MASK;	// clear interrupt
}

// handle OUT endpoint activities (command and data from host)
void ep2_interrupt(int irq, void *dev_id, struct pt_regs *regs)
{
   //printk("USB serial driver. eP2 Int\n");
   if (_reg_USBD_EP2_INTR_STAT & EOT_MASK || _reg_USBD_EP2_INTR_STAT & EOF_MASK)
   {   // EOT/EOF interrupt, command from host
   	_iUsbProcessCommand();
   }
   _reg_USBD_EP2_INTR_STAT = 0x1FF;   // clear all interrupts
}

void usb_interrupt(int irq, void *dev_id, struct pt_regs *regs)
//void _UsbIntrHandler(void)
{
//	DPRINTK("Interrupt source: %d\n", irq);
//	DPRINTK("intr stat before: 0x%08x\n",_reg_USBD_INTR_STAT);
/*
	// reset signalling from host ?
	if (_reg_USBD_INTR_STAT & RST_START_MASK)
	{
		_iUsbReset();
	}
	// It seems that the command over mechanism is not functioning
	// properly. So we'll signal command over every frame.
*/
	if (_reg_USBD_INTR_STAT & SOF_MASK)
	{
		_reg_USBD_CTRL |= CMD_OVER_MASK;    // signal CMD_OVER
	}
	_reg_USBD_INTR_STAT = 0x800000FF;
//	DPRINTK("intr stat after : 0x%08x\n",_reg_USBD_INTR_STAT);

/*
	 // handle general interrupt
    if (_reg_USB_ISR & USB_INTR_GEN_MASK)
    {

        // nothing to be done for CFG_CHG interrupt, just clear the interrupt flag
//        if (_reg_USB_GEN_ISR & USB_CFG_CHG_MASK)
//        {
//        }

        // reset signalling from host
        if (_reg_USB_GEN_ISR & USB_RESET_MASK)
        {
            _iUsbReset();
        }
        // It seems that the command over mechanism is not functioning
        // properly. So we'll signal command over every frame.
        if (_reg_USB_GEN_ISR & USB_SOF_MASK)
        {
            _reg_USB_CTRL |= USB_CTRL_CMOV_MASK;    // signal CMD_OVER
        }
        _reg_USB_GEN_ISR = 0x800000FF;
    }

    // handle interrupt from EP0 (device request)
    if (_reg_USB_ISR & USB_INTR_EP0_MASK)
    {
        _iUsbHandleDevReq();
        _reg_USB_EP0_ISR = 0x1FF;   // clear all interrupts
    }

    // handle interrupt from EP3
    if (_reg_USB_ISR & USB_INTR_EP3_MASK)
    {
        if (_reg_USB_EP3_ISR & USB_EPINTR_EOT_MASK)
        {   // EOT interrupt, command from host
            _reg_USB_MASK = ENABLE_CFG_CHG & ENABLE_RESET;
            _iUsbProcessCommand();
        }
        if (_reg_USB_EP3_ISR & USB_EPINTR_EOF_MASK)
        {   // EOF interrupt, data transfer from host complete
            _iUsbProcessDataFromHost();
        }
        _reg_USB_EP3_ISR = 0x1FF;   // clear all interrupts
    }

    // handle interrupt from EP4 (EOF interrupt, data transfer to host complete)
    if (_reg_USB_ISR & USB_INTR_EP4_MASK)
    {
        _iUsbProcessDataToHost();
        _reg_USB_EP4_ISR = 0x1FF;   // clear all interrupts
    }
*/
}

void _iUsbProcessCommand(void)
{
	int new_data = 0;
	spin_lock(&data_lock);
	while (!(_reg_USBD_EP2_INTR_STAT & 0x80)) {
		data_buffer[data_ptr_in] = *((volatile U8 *)((U32)&_reg_USBD_EP2_FDAT+3));
		//if (!overflow)
			 //data_buffer[data_len] = data_in;
		//printk("USB serial driver. Data Byte= %x,%d)\n",data_buffer[data_len],data_len);
		data_ptr_in++;
		if (data_ptr_in == MAX_BUFFER_SIZE) 
		data_ptr_in = 0;
		if (data_ptr_in == data_ptr_out - 1)
			printk ("USB serial driver. Possible input Overflow\n");
		new_data =  1;
	}
	spin_unlock(&data_lock);
	if (new_data)
	{	//Flag that new data is availble to the Read() function
		data_ready = 1;
		//THIS SHOULD RETURN TRUE AND THEN WAKEUP CODE SHOULD WAKE UP THE USERS READ THREAD
		//BUT INSTEAD IF WAKEUP CODE IS CALLED IT CAUSE KERNAL CRASH WITH INVALID ADDRESS ACCESS
		// So this code is disabled at the moment (instead mx1ads_usbserial_read blocks with a timeout and polls for data_ready = 1)
		/*if ( waitqueue_active( &usb_ser_wait ))
		{
			printk("USB serial driver. IRQ - wakeup\n");
			data_ready = 1;
			//wake_up_interruptible(&usb_serial_wait);
			wake_up_interruptible(&usb_ser_wait);
		}
		else
			printk("USB serial driver. IRQ -wq inactive\n");
		*/
	}
	
	//printk("USB serial driver. ProcCmd(data_len=%d)\n",data_len);

	/*
	for (i = 0; i < 8; i++) {
		*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = i+65;
	}

	_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = '!';
	_reg_USBD_EP1_FDAT = 0x44434241;
	_reg_USBD_EP1_FDAT = 0x48474645;
	_reg_USBD_EP1_FDAT = 0x44434241;
	_reg_USBD_EP1_FDAT = 0x48474645;
	_reg_USBD_EP1_FDAT = 0x44434241;
	_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
	_reg_USBD_EP1_FDAT = 0x48474645;
	udelay(10000);
	*/

	/*
	_reg_USBD_EP1_FDAT = 0x64636261;
	_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = '!';
	*/
	
	//_reg_USBD_EP1_FDAT = 0x68676665;

	/*
	for (i = 0; i < 5; i++) {
		printk("%x\n", (_reg_USBD_EP2_INTR_STAT));
		if (!(_reg_USBD_EP2_INTR_STAT & 0x80))
		_gCBW[i] = *((volatile U8 *)((U32)&_reg_USBD_EP2_FDAT+3));
	}
	for (i = 0; i < 5; i++) {
		printk("%d", _gCBW[i]);
	}
	*/
	/*
	//for (i=0; i<31; i++)
	//	_gCBW[i] = *((volatile U8 *)((U32)&_reg_USBD_EP2_FDAT+3));
	for (i=0; i<20; i++) {
		printk("%x", _reg_USBD_EP2_INTR_MASK & (1 << 7))
		_gCBW[i] = *((volatile U8 *)((U32)&_reg_USBD_EP2_FDAT+3));
	}

	for (i = 0; i < _gCBW[0]; i++)
		printk("%c", _gCBW[i+1]);
	*/

	/*
	printk("%s %d\n", __FUNCTION__, _gCBW[15]);
	switch(_gCBW[15])
	{
		case 0x12:	// inquiry
//DPRINTK("Inquiry\n");
//			_reg_USBD_EP1_FDAT = 0x00800202;
			_reg_USBD_EP1_FDAT = 0x00800001;
			_reg_USBD_EP1_FDAT = 0x5B000000;
			// vendor identification (8 bytes)
			_reg_USBD_EP1_FDAT = 0x4D4F544F;		// "MOTO"
			_reg_USBD_EP1_FDAT = 0x524F4C41;		// "ROLA"
			// product identification (16 bytes)
			_reg_USBD_EP1_FDAT = 0x41445320;		// "ADS "
			_reg_USBD_EP1_FDAT = 0x302E3120;		// "0.1 "
			_reg_USBD_EP1_FDAT = 0x20202020;		// "    "
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			_reg_USBD_EP1_FDAT = 0x20202020;		// "    "

			// product revision level (4 bytes)
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x30;
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x31;
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x30;
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x30;

			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<4; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FDAT = 0;		// data residue
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed
			break;
		case 0x23:	// READ FORMAT CAPACITIES, not supported, return STALL
		case 0x1A:	// MODE SENSE, not supported, return STALL
		case 0x5A:	// MODE SENSE, not supported, return STALL
			_reg_USBD_EP1_STAT |= FORCE_STALL_MASK;
			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<8; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x01;	// status: failed
			break;
		case 0x03:	// REQUEST SENSE, return error
			_reg_USBD_EP1_FDAT = 0x70000500;
			_reg_USBD_EP1_FDAT = 0x0000000C;
			_reg_USBD_EP1_FDAT = 0x00000000;
			_reg_USBD_EP1_FDAT = 0x20000000;
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x00;
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0x00;

			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<4; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FDAT = 0;		// data residue
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed
			break;
		case 0x25:	// READ CAPACITY
//			_reg_USBD_EP1_FDAT = 0x00007FFF;		// last block
			_reg_USBD_EP1_FDAT = 0x00006FFF;		// last block of 14M disk
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			_reg_USBD_EP1_FDAT = 0x00000200;		// block size

			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<4; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FDAT = 0;		// data residue
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed
			break;
		case 0x28:	// READ
			// extract start sector
			_gUsbCurSector = 0;
			for (i=0; i<4; i++)
				_gUsbCurSector = (_gUsbCurSector << 8) | (U32)_gCBW[17+i];
			// extract number of sectors
			_gUsbNumSector = (((U32)_gCBW[22]) << 8) | ((U32)_gCBW[23]);
//DPRINTK("Read from sector 0x%08x for 0x%04x sectors\n", _gUsbCurSector, _gUsbNumSector);
			_gUsbPacketCount = _gUsbNumSector * 16;
			_gpUsbBufPtr = (P_U8)(USB_DISK_START + _gUsbCurSector * 512);

			// fill up the 1st packet
			for (i=0; i<31; i++)
		   	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = *(_gpUsbBufPtr++);
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
   		*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = *(_gpUsbBufPtr++);
			// enable EOF interrupt
			_reg_USBD_EP1_INTR_MASK &= ~EOF_MASK;
			break;
		case 0x00:	// NULL COMMAND, return CSW with pass
		case 0x1E:	// PREVENT-ALLOW MEDIUM REMOVAL, return CSW with pass
		case 0x2F:	// VERIFY
			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<4; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FDAT = 0;		// data residue
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed
			break;
		case 0x1B:	// START-STOP UNIT (when host EJECT)
			printk("\nEJECT from host detected.\n");
			// now the CSW
			_reg_USBD_EP1_FDAT = 0x55534253;		// signature in BIG endian
			for (i=0; i<4; i++)
				*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = _gCBW[4+i];	// CSWtag
			_reg_USBD_EP1_FDAT = 0;		// data residue
			_reg_USBD_EP1_FCTRL |= 0x20000000;	// next is last word in packet
			*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = 0;	// status: passed


			break;
		case 0x2A:	// WRITE
			// extract start sector
			_gUsbCurSector = 0;
			for (i=0; i<4; i++)
				_gUsbCurSector = (_gUsbCurSector << 8) | (U32)_gCBW[17+i];
			// extract number of sectors
			_gUsbNumSector = (((U32)_gCBW[22]) << 8) | ((U32)_gCBW[23]);
//DPRINTK("Write to sector 0x%08x for 0x%04x sectors\n", _gUsbCurSector, _gUsbNumSector);
			_gUsbPacketCount = _gUsbNumSector * 16;
			_gpUsbBufPtr = (P_U8)(USB_DISK_START + _gUsbCurSector * 512);
			// enable EOF interrupt
			_reg_USBD_EP2_INTR_MASK &= ~EOF_MASK;
			break;
		default:
			printk("Unknown command !\n");
	DPRINTK("dCBWSignature: 0x%02x 0x%02x 0x%02x 0x%02x \n", _gCBW[0], _gCBW[1], _gCBW[2], _gCBW[3]);
	DPRINTK("dCBWTag: 0x%02x 0x%02x 0x%02x 0x%02x \n", _gCBW[4], _gCBW[5], _gCBW[6], _gCBW[7]);
	DPRINTK("dCBWDataTransferLength: 0x%08x\n", (int)((U32)_gCBW[8] | ((U32)_gCBW[9]<<8) | ((U32)_gCBW[10]<<16) | ((U32)_gCBW[11]<<24)));
	DPRINTK("bmCBWFlags: 0x%02x\n", _gCBW[12]);
	DPRINTK("bCBWLUN: 0x%02x\n", _gCBW[13]);
	DPRINTK("bCBWLength: 0x%02x\n", _gCBW[14]);
	DPRINTK("CBWCB: ");
	for (i=0; i<_gCBW[14]; i++)
		DPRINTK("0x%02x ", _gCBW[15+i]);
	DPRINTK("\n");

	}
*/
}

void _iUsbHandleDevReq()
{
    U32 fifoWord;
    U8  i, j;

    /* read device request data from FIFO */
    j = 0;
    for (i=0; i<2; i++)
    {
        fifoWord = _reg_USBD_EP0_FDAT;
        _gUsbDevReq[j++] = (U8)(fifoWord >> 24);
        _gUsbDevReq[j++] = (U8)(fifoWord >> 16);
        _gUsbDevReq[j++] = (U8)(fifoWord >> 8);
        _gUsbDevReq[j++] = (U8)fifoWord;
    }
    /* decode device request */
    if ((_gUsbDevReq[0] = 0x80) && (_gUsbDevReq[1] = 0x06))
    {
        switch (_gUsbDevReq[3])
        {
            case 0x01:  // device descriptor
                _iUsbHandleGetDevDscptr();
                break;
            case 0x02:  // configuration descriptor
                _iUsbHandleGetConfDscptr();
                break;
            case 0x03:  // string descriptor
                _iUsbHandleGetStrDscptr();
                break;
        }
    }

	 // turn on SOF interrupt to signal CMD_OVER bit
	 _reg_USBD_INTR_MASK &= ~(SOF_MASK);
}

void _iUsbHandleGetDevDscptr()
{
//DPRINTK("Device Descr\n");

    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbDevDscptr[0];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbDevDscptr[1];

//    _reg_USB_CTRL |= USB_CTRL_CMOV_MASK;

    /* if length is not exactly 0x12, just return one packet */
    /* otherwise, return all 0x12 bytes */
    if (_gUsbDevReq[6] == 0x12)
    {
        _reg_USBD_EP0_FDAT = _gUsbDevDscptr[2];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbDevDscptr[3];

		// due a bug in gcc, half-word access is compiled into word access
		// so we'll use byte access instead
      *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbDevDscptr[4]>>8);
      _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
      *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)_gUsbDevDscptr[4];
	}
}

void _iUsbHandleGetConfDscptr()
{
    /* if length is exactly 9, return 9 bytes only */
    if (_gUsbDevReq[6] == 0x09)
    {
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[0];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[1];

        /* here comes the last byte */
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbConfDscptr[2]>>24);
    }
    else    /* otherwise, return all 32 bytes */
    {
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[0];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[1];

        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[2];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[3];

        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[4];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[5];

        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[6];
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        _reg_USBD_EP0_FDAT = _gUsbConfDscptr[7];

        /* need to end with a zero length packet */
        _reg_USBD_EP0_STAT |= ZLPS_MASK;    // next one is a zero length packet
    }
}

void _iUsbHandleGetStrDscptr()
{
    switch (_gUsbDevReq[2])
    {
        case 0:
            _iUsbReturnStrDscptr0();
            break;
        case 2:
            _iUsbReturnStrDscptr2();
            break;
        case 3:
            _iUsbReturnStrDscptr3();
            break;
    }
}

void _iUsbReturnStrDscptr0()
{
    /* if length is 2, return 2 bytes only */
    if (_gUsbDevReq[6] == 0x02)
    {
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr0>>24);
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr0>>16);
    }
    else    /* otherwise, return all 4 bytes */
    {
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr0>>24);
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr0>>16);
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr0>>8);
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)_gUsbStrDscptr0;
    }
//    _reg_USBD_EP0_ISR |= USBD_EPINTR_EOT_MASK; // clear EOT intr
//    _reg_USBD_EP0_MASK = ENABLE_DEVREQ & ENABLE_EOT;
}

void _iUsbReturnStrDscptr2()
{
    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[0];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[1];

    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[2];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[3];

    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[4];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr2[5];

    *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr2[6]>>8);
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)_gUsbStrDscptr2[6];

	 /* the next packet is an zero-length one */
//    _reg_USBD_EP0_STAT |= ZLPS_MASK;

//    _reg_USBD_EP0_ISR |= USBD_EPINTR_EOT_MASK; // clear EOT intr
//    _reg_USBD_EP0_MASK = ENABLE_DEVREQ & ENABLE_EOT;
}

void _iUsbReturnStrDscptr3()
{
    /* if length is 2, return 2 bytes only */
    if (_gUsbDevReq[6] == 0x02)
    {
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr3[0]>>24);
        _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
        *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr3[0]>>16);
    }
    else    /* otherwise return all 22 bytes */
    {
    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr3[0];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr3[1];

    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr3[2];
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr3[3];

    /* 8 bytes per packet */
    _reg_USBD_EP0_FDAT = _gUsbStrDscptr3[4];
    *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)(_gUsbStrDscptr3[5]>>8);
    _reg_USBD_EP0_FCTRL |= 0x20000000;  // next write is last one of packet
    *((volatile U8 *)((U32)&_reg_USBD_EP0_FDAT+3)) = (U8)_gUsbStrDscptr3[5];
    }

//    _reg_USBD_EP0_ISR |= USBD_EPINTR_EOT_MASK; // clear EOT intr
//    _reg_USBD_EP0_MASK = ENABLE_DEVREQ & ENABLE_EOT;
    
}

void _iUsbDelay(U32 count)
{
    U32 i;

    i = 0;
    while (i<count)
    {
        i++;
    }
}

void _iUsbReset()
{
	U8	i;
 /* reset and enable USB device module */
	//_reg_USBD_ENABLE = 0x00000000;	    /* disable module */
// PLAM -- for rev2 (changed from using direct assignment and for new endian bit)
	_reg_USBD_ENABLE &= ~0x40000000;	/* disable module */
// end PLAM
	_iUsbDelay(10);
	//_reg_USBD_ENABLE = 0x80000000;	    /* enable and reset module */
// PLAM -- for rev2 (changed from using direct assignment and for new endian bit)
	_reg_USBD_ENABLE &= ~0x00000001;	/* select 32-bit mode FIFO */
	_reg_USBD_ENABLE &= ~0x10000000;	/* Set big endian */
	_reg_USBD_ENABLE |= 0x40000000;	    /* enable module */
// end PLAM
	
	/* remark: resetting the module will enable module automatically */
	while (!(_reg_USBD_ENABLE & 0x40000000));		// wait until it is enabled

	// fill endpoint configuration buffer
	for (i=0; i<55; i++)
	{
		_reg_USBD_EPBUF = gEPconfigData[i];
		while (_reg_USBD_CFGBSY & 0x40000000);		// wait until busy bit is cleared
	}

	// mask interrupts
	_reg_USBD_INTR_STAT = 0x800000FF;		// clear general interrupts
	_reg_USBD_INTR_MASK = 0x800000FF;		// mask all general interrupts
//DPRINTK("intr stat: 0x%08x\n",_reg_USBD_INTR_STAT);
	_reg_USBD_EP0_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP0_INTR_MASK = 0x000001FF;	// mask all EP interrupts
	_reg_USBD_EP1_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP1_INTR_MASK = 0x000001FF;	// mask all EP interrupts
	_reg_USBD_EP2_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP2_INTR_MASK = 0x000001FF;	// mask all EP interrupts
	_reg_USBD_EP3_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP3_INTR_MASK = 0x000001FF;	// mask all EP interrupts
	_reg_USBD_EP4_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP4_INTR_MASK = 0x000001FF;	// mask all EP interrupts
	_reg_USBD_EP5_INTR_STAT = 0x000001FF;	// clear EP interrupts
	_reg_USBD_EP5_INTR_MASK = 0x000001FF;	// mask all EP interrupts

	// configure USB_EPn_STAT registers and flush FIFOs
	_reg_USBD_EP0_STAT = 0x00000002;
	_reg_USBD_EP1_STAT = 0x000000D2;		// IN, MAX PS 32, BULK
	_reg_USBD_EP2_STAT = 0x00000052;		// OUT, MAX pS 32, BULK
	_reg_USBD_EP3_STAT = 0x000000BA;		// IN, MAX PS 16, INTR
	_reg_USBD_EP4_STAT = 0x0000003A;		// OUT, MAX PS 16, INTR
	_reg_USBD_EP5_STAT = 0x000000BA;		// IN, MAX PS 16, INTR

	// configure USB_EPn_FCTRL registers
	_reg_USBD_EP0_FCTRL = 0x0F000000;
	//_reg_USBD_EP1_FCTRL = 0x0B000000;
	_reg_USBD_EP1_FCTRL = 0x0F000000;
	_reg_USBD_EP2_FCTRL = 0x0F000000;
	_reg_USBD_EP3_FCTRL = 0x0B000000;
	_reg_USBD_EP4_FCTRL = 0x0F000000;
	_reg_USBD_EP5_FCTRL = 0x0B000000;

	// configure USB_EPn_FALRM registers
	_reg_USBD_EP0_FALRM = 0x00000000;
	_reg_USBD_EP1_FALRM = 0x00000020;
	_reg_USBD_EP2_FALRM = 0x00000020;
	_reg_USBD_EP3_FALRM = 0x00000010;
	_reg_USBD_EP4_FALRM = 0x00000010;
	_reg_USBD_EP5_FALRM = 0x00000010;

	while (_reg_USBD_INTR_STAT & RST_START_MASK);	// wait until reset signaling finished
	_reg_USBD_CTRL = 0x0000001A;				// enable module
}

static ssize_t mx1ads_usbserial_write(struct file * file, const char * buf, size_t count, loff_t *ppos)
{
	unsigned char data;
	int i;
	int len;

	if (count > 32)
		len = 32;
	else
		len = count;

	for (i = 0; i < len-1; i++) {
		get_user(data, &buf[i]);
		*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = data;

	}
	get_user(data, &buf[i]);
 	_reg_USBD_EP1_FCTRL |= 0x20000000; 
	*((volatile U8 *)((U32)&_reg_USBD_EP1_FDAT+3)) = data;

//	printk("USB serial driver. Write (len=%d)\n",len);
	//In theory we should now wait until the write is finsihed (should get an interrupt when its complete)
	//But the iunterrupt inever occurs so instead we just do a HACK and delay here for awhile.
	//DEBUG - Kill some time to let the bytes be sent out the USB port
	_iUsbDelay (50000);
	return len;
}


//copy bytes from usb buff to a tempory buffer
int get_bytes(unsigned char *tmp_buf, int request) 
{
	int len = data_ptr_in - data_ptr_out;
	if (len == 0) 
		return 0;
	if (len < 0)  //then buffer has wrapped
		len = MAX_BUFFER_SIZE + len;   //But since len <0 then + 'en will make len smaller than MAX_BUFFER_SIZE

	if (request < len)  //If the user has requested less bytes than available then only get the requested bytes
		len = request;
	//printk("Req = %d , len = %d\n",request,len);
	if (data_ptr_out +  len < MAX_BUFFER_SIZE) 
	{
		memcpy(tmp_buf, &(data_buffer[data_ptr_out]), len);
		data_ptr_out += len;
	} 
	else //buffer has wrapped (some data is at the end and some is at the start)
	{
		//Copy all data from the current out pointer to the end of the buffer
		memcpy(tmp_buf, &(data_buffer[data_ptr_out]), MAX_BUFFER_SIZE - data_ptr_out);

		//Find the number of bytes to copy from the start of the buffer
		int outpos = len - (MAX_BUFFER_SIZE - data_ptr_out);
		printk("2 part copy p1=%d, p2=%d\n",MAX_BUFFER_SIZE - data_ptr_out,outpos);

		//Now copy these bytes to the end of the output buffer
		memcpy(&tmp_buf[MAX_BUFFER_SIZE - data_ptr_out], &(data_buffer[0]), outpos);
		data_ptr_out = outpos;
	}

	return len;
}
static ssize_t mx1ads_usbserial_read(struct file * file, char * buf, size_t count, loff_t *ppos)
{
	static unsigned char tmp_buf[MAX_BUFFER_SIZE+5];  //DEBUG + 5 just in case!!!
///	DECLARE_WAITQUEUE(wait,current);
	int len;
	
//	printk("USB serial driver. Read Start\n");
	// check if we have data - if not, sleep
	// wake up in interrupt_handler

	if (data_ptr_in == data_ptr_out) //There is no data so wait
	{
	//	printk("USB serial driver. Read Starting wait\n");
///		add_wait_queue(&usb_ser_wait, &wait);
///		current->state = TASK_INTERRUPTIBLE;

		//wait_event_interruptible(wq, data_ready != 0);
wait:
		while (!data_ready) {
//DEBUG - THE WAKEUP COMMAND IS NOT WORKING (GETS NULL POINTER EXCEPTION
//DEBUG - SO INSTEAD USE A TIMEOUT ON THE WAIT AND THEN CHECK FOR DATA
			interruptible_sleep_on_timeout(&usb_ser_wait,30);
		}
		data_ready = 0;
	//	printk("USB serial driver. Read wait complete\n");
	///	current->state = TASK_RUNNING;
	///	remove_wait_queue(&usb_ser_wait, &wait);
	}
	spin_lock(&data_lock);
	//copy bytes from usb buff to a tempory buffer
	//(Will also adjust the data_ptr_out pointer - so make sure it is called within spinlock)
	len = get_bytes(tmp_buf, count);
	if (len == 0) {
		printk("USB serial driver. Error - data len = 0\n");
		spin_unlock(&data_lock);
		goto wait;  //Sorry , using a evil goto command- Len = 0 is a rare occurance dont know why it happens, this is the easiest way to handle it.
	}
	//Now copy the prepared data to the userbuffer
	copy_to_user(buf, tmp_buf, len);	
	spin_unlock(&data_lock);
//	printk("USB serial driver. Read (len=%d cnt=%d)\n",len, count);
	return len;
}

static int mx1ads_usbserial_ioctl(struct inode *inode, struct file *filp, unsigned 
int cmd, unsigned long arg)
{
	//printk("USB serial driver. ioctrl (cmd=%0X),(arg=%0lX)\n",cmd,arg);
	return 0;
}

static int mx1ads_usbserial_open(struct inode * inode, struct file * filp)
{
	printk("USB serial driver. Open (%d) [flags = %x]\n",opened, filp->f_flags);
	//let multiple open happen (so we can redirect stdin and stdout through this device and support other connections, pipes other shells ect) 
	if (opened >= 20) 
		return -EIO;
	opened++;
	return 0;
}

static int mx1ads_usbserial_release(struct inode *inode, struct file *filp)
{
	printk("USB serial driver. Release (%d)\n",opened);
//    opened = 0;

//	wake_up_interruptible(&usb_ser_wait);
	
	if (opened > 0)
		opened--;
	if (opened == 0)
	{
		data_ptr_out = 0;
		data_ptr_in = 0;
	}
    return 0;

}


static struct file_operations mx1ads_usbserial_fops = {
        read:   mx1ads_usbserial_read,
        write:  mx1ads_usbserial_write,
        ioctl:  mx1ads_usbserial_ioctl,
        open:   mx1ads_usbserial_open,
        release:mx1ads_usbserial_release,
};

int __init mx1ads_usbserial_init(void)
{

	// set clock for 48 MHz USB clock
	//_reg_CCM_CSCR = 0x47008403;
// PLAM -- for rev2 (changed from using direct assignment and for new endian bit)
	_reg_CCM_CSCR &= ~USB_DIV_MASK;
	_reg_CCM_CSCR |= 0x04000000;	// set USB DIV to divide-by-2
// end PLAM	

	// config port for USBD
	_reg_PTB_GIUS &= 0x000FFFFF;		// set PB31-28 to UART2 and PB27-20 to USBD
	_reg_PTB_GPR &= 0x000FFFFF;		// select primary peripheral

    // enable USB device interrupt
//    _reg_IMR &= (~USBD_INTR_MASK);

    /* initialize variables */
	_gUsbDrvStatus[0] = USB_DRV_READY;
//   _gUsbDrvStatus[0] = USB_DRV_NOT_READY;
   _gUsbDrvStatus[1] = USB_DRV_NOT_READY;
    /* register interrupt handler */
//    _HalAttachIsr(USB_INTR_SOURCE, (P_VOID)_UsbIntrHandler);

    _iUsbReset();

	if (request_irq(USB_INTR_SOURCE0, ep0_interrupt, SA_INTERRUPT, "USB EP0", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE0);
	if (request_irq(USB_INTR_SOURCE1, ep1_interrupt, SA_INTERRUPT, "USB EP1", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE1);
	if (request_irq(USB_INTR_SOURCE2, ep2_interrupt, SA_INTERRUPT, "USB EP2", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE2);
	if (request_irq(USB_INTR_SOURCE3, usb_interrupt, SA_INTERRUPT, "USB EP3", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE3);
	if (request_irq(USB_INTR_SOURCE4, usb_interrupt, SA_INTERRUPT, "USB EP4", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE4);
	if (request_irq(USB_INTR_SOURCE5, usb_interrupt, SA_INTERRUPT, "USB EP5", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE5);
	if (request_irq(USB_INTR_SOURCE6, usb_interrupt, SA_INTERRUPT, "USB", 0) < 0)
		printk("Intr request for source %d failed !\n", USB_INTR_SOURCE6);

	_reg_USBD_EP0_INTR_MASK &= ~(DEVREQ_MASK);	// enable DEVREQ for EP0
//	_reg_USBD_EP0_INTR_MASK = 0x1FD;	// enable DEVREQ for EP0
	_reg_USBD_EP2_INTR_MASK &= ~(EOT_MASK);		// enable EOT for EP2
	_reg_USBD_EP2_INTR_MASK &= ~(1 << 7);		// enable FIFO for EP2
	_reg_USBD_EP2_INTR_MASK &= ~(EOF_MASK);		// enable EOF for EP2

	opened = 0;
	data_ptr_in = 0;
	data_ptr_out = 0;
        spin_lock_init(&data_lock);

        if (register_chrdev(MX1ADS_USBSERIAL_MAJOR, "MX1ADS USB serial", &mx1ads_usbserial_fops))
                panic("Unable to get major %d for USB serial", MX1ADS_USBSERIAL_MAJOR);

	init_waitqueue_head(&usb_ser_wait);				

	printk("MXLADS USB serial module initialized %d\n",MX1ADS_USBSERIAL_MAJOR);

	return 0;
}

void mx1ads_usbserial_exit(void)
{
	printk("Cleanup USB serial driver. %d\n",MX1ADS_USBSERIAL_MAJOR);

	free_irq(USB_INTR_SOURCE0, 0);
	free_irq(USB_INTR_SOURCE1, 0);
	free_irq(USB_INTR_SOURCE2, 0);
	free_irq(USB_INTR_SOURCE3, 0);
	free_irq(USB_INTR_SOURCE4, 0);
	free_irq(USB_INTR_SOURCE5, 0);
	free_irq(USB_INTR_SOURCE6, 0);
	unregister_chrdev(MX1ADS_USBSERIAL_MAJOR, "MX1ADS USB serial");

}

#ifndef MODULE
__initcall(mx1ads_usbserial_init);
#else
module_init(mx1ads_usbserial_init);
module_exit(mx1ads_usbserial_exit);
#endif
