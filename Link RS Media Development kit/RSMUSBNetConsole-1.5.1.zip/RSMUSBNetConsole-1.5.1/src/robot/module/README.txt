NOTE THIS SOURCE CODE IS NOW FOR REFERENCE ONLY
THE SOURCE CODE HERE WAS USED FOR mx1ads_serial.o for USBConsole versions 1.0-1.4
BUT USBConsole V1.5 uses mx1ads_serial.o from Wowwee. There is no source code available for this version from Wowwee. The Wowweeversion is available in all RS Media V2 robots in the directory /usr/bin/robot/ppp
Helibot Feb 2010
