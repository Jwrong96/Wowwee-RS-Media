#!/bin/sh

# Call script in Application directory to start the USB console.
/mnt/sd/Application/startusbcon.sh


