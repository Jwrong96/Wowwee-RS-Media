#This is the script that starts the RSM Application Menu program for the RSMedia robot.
#By Helibot 2009.
#kill any old versions of the RSM App Menu running
killall rsmappmenu

cd /mnt/sd/Application
#Start the rsm Application Menu program (using '&' so its run in the background)
./rsmappmenu &
