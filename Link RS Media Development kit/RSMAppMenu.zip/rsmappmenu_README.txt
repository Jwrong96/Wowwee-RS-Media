RSMAppMenu
==========
by Helibot 2009

This program creates a menu on the RSMedia LCD screen. The user can navigate up and down the menu and select items.
The menu graphics are similar to the standard menu graphics in WowWee applications.
The menu items are read from a config.ini file (Which is a windows style ini file format)
The actions for the menu can be to run another program/script or any linux command. The actions are also defined in the ini file.
The aim is that users can create a on screen menu just by editing the config file (without the need for coding in 'c' or any recompiling).

Install
=====
Unzip the archive to the SD card Application directory.
Edit the config.ini file if you want to change the menu items.

Usually you will want to start the menu by UserBodyCon. Todo this you must copy BodyCon6.sh to Personalities\XXX\Macros\CONANIM06 directory.  (XXX is the name of teh active personality)    
(You can then use L+R+STOP button to active the bodycon.sh which will start the rsmappmenu)


Running
======
***NOTE you MUST change to Media mode before starting the application****
***If you dont the menu will run but none of the keys will work.***

If you want to start the app menu by UserBodycon then use
L+R+Stop 

If you want to start the app menu by USBConsole then use
#cd /mnt/sd/Application
#./rsmappmenu &

When rsmappmenu is started it shows a menu of options.
-Use LHS up and down button to navigate the menu items
-Use Select to perform/start one of the menu items.
***NOTE When the application first starts often the keys wont work, to work around this use the RHS up/down keys , this will make the volume dialog appear, when it disappears then the LHS keys should work on the menu.***
-Use the 'a' Key to exit the application.

Notes-
  -To use the USBConsole menu item you need the USB console files in /Application/usbconsole directory. (This is included in archive.)
  -To use the RSMAlarmClock menu item you need the RSMAlarmClockV2 programs installed at /clk directory on the SD card. (Not included in the archive)
  -Dont forget that there can be upto 20 items , so you have to scroll down to see item 7 to 20.
  
Source code
=========
The code is released into the source repository at http://sourceforge.net/projects/rsmediadevkit/develop. 
It is freely available, but it is necessary to use the /include and /libs from the source repository and also the compiler from the repository (or from RSMDevkit1.5 or later)
 




