/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: tcp.c
 * Description 	: TCP/IP socket management
 * Authors		: Christophe Buguet (cbuguet@users.sourceforge.net)
 *				  Gerald Villemure (gvillemure@users.sourceforge.net)
 *
 * Modifications: Helibot
 *
 * $Id: tcp.c,v 1.1 2004/09/09 19:58:57 cbuguet Exp $
 */


#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>
#include <mswsock.h>
#include "error.h"
#include "tcp.h"
#include "bridge.h"


/**
 * Initializes Winsock DLL
 *
 * @return The error code, or S_OK
 */
int InitWinsock(void) 
{
	WORD	wVersionRequested;
	WSADATA wsaData;
	int		iErr;
 
	// Checks if Winsock is there
	wVersionRequested = MAKEWORD(2, 2);
	iErr = WSAStartup(wVersionRequested, &wsaData);
	
	if (iErr != 0) {
		fprintf(myout, "tcp.c: Checking Winsock DLL (unsupported library)\n");
		return iErr;
	}

	// Checks if version is 2.2 or newer
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
		fprintf(myout, "tcp.c: Check version (>= 2.2)\n");
		CloseWinsock();
		return ERR_FAIL; 
	}

	return S_OK;
}


/**
 * Closes Winsock DLL
 * 
 * @return The error code, or S_OK
 */
int CloseWinsock(void)
{
	int iErr;

	// Closing server socket
	if (g_sockServer) {
		closesocket(g_sockServer);
	}

	// Close Winsock library
	iErr = WSACleanup();

	switch (iErr) {
		case WSANOTINITIALISED:
			fprintf(myout, "tcp.c: No Winsock DLL to close\n");
			break;
		case WSAENETDOWN:
			fprintf(myout, "tcp.c: Network subsystem error\n");
			break;
		case WSAEINPROGRESS:
			fprintf(myout, "tcp.c: Blocking mode call in progress\n");
			break;
		default:
			break;
	}

	return iErr;
}


/**
 * Starts listening on specified IP and port
 *
 * @param sIFace Interface to listen to (NULL for all interfaces available)
 * @param iPort TCP port
 * @param hWnd Window handle
 */
int StartTcpSocket(char *sIFace, unsigned short iPort, HWND hWnd)
{
	struct sockaddr_in	local;

	local.sin_family		= AF_INET;
	local.sin_addr.s_addr	= (sIFace) ? inet_addr(sIFace) : INADDR_ANY;
	local.sin_port			= htons(iPort);
	
	// Creates socket
	g_sockServer = socket(AF_INET, SOCK_STREAM, 0);

	if (g_sockServer == INVALID_SOCKET) {
		fprintf(myout, "tcp.c: Unable to create socket (%d)\n", WSAGetLastError());
		CloseWinsock();
		return ERR_FAIL;
	}

	// Binds IP and TCP port to the socket
	if (bind(g_sockServer, (struct sockaddr FAR *)&local, sizeof(local))) {
		fprintf(myout, "tcp.c: Unable to bind IP and port (%d)\n", WSAGetLastError());
		CloseWinsock();
		return ERR_FAIL;
	}
	
	// Starts listening to socket
	if (listen(g_sockServer, SOMAXCONN) == SOCKET_ERROR) {
		fprintf(myout, "tcp.c: listen() failed (%d)\n", WSAGetLastError());
		CloseWinsock();
		return ERR_FAIL;
	}

	g_hEvent[WSA_ACCEPT] = WSACreateEvent();
	g_hEvent[WSA_READ]	= WSACreateEvent();
	g_hEvent[WSA_WRITE]	= WSACreateEvent();

	// Runs and waits for incoming connection
	WSAEventSelect(g_sockServer, g_hEvent[WSA_ACCEPT], FD_ACCEPT);
	//WSAEventSelect(g_sockServer, g_hEvent[WSA_WRITE], FD_WRITE);

	return S_OK;
}


/**
 * Accepts new connection
 *
 * @param cl_sock The client socket
 * @return TRUE if connection was accepted, FALSE otherwise
 */
BOOL AcceptConnection(SOCKET *cl_sock)
{
	struct sockaddr_in	cl_saddr; 
	int					iClAddrLen;
	SOCKET				tmp_sock;
	char				sMsg[STR_SIZE] = "Someone is already connected. Bye.\n";

	// Rejects if there is already one connction established
	if (*cl_sock) {
		tmp_sock = accept(g_sockServer, (struct sockaddr FAR *)&cl_saddr, (int FAR *)&iClAddrLen);
		WriteSocketData(&tmp_sock, sMsg, STR_SIZE);
		CloseConnection(&tmp_sock);

		return FALSE;
	}

	// Initialisation des informations du nouveau client qui se connecte
	iClAddrLen	= sizeof(cl_saddr);
	*cl_sock	= accept(g_sockServer, (struct sockaddr FAR *)&cl_saddr, (int FAR *)&iClAddrLen);
	
	if (*cl_sock == INVALID_SOCKET) {
		CloseConnection(cl_sock);
		return FALSE;
	}

	// Initialisation de la lecture �criture
	g_hEvent[WSA_READ] = WSACreateEvent();
	WSAEventSelect(*cl_sock, g_hEvent[WSA_READ], FD_READ | FD_CLOSE);

	return TRUE;
}


/**
 * Closes client connection
 *
 * @return TRUE if connection was closed, FALSE otherwise
 */
BOOL CloseConnection(SOCKET *cl_sock)
{
	if (*cl_sock) {
		closesocket(*cl_sock);
		*cl_sock = 0;
	}

	return TRUE;
}


/**
 * Gets data from socket
 *
 * @param sData Pointer to receive data
 * @return Size of data got, or -1 if nothing to read
 */
int ReadSocketData(SOCKET *cl_sock, char *sData, int iMaxSize)
{
	int iFlags = 0;
	int iBytes;

	iBytes = WSARecvEx(*cl_sock, sData, iMaxSize, &iFlags);

	if ((iBytes == 0) && ((iFlags & MSG_PARTIAL) != MSG_PARTIAL)) {
		iBytes = -1;
	}

	return iBytes;
}


/**
 * Writes data on active socket
 *
 * @param sData Data to write
 * @param iSize Size of data
 * @return Bytes written on socket
 */
int WriteSocketData(SOCKET *cl_sock, char *sData, int iSize)
{
	int iBytes;

	iBytes = send(*cl_sock, sData, iSize, 0);

	return iBytes;
}



