#!/bin/sh

# Driver Loader by Helibot

/usr/bin/killall -9 redirect
/sbin/rmmod mx1ads_usbd
/sbin/rmmod mx1ads_usbserial
/bin/mknod -m 777 /tmp/ttyUSB c 188 0
/sbin/insmod ./mx1ads_usbserial.o
ln -s /bin/sh /tmp/redirect 
echo USB Serial Setup done. Starting shell to redirect console to ttyUSB
/tmp/redirect < /tmp/ttyUSB > /tmp/ttyUSB 2<&1 &
# Checks that the system is online. Alerts user either way
# Added by Tika Carr
var = `/bin/lsmod | grep -e usbserial`
var=`/sbin/lsmod | grep -c -e usbserial`
if [ $var != "0" ] && [ -f /tmp/redirect ]
then
     /usr/bin/robot/scripts/play_audio.sh  "/mnt/default/Personalities/RSMedia/Sounds/USBCON.mp3" 0 0 
  else
     /usr/bin/robot/scripts/play_audio.sh  "/mnt/default/Personalities/RSMedia/Sounds/CANTDO01.mp3" 0 0
fi
