#number of Bcons: 21
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM04.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM03.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM02.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM01.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\RSMedia Pose.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\BillyJoe.jpg
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM05.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\VortexRacerScreen.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\Speaker.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\TX hand.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\SDcard.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\RSMedia in love.JPG
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM10.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM09.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM08.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM07.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\MEDDEM06.mp3
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\BillyJoe.jpg
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\Butler.jpg
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\SpaceBot.jpg
#C:\Program Files\WowWee\RS Media Suite\Personality\Billy Joe\BodyCons\CONANIM12\PERSINTRO.mp3
#Start Macro|StartEvent|1|
#PERSINTRO.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "PERSINTRO.mp3" 0 0   |\Images\actions\play-sound.gif
#RSMedia Pose.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "RSMedia Pose.JPG" 11000 & |\Images\actions\display-picture.gif
#MEDDEM01.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM01.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#BillyJoe.jpg|Action|1|/usr/bin/robot/scripts/display_image.sh "BillyJoe.jpg" 3000 & |\Images\actions\display-picture.gif
#Butler.jpg|Action|1|/usr/bin/robot/scripts/display_image.sh "Butler.jpg" 3000 & |\Images\actions\display-picture.gif
#SpaceBot.jpg|Action|1|/usr/bin/robot/scripts/display_image.sh "SpaceBot.jpg" 3000 & |\Images\actions\display-picture.gif
#MEDDEM02.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM02.mp3" 0 0   |\Images\actions\play-sound.gif
#MEDDEM03.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM03.mp3" 0 0   |\Images\actions\play-sound.gif
#MEDDEM04.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM04.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#Take A Photo After The Time Delay|Action|1|/usr/bin/robot/scripts/take_photo_timer.sh 1000 |\Images\actions\take-photo-time.gif
#MEDDEM05.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM05.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#VortexRacerScreen.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "VortexRacerScreen.JPG" 9000 & |\Images\actions\display-picture.gif
#MEDDEM06.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM06.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#Speaker.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "Speaker.JPG" 10000 & |\Images\actions\display-picture.gif
#MEDDEM07.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM07.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#TX hand.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "TX hand.JPG" 11000 & |\Images\actions\display-picture.gif
#MEDDEM08.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM08.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#SDcard.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "SDcard.JPG" 12000 & |\Images\actions\display-picture.gif
#MEDDEM09.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM09.mp3" 0 0   |\Images\actions\play-sound.gif
#Clear The LCD Screen Display|Action|1|/usr/bin/robot/scripts/clear_screen.sh  |\Images\actions\clear-screen.gif
#RSMedia in love.JPG|Action|1|/usr/bin/robot/scripts/display_image.sh "RSMedia in love.JPG" 15000 & |\Images\actions\display-picture.gif
#MEDDEM10.mp3|Action|1|/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM10.mp3" 0 0   |\Images\actions\play-sound.gif
#End of Macro|EndEvent|0|
#code section:
#!bash
PATH=/usr/bin/robot/state:/usr/bin/robot/script:$PATH
/usr/bin/robot/scripts/play_audio_noui.sh "PERSINTRO.mp3" 0 0
/usr/bin/robot/scripts/display_image.sh "RSMedia Pose.JPG" 13000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM01.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM02.mp3" 0 0 &
/usr/bin/robot/scripts/display_image.sh "BillyJoe.jpg" 15000
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM03.mp3" 0 0 &
/usr/bin/robot/scripts/display_image.sh "Butler.jpg" 9000
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM04.mp3" 0 0  &
/usr/bin/robot/scripts/display_image.sh "SpaceBot.jpg" 8000
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/take_photo_timer.sh 1000
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM05.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/display_image.sh "VortexRacerScreen.JPG" 11000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM06.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/display_image.sh "Speaker.JPG" 12000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM07.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/display_image.sh "TX hand.JPG" 13000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM08.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/display_image.sh "SDcard.JPG" 14000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM09.mp3" 0 0
/usr/bin/robot/scripts/clear_screen.sh
/usr/bin/robot/scripts/display_image.sh "RSMedia in love.JPG" 15000 &
/usr/bin/robot/scripts/play_audio_noui.sh "MEDDEM10.mp3" 0 0
