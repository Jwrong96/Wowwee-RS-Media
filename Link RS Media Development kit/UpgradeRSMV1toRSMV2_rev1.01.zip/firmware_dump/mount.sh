#!/bin/bash

mkdir root >& /dev/null
mkdir root/mnt >& /dev/null
mkdir root/mnt/sd >& /dev/null
mkdir root/mnt/default >& /dev/null
mkdir root/lnk >& /dev/null
mkdir root/pw >& /dev/null

mount -o loop nand1 root -t cramfs
mount -o loop nand2 root/mnt/default -t cramfs
mount -o loop nand3 root/mnt/sd -t vfat
mount -o loop nand4 root/lnk -t ext2
mount -o loop nand5 root/pw -t ext2
