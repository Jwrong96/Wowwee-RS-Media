echo "1" > /tmp/state/scriptrun
/usr/bin/robot/pipe /tmp/robot_pipe 9 2 0 0 0
./CONANIM08_User.bcn
/usr/bin/robot/pipe /tmp/robot_pipe 9 2 1 0 0
echo "0" > /tmp/state/scriptrun
