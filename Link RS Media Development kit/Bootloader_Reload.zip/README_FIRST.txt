
How to use BootStrap mode to reload the bootloader into RSMV1 or RSMV2


Prerequisites
You will need the serial hack setup <<Add Link>>
You will need to be able to solder wires or create a solder link on J15 on the media board.
Download the files needed from this location  <<ADD LINK>>
The archive comes with three Bootloaders, one for RSMV1, one for RSMV2_16M (also the correct version if you have upgraded a RSMV1->RSMV2) and RSMV2_32M. You should know which version of RS Media you have before you start. If you dont know try bootloader_RSMV2_16M as it should work on all three variants of the RS Media.

Summary of the process

Solder the bootstrap pin on J15 (or solder on wires and a switch or solder on wires and pins and use a jumper)
Boot robot at 57600 and type 'a'. Response is ':'
Send a runnable bootloader file to the serial port
Change to 115200 and press a key - should get a menu
Choose '0' programming menu
Choose '0' program bootloader
Use USB to transfer the RSMV2 bootloader image (yes I did mean USB)
Bootloader should be flashed
Reboot robot and boot normally or press any key to enter bootloader (if other sections need reflashing)

Details of the process

You will need to pull apart your RSMedia and look for a pad on the bottom of the media board.
It will be labelled J15
There are two pads on the jumper.
I suggest you solder two wires onto the pads.
Shorting/Joining the two wires together will force 'bootstrap' mode.

Start your Serial Terminal program (I suggest TeraTerm)
Set the serial port to 115200.

Join the two pads on J15 to enter Bootstrap mode.
Powering up the robot and press a or A on the terminal program.
Robot responds with ':'
You are now in bootstrap mode. To use this mode you need to send a file swith 'B-records' to the serial port.
   (You can try 57600 if 115200 doesnt work)
Use Tera term 'File:SendFile' to send a file to the RSMedia. Select the file 'Boot_b.txt'
   (For my serial port I also needed to set a line delay of 1ms when configurring the serial port.  You may or may not need this)
Wait for send window to disappear. It may take a few more seconds of lines being shown then you should now see a menu.
   (If it seems to lock up then you likely need to try a transmission delay and /or 57600 speed)
Pres 0 then 0 you should see this:

Nocturnal's RS Media BootLoader - Ver 0.5 (22/09/2007)
------------------------------------------------------------------------
Flash EEPROM : Manufacturer ID = 0x00C2, Device ID = 0x22BA
NAND Flash : Manufacturer ID = 0xEC, Device ID = 0x76, MultiPlane = 0xC0
MC9328MXL CPU : Silicon ID = 0x00D4C01D
RS Media : Device ID = 0xABCDEF01

-+= Main Menu =+-
0. Programming Menu
1. Boot Menu
2. Memory Menu
3. Other Options
4. Boot
   Please enter selection -> 0

-+= Main Menu =+-
0. Program Bootloader
1. Program Kernel
2. Program Root-Disk
3. Program System-Disk
4. Program New Logo
5. Program All
6. Return to Main Menu
   Please enter selection -> 0

USB drive ready for transfer. 

Now connect USB cable to PC
A new USB disk drive should appear.
In WindowXP or 7 it should be quite quick.
In Windows 8 or 10 it can take a longggg time (literally 3-5 minutes) and it may state the USB device cant be started. But be patient, it did eventually always come up for me!!)

If you are using Windows XP (or maybe 7) you can use explorer to copy the image bootload_RSMXX to the new USB drive on the computer. Then eject the Drive in windows.

If you are using Windows 10 then close the window that may popup up showing you the new drive.
Open a DOS command prompt and use these commands  (IMPORTANT change g: to the drive letter on your system)
  rmdir g:\"System Volume information" /S /Q
  copy bootloader_RSMXX g:\
Wehere bootloader_RSMXX is one of the files included in the downloaded archive.

Now goto File Explorer. Make sure the RSMeida USB drive is NOT selected. We do NOT want Explorer to look at the files in the drive.
Instead in the left hand pane, right click on the drive icon and choose "Eject".
  (In Windows 8/10 if you use Explorer to look at the removable drive then it will automatically create extra system/hidden files that WILL make the flash not work correctly.)

Output should look like this:

USB drive ready for transfer.
Unknown command : 0xUnknown command : 0xUnknown command : 0xUnknown command : 0xUnknown command : 0xUnknown command : 0xUnknown command : 0xUnknown command : 0x
File transfer completed.

File Size : 0x00020000
Erasing EEPROM... Complete.
Copying Bootloader from RAM to Flash... Done.
Verifying Bootloader...
Error at 0x10020001 RAM = 0xF1 EEPROM = 0xFF
Verify Complete...

In Windows 10 you may see the Unknown command : 0x repeated 10-15 times before it works and the drive is recognised.

Remove the J15 bootstrap link
And restart the robot, if all went well you should see the normal boot process on the serial port.
If flash failed, you will likely see nothing on the serial port and a white screen on teh RSMedia.

If you want to test the flash BEFORE you remove bootstrap mode , then  reboot the robot, press A and see : then use "send file 'call_bootloader.txt
To test the flash worked , reboot the robot and press 'A' again and see ':'. Use thes 'File:SendFile' to send the file 'call_bootloaderb.txt'.  If the bootloader is correctly in place this shoudl cause the robot to start booting correctly.


Now the disclaimer.... The above porocess worked for me multiple times, but I cant guarantee it works for you. If you have trouble please contact me and I will try to assist.


