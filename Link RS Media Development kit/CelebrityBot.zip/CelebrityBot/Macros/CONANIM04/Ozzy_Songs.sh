# Number of Media:0
/usr/bin/robot/scripts/play_audio.sh  "ozzzy.mp3" 0 0 
