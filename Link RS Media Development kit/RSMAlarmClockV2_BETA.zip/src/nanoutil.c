/*
 * RSM Alarm  Clock application for RSMedia Robot.
 * Helibot 2009
 *
  * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: nanoutil.c
 * Description 	: Useful utility functions for dumping information about Nano-X windows and structures
 * Author      	: Helibot
 */
#include <stdio.h>
#include <sys/time.h>
#include "nano-X.h"

#include "nanoutil.h"

void dumpscreeninfo(GR_SCREEN_INFO	*si)
{
	printf ("Screen info width = %d, height = %d\n",si->cols,si->rows);
	printf ("Screen info ncolors = %ld, fonts = %d\n",si->ncolors,si->fonts);
	printf ("Screen info planes = %d, bpp = %d\n",si->planes,si->bpp);
	printf ("Screen masks = %lx,%lx,%lx\n",si->rmask,si->gmask,si->bmask);
	printf ("Screen FB driver = %d\n",si->fbdriver);
	printf ("Screen pixtype = %d\n",si->pixtype);
	printf ("Screen buttons = %d\n",si->buttons);
	printf ("Screen modifiers = %d\n",si->modifiers);
}

void dumpwinfo(GR_WINDOW_INFO *wi)
{
	printf ("===Win Info====\nID=%d\n,parent=%d\n,inputonly=%d\n,mapped=%d\n",wi->wid,wi->parent,wi->inputonly,wi->mapped);
	printf ("  X=%d\n,Y=%d\n,H=%d\n,W=%d\n",wi->x,wi->y,wi->width,wi->height);
	printf ("  pid=%ld\n,Props=%lx\n,Mask=%lx\n",wi->processid,wi->props,wi->eventmask);
}
/* Window properties returned by the GrGetWindowInfo call. */
// typedef struct {
  // GR_WINDOW_ID wid;		/* window id (or 0 if no such window) */
  // GR_WINDOW_ID parent;		/* parent window id */
  // GR_WINDOW_ID child;		/* first child window id (or 0) */
  // GR_WINDOW_ID sibling;		/* next sibling window id (or 0) */
  // GR_BOOL inputonly;		/* TRUE if window is input only */
  // GR_BOOL mapped;		/* TRUE if window is mapped */
  // GR_COUNT unmapcount;		/* reasons why window is unmapped */
  // GR_COORD x;			/* absolute x position of window */
  // GR_COORD y;			/* absolute y position of window */
  // GR_SIZE width;		/* width of window */
  // GR_SIZE height;		/* height of window */
  // GR_SIZE bordersize;		/* size of border */
  // GR_COLOR bordercolor;		/* color of border */
  // GR_COLOR background;		/* background color */
  // GR_EVENT_MASK eventmask;	/* current event mask for this client */
  // GR_WM_PROPS props;		/* window properties */
  // GR_CURSOR_ID cursor;		/* cursor id*/
  // unsigned long processid;	/* process id of owner*/
// } GR_WINDOW_INFO;

void dumpwprop(GR_WM_PROPERTIES *wp)
{
	printf ("===Win Propeties====\nflags=%lx\n,props=%lx\n,bgcol=%lx\n,bdrsize=%d\nbdrcol=%lx\n",
	wp->flags,wp->props,wp->background,wp->bordersize,wp->bordercolor);
	printf ("  Title=%s\n",wp->title);
}
// typedef struct {
  // GR_WM_PROPS flags;		/* Which properties valid in struct for set*/
  // GR_WM_PROPS props;		/* Window property bits*/
  // GR_CHAR *title;		/* Window title*/
  // GR_COLOR background;		/* Window background color*/
  // GR_SIZE bordersize;		/* Window border size*/
  // GR_COLOR bordercolor;		/* Window border color*/
// } GR_WM_PROPERTIES;

void dumpgcinfo(GR_GC_INFO *gc)
{
	printf ("===GC Info====\ngcid=%x\nmode=%d\nxoff=%x\nyoff=%x\nFontID=%d\nfgcol=%lx\nbgcol=%lx\n",
	gc->gcid,gc->mode,gc->xoff,gc->yoff,gc->font,gc->foreground,gc->background);
}
// /* Graphics context properties returned by the GrGetGCInfo call. */
// typedef struct {
  // GR_GC_ID gcid;		/* GC id (or 0 if no such GC) */
  // int mode;			/* drawing mode */
  // GR_REGION_ID region;		/* user region */
  // int xoff;			/* x offset of user region*/
  // int yoff;			/* y offset of user region*/
  // GR_FONT_ID font;		/* font number */
  // GR_COLOR foreground;		/* foreground color */
  // GR_COLOR background;		/* background color */
  // GR_BOOL usebackground;	/* use background in bitmaps */
// } GR_GC_INFO;


void dumpfontinfo(GR_FONT_INFO *fi)
{
	printf ("===FontInfo==== maxwidth=%d height=%d baseline=%d 1st char=%d last char=%d fixed=%d\n",
	fi->maxwidth,fi->height,fi->baseline,fi->firstchar,fi->lastchar,fi->fixed);
}
/* GetFontInfo structure*/
// typedef struct {
	// int 	maxwidth;	/* maximum width of any char */
	// int 	height;		/* height of font in pixels*/
	// int 	baseline;	/* baseline (ascent) of font */
	// int	firstchar;	/* first character in font*/
	// int	lastchar;	/* last character in font*/
	// MWBOOL	fixed;		/* TRUE if font is fixed width */
	// MWUCHAR	widths[256];	/* table of character widths */
// } MWFONTINFO, *PMWFONTINFO;

void getfontlist(GR_GC_INFO *gc)
{
	GR_FONTLIST **fontlist;
	//GR_FONTLIST *fl;

	int numfonts=0;
	int i;
	GrGetFontList(&fontlist, &numfonts);
	printf("NUM_FONTS = %d\n",numfonts);
	//fl= *fontlist;
	for (i=0; i<numfonts; i++)
	{
		//printf("name(%d) = %s\n",i,fl->mwname);
		//fl++;
	}
}

void get_sys_colors()
{
	int i;
	GR_COLOR grcol;
	GR_PIXELVAL pixval;

	for (i=0;i<16;i++)
	{
		grcol = GrGetSysColor(i);
		GrFindColor(grcol, &pixval);
		printf ("Sys color %d = %lx (%x)\n",i,grcol,pixval);
	}
}
GR_COLOR test_cols[]={
BLACK,//		MWRGB( 0  , 0  , 0   )
YELLOW	,//	MWRGB( 255, 255, 0   )
RED	,//	MWRGB( 128, 0  , 0   )
LTRED	,//	MWRGB( 255, 0  , 0   )
LTBLUE,//		MWRGB( 0  , 0  , 255 )
BLUE,//		MWRGB( 0  , 0  , 128 )
LTGREEN	,//	MWRGB( 0  , 255, 0   )
GREEN,//		MWRGB( 0  , 128, 0   )
WHITE	,//	MWRGB( 255, 255, 255 )
CYAN,//		MWRGB( 0  , 128, 128 )
MAGENTA	,//	MWRGB( 128, 0  , 128 )
BROWN,//		MWRGB( 128, 64 , 0   )
LTGRAY,//		MWRGB( 192, 192, 192 )
GRAY,//		MWRGB( 128, 128, 128 )
LTCYAN	,//	MWRGB( 0  , 255, 255 )
LTMAGENTA,//	MWRGB( 255, 0  , 255 )
DKGRAY,//		MWRGB( 32,  32,  32)
};

//Basic function to fill the RSMedia Robots LCD screen with stripes of different colours.
//Not used in RSM Alarm Clock application , but left here for others who may reuse this code!
void ColourTest(GR_WINDOW_ID wid, GR_GC_ID gc)
{
	int y=0;
	GR_PIXELVAL pixval;
	for (y=0;y<17;y++)
	{
		GrSetGCForeground(gc,test_cols[y]);
		GrFillRect(wid, gc, 0,y*10,132,12);
		GrFindColor(test_cols[y], &pixval);
		printf ("ColTest %d = %06lx (%06x)\n",y,test_cols[y],pixval);
	}
}

static unsigned char psEventType[23][32] = {
"GR_EVENT_TYPE_NONE",	//	0
"GR_EVENT_TYPE_EXPOSURE", //		1
"GR_EVENT_TYPE_BUTTON_DOWN",//	2
"GR_EVENT_TYPE_BUTTON_UP",	//		3
"GR_EVENT_TYPE_MOUSE_ENTER",	//	4
"GR_EVENT_TYPE_MOUSE_EXIT",	//	5
"GR_EVENT_TYPE_MOUSE_MOTION",	//	6
"GR_EVENT_TYPE_MOUSE_POSITION",	//	7
"GR_EVENT_TYPE_KEY_DOWN",	//		8
"GR_EVENT_TYPE_KEY_UP",	//		9
"GR_EVENT_TYPE_FOCUS_IN	",	//	10
"GR_EVENT_TYPE_FOCUS_OUT",	//		11
"GR_EVENT_TYPE_FDINPUT",	//		12
"GR_EVENT_TYPE_UPDATE",	//		13
"GR_EVENT_TYPE_CHLD_UPDATE",	//	14
"GR_EVENT_TYPE_CLOSE_REQ",	//		15
"GR_EVENT_TYPE_TIMEOUT",	//		16
"GR_EVENT_TYPE_SCREENSAVER",	//	17
"GR_EVENT_TYPE_CLIENT_DATA_REQ",	//	18
"GR_EVENT_TYPE_CLIENT_DATA",	//	19
"GR_EVENT_TYPE_SELECTION_CHANGED",	// 20
"GR_EVENT_TYPE_TIMER",	//            21
"GR_EVENT_TYPE_PORTRAIT_CHANGED"	//  22
};
unsigned char *psGetEventName(GR_EVENT_TYPE type)
{
  return (&psEventType[type][0]);
}
