#ifndef __UDF_DECL_H
#define __UDF_DECL_H

/* Timestamp (ECMA 167 1/7.3) */
typedef struct {
	unsigned int typeAndTimezone;
	unsigned int year;
	unsigned char month;
	unsigned int day;
	unsigned int hour;
	unsigned int minute;
	unsigned int second;
	unsigned int centiseconds;
	unsigned int hundredsOfMicroseconds;
	unsigned int microseconds;
} timestamp;

/* udftime.c */
extern time_t *udf_stamp_to_time(time_t *, long *, timestamp);
extern timestamp *udf_time_to_stamp(timestamp *, time_t, long);
//extern time_t udf_converttime (struct ktm *);

//HMc added for convience
extern int get_time(char *time_string,char *date_string);
extern int create_date(timestamp *tstamp,char *date_string);
int get_timestamp(timestamp *tstamp);
int set_time(timestamp *tstamp);
int get_weekday(int month, int day, int year);
#endif /* __UDF_DECL_H */
