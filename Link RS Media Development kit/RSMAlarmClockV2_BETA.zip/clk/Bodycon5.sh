#This is the script that starts the RSM Alarm Clock application for the RSMedia robot.
#By Helibot 2009.
#kill any old versions of the RSMalarm clock running
killall rsmalarmclock

#copy the runbodycon.sh script to the /tmp dir so we can always find when needed for an alarm.
cp ./runbodycon.sh /tmp

#Start the rsm alarm clock application (using '&' so its run in the background - so console is still available)
./rsmalarmclock &
