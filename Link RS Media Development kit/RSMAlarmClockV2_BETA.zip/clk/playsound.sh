#Stop any exitsing audio players
killall audioplayer

#Start a new audioplayer
/usr/bin/robot/audioplayer -q0 -n0 -c0 -e0 -f $1 &

