#This script is a special script only used when rsmalarmclock needs to run a user bodycon.
#A user bodycon must be executed from its own directory. So this script changes to the directroy specified.
#Then executes the bodycon script. 
dir=`dirname "$1"`
cd "$dir"
"$1"
