/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: bridge.c
 * Description 	: Bridge TCP <-> USB management
 * Author       : Helibot
 * Authors		: Christophe Buguet (cbuguet@users.sourceforge.net)
 *				  Gerald Villemure (gvillemure@users.sourceforge.net)
 *
 * $Id: bridge.c,v 1.1 2004/09/09 19:58:57 cbuguet Exp $
 */

#include <stdio.h>
#include <winsock2.h>
#include "bridge.h"
#include "tcp.h"
#include "usb.h"
//#include "error.h"

#define MAXSIZE_TCPBUFFER	2048
#define MAXSIZE_USBBUFFER	2048
#define MAXSIZE_USBWRITE	32

/* Extern vars */
//OVERLAPPED	ovRead, ovWrite;
///int			g_iAuthPos;

/* Global vars */
extern FILE *myout;


/**
 * Disposes client connection
 */
void DisposeClientConnection()
{
	CloseConnection(&(g_lpBridgeCfg->sockClient));
	DisposeUsb();
///	g_lpBridgeCfg->bAuthenticated = (strlen(g_lpBridgeCfg->sPassword) == 0);
///	g_iAuthPos = 0;
}


/**
 * Callback for managing bridge thread
 *
 * @param lpParameter Data passed by CreateThread function
 * @return S_OK if everything succeed or ERR_FAIL if failure
 */
DWORD WINAPI StartBridgeThread(LPVOID lpParameter)
{
	int		iBytes, iErr, iUsbBytesRead=0, iUsbBytesWritten=0, iTCPBytesWrite =0;
//	int		iPos, iPosUsbBuffer = 0;

	char	sUsbBufferIn[MAXSIZE_USBBUFFER],  sUsbBufferOut[MAXSIZE_USBBUFFER];

	char	sTcpBufferOut[MAXSIZE_USBBUFFER], sTcpBufferIn[MAXSIZE_TCPBUFFER];  

	DWORD	dwEvent;

	WSANETWORKEVENTS netEvents;

	// Inits TCP stuff
	InitWinsock();
	iErr = StartTcpSocket(g_lpBridgeCfg->sBindAddr, (unsigned short)g_lpBridgeCfg->lTcpPort, NULL);

	if (iErr != S_OK) {
		fprintf(myout, "bridge.c: StartTcpSocket() failed\n");
		return FALSE;
	} else {
		fprintf(myout, "bridge.c: StartTcpSocket() succeeded\n");
	}


	//Open the USB connection
	if (OpenUsb(g_lpBridgeCfg->iUsbvid,g_lpBridgeCfg->iUsbpid) != S_OK)
	{
		fprintf(myout, "bridge.c: USB failed to Open\n");
		return FALSE;
	} else
	{
		//LibUSB has already created the async Events to wait on. So copy the handles to our event list
		g_hEvent[USB_READ] = (usbGetOverlappedUSBRead()).hEvent;
		g_hEvent[USB_WRITE] = (usbGetOverlappedUSBWrite()).hEvent;
		ResetEvent(g_hEvent[USB_READ]);
		ResetEvent(g_hEvent[USB_WRITE]);


		// Start waiting for something to read from USB
		//DEBUG IS THIS (OR SOMETHING ELSE REQUIREd) HERE??????
		iErr = usb_submit_async(pread_usb_context, (char *)/*(LPCSTR *)*/&sUsbBufferIn, MAXSIZE_USBBUFFER);
		printf("usb_sub_async: returned %d\n",iErr);
	//	iErr = GetOverlappedResult(g_hEvent[USB_READ], &pread_usb_context->ol, &dwBytes, FALSE);
	//	printf("GetOverlappedUSB_READ: returned %d\n",iErr);
	}
	while (1) {
		// Handles Network TCP messages
		dwEvent = WSAWaitForMultipleEvents(MAX_EVENTS, g_hEvent, FALSE, WSA_INFINITE, TRUE);
//		printf("bridge.c: ...Event Occured %d \n",dwEvent);

		// Treats messages
		switch (dwEvent) {
			case WSA_ACCEPT:
				if (AcceptConnection(&(g_lpBridgeCfg->sockClient))) {
					g_lpBridgeCfg->iNameLen = sizeof(struct sockaddr_in);
					getpeername(g_lpBridgeCfg->sockClient, (struct sockaddr *)&(g_lpBridgeCfg->sockAddr), &(g_lpBridgeCfg->iNameLen));
					fprintf(myout, "bridge.c: Accepted connection from %s\n", inet_ntoa(g_lpBridgeCfg->sockAddr.sin_addr));
					
					strcpy(sTcpBufferOut, "+USB2TCP v2.0.0\r\n# ");
					iBytes = WriteSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferOut, (int) strlen(sTcpBufferOut));

					sTcpBufferOut[0] = 0;

					///Start a read of the USB data 
					iUsbBytesRead = ReadBytes((LPCSTR *)&sUsbBufferIn, MAXSIZE_USBBUFFER);
				}

				WSAResetEvent(g_hEvent[WSA_ACCEPT]);
				break;

			case WSA_READ:
				WSAEnumNetworkEvents(g_lpBridgeCfg->sockClient, g_hEvent[WSA_READ], &netEvents);

				if (netEvents.lNetworkEvents == FD_READ) {
					
					iBytes = ReadSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferIn, MAXSIZE_USBWRITE-2);
					if (iBytes) {
						//Copy data from TCP in to USB out buffer
						memcpy (sUsbBufferOut,sTcpBufferIn,iBytes);
						//Write bytes to USB port
						iUsbBytesWritten = WriteBytes(sUsbBufferOut, iBytes);
					}
/*
					//Now see if there are any more bytes to send. If so sleep for awhile so USB dricer can send data first.
					while ((iBytes = ReadSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferIn, MAXSIZE_USBWRITE)) != -1) {
						Sleep (100);  //Give USB driver time to send the last 32 bytes
						//Copy data from TCP in to USB out buffer
						memcpy (sUsbBufferOut,sTcpBufferIn,iBytes);
						//Write bytes to USB port
						iUsbBytesWritten = WriteBytes(sUsbBufferOut, iBytes);
						fprintf(myout, "bridge.c: %i bytes written to USB after sleep\n", iUsbBytesWritten);
					}
*/
				} else if (netEvents.lNetworkEvents == FD_CLOSE) {
					DisposeClientConnection();
					fprintf(myout, "bridge.c: Connection closed while reading data\n");
				} 

				WSAResetEvent(g_hEvent[WSA_READ]);
				break;

			case WSA_WRITE:
				WSAEnumNetworkEvents(g_lpBridgeCfg->sockClient, g_hEvent[WSA_WRITE], &netEvents);

				if (netEvents.lNetworkEvents == FD_CLOSE) {
					DisposeClientConnection();
					fprintf(myout, "bridge.c: Connection closed while writing data\n");
				} else
				{
					//Write data to socket 
					//iBytes = WriteSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferOut, strlen(sTcpBufferOut));
					//Helibot changed to use len is iUsbBytesRead so binary data can be sent
					iBytes = WriteSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferOut, iTCPBytesWrite);

//					fprintf(myout, "bridge.c: %i byte(s) written to TCP (%i planned)\n", iBytes, iTCPBytesWrite);
					iTCPBytesWrite =0;
				}

				WSAResetEvent(g_hEvent[WSA_WRITE]);
				break;

			case USB_WRITE:
				printf("bridge.c: USB_WRITE Event: ");
				if (GetOverlappedResult(g_hEvent[USB_WRITE], &pwrite_usb_context->ol, &iUsbBytesWritten, FALSE)) {
						printf("%i bytes written on USB\n", iUsbBytesWritten);
				}

				ResetEvent(g_hEvent[USB_WRITE]);

				//Now see if there are any more bytes in the TCPIN Buffer to send. 
				if ((iBytes = ReadSocketData(&(g_lpBridgeCfg->sockClient), sTcpBufferIn, MAXSIZE_USBWRITE-2)) != -1) {
						//The wait below should NOT be needed but RSMedia read is polled at the moment so it cannot read data very fast.
//Helibot 18/1/2010
					    Sleep (g_lpBridgeCfg->iUsbdelay);  //Sleep for iUSBdelay millisecs (this var is set on command line (default is 20ms)
							
						//Copy data from TCP in to USB out buffer
						memcpy (sUsbBufferOut,sTcpBufferIn,iBytes);
						//Write bytes to USB port
						iUsbBytesWritten = WriteBytes(sUsbBufferOut, iBytes);
						fprintf(myout, "bridge.c: %i bytes written to USB after WRITE event\n", iUsbBytesWritten);
				}
				break;

			case USB_READ:
				printf("bridge.c: USB_READ  Event: ");
				iUsbBytesRead = 0;
				if (GetOverlappedResult(g_hEvent[USB_WRITE], &pread_usb_context->ol, &iUsbBytesRead, FALSE)) {
					/*if (iComBytesRead > 0)*/
					fprintf(myout, "%i bytes from USB\n", iUsbBytesRead);

					//Copy bytes from USBport to TCP out buffer AND set TCP WRITE event
					if ( iUsbBytesRead > 0) {
						//strncpy(sTcpBufferOut, sUsbBufferIn, iUsbBytesRead);
						//sTcpBufferOut[iUsbBytesRead] = 0;
						//Helibot - changed to memcpy so binary data can be passed.
						memcpy(sTcpBufferOut, sUsbBufferIn, iUsbBytesRead);
						iTCPBytesWrite = iUsbBytesRead;
						WSASetEvent(g_hEvent[WSA_WRITE]);
					}
				}
					
				ResetEvent(g_hEvent[USB_READ]);

				//Start another read again. 				
				ReadBytes((LPCSTR *)&sUsbBufferIn, MAXSIZE_USBBUFFER);

				break;

			default:
				break;
		}
	}

	// Close TCP and COM stuff
	CloseWinsock();

	return FALSE;
}

