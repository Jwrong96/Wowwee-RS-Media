/*
 * USB to TCP bridge
 * Helibot 2009
 *
 * Based on tcp2com - see USB2TCP.html
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * ---------------------------------------------------------------------------
 *
 * File 		: usb.c
 * Description 	: USB port management functions
 * Authors		: Helibot 
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "libusb.h"   //Include libusb public header file.
#include "usb.h"   //Include this files headers.
#include "error.h"
#include "bridge.h"

/* Local vars */

usb_context_t *pread_usb_context;
usb_context_t *pwrite_usb_context;
usb_dev_handle *dev = NULL; /* the device handle */


/**
 * Disposes COM handles and values
 */
void DisposeUsb(void)
{
	if (dev != NULL)
	  usb_close(dev);
}


//usb_dev_handle *open_dev(void);

usb_dev_handle *open_dev(int iUsbvid,int iUsbpid)
{
  struct usb_bus *bus;
  struct usb_device *dev;

  for(bus = usb_get_busses(); bus; bus = bus->next) 
    {
      for(dev = bus->devices; dev; dev = dev->next) 
        {
          if(dev->descriptor.idVendor == iUsbvid
             && dev->descriptor.idProduct == iUsbpid)
            {
              return usb_open(dev);
            }
        }
    }
  return NULL;
}


/**
 * Opens USB port 
 *
 * @return S_OK if succeed, ERR_FAIL otherwise
 */
int OpenUsb(int iUsbvid,int iUsbpid)
{
     
  usb_init(); /* initialize the library */
  usb_find_busses(); /* find all busses */
  usb_find_devices(); /* find all connected devices */

  if(!(dev = open_dev(iUsbvid,iUsbpid)))
    {
      printf("error: USB device not found!\n");
      return ERR_FAIL;
    }

  if(usb_set_configuration(dev, 1) < 0)
    {
      printf("error: USB setting config 1 failed\n");
      usb_close(dev);
      return ERR_FAIL;
    }

  if(usb_claim_interface(dev, 0) < 0)
    {
      printf("error: USB claiming interface 0 failed\n");
      usb_close(dev);
      return ERR_FAIL;
    }
	//Setup a read context for the EP_IN endpoint.
    usb_bulk_setup_async(dev, (void *) &pread_usb_context ,EP_IN);
	//Setup a write context for the EP_OUT endpoint.
	usb_bulk_setup_async(dev, (void *) &pwrite_usb_context ,EP_OUT);

	return S_OK;
}


OVERLAPPED usbGetOverlappedUSBRead()
{
	return pread_usb_context->ol;
}

OVERLAPPED usbGetOverlappedUSBWrite()
{
	return pwrite_usb_context->ol;
}


/**
 * Read iCount bytes from the opened USB port.
 * This function starts a read via usb_submit_async
 *
 * @param lpszBuffer Buffer where to store the read data
 * @param iSize Number of bytes to read
 * @return The number of bytes read or ERR_FAIL
 */
int ReadBytes(LPCSTR *lpszBuffer, int iSize)
{
	INT		iRetVal,GetOLResult;

	DWORD	dwBytesRead = 0;

	iRetVal= usb_submit_async(pread_usb_context, (char *) lpszBuffer, iSize);

	GetOLResult = GetOverlappedResult(g_hEvent[USB_READ], &pread_usb_context->ol, &dwBytesRead, FALSE);
	//printf("usb_read: iretval =  %d GetOLResult = %d dwBytesRead = %d\n",iRetVal,GetOLResult,dwBytesRead);
	//printf("usb_read: data = [ %c%c%c ]\n",lpszBuffer[0],lpszBuffer[1],lpszBuffer[3]);
	return iSize;
}


/**
 * Write iCount bytes from the opened COM port.
 * Non-blocking.
 *
 * @param lpszBuffer Buffer with data
 * @param iSize Number of bytes to write
 * @return The number of bytes written or ERR_FAIL
 */
int WriteBytes(LPCSTR lpszBuffer, int iSize)
{
	INT		iRetVal;


	iRetVal= usb_submit_async(pwrite_usb_context, (char *) lpszBuffer, iSize);

	if (iRetVal != 0) 
	{	
		printf ("USBWrite error (%d)\n",iRetVal);
		return 0;
	}
	else
        return (int)iSize /*dwBytesRead*/;
}
