killall nano-X
killall main_ui

sleep 1
. /usr/bin/robot/init.sh.ff
/usr/bin/robot/nano-X -p &

sleep 1

#Run obot Mimic
/mnt/sd/Application/copybot

#when Robot Mimic finishes the start the normal Wowwee robot programs again
#. /usr/bin/robot/init.sh.ff
#/usr/bin/robot/nano-X -p &
/usr/bin/robot/mediadaemon &
/usr/bin/robot/start_robot_main &
/usr/bin/robot/main_ui &