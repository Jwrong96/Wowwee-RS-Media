#!/bin/sh

# Call script in Application directory to start the USB console.
/mnt/sd/Application/run_copybot.sh


